<?php
include $_SERVER['DOCUMENT_ROOT'].'/functions/top_search.php';
include $_SERVER['DOCUMENT_ROOT'].'/functions/login.php';
include $_SERVER['DOCUMENT_ROOT'].'/functions/resize_avatar.php';
include $_SERVER['DOCUMENT_ROOT'].'/functions/add_friends.php';
include $_SERVER['DOCUMENT_ROOT'].'/functions/del_friends.php';
include $_SERVER['DOCUMENT_ROOT'].'/functions/load_comments.php';
include $_SERVER['DOCUMENT_ROOT'].'/functions/send_comment.php';
include $_SERVER['DOCUMENT_ROOT'].'/functions/del_comment.php';
include $_SERVER['DOCUMENT_ROOT'].'/functions/like_users.php';
include $_SERVER['DOCUMENT_ROOT'].'/functions/like_peoples.php';
include $_SERVER['DOCUMENT_ROOT'].'/functions/load_photo.php';
include $_SERVER['DOCUMENT_ROOT'].'/functions/send_wall.php';
include $_SERVER['DOCUMENT_ROOT'].'/functions/load_wall.php';
include $_SERVER['DOCUMENT_ROOT'].'/functions/del_wall.php';
include $_SERVER['DOCUMENT_ROOT'].'/functions/del_photo.php';
include $_SERVER['DOCUMENT_ROOT'].'/functions/save_photo.php';
include $_SERVER['DOCUMENT_ROOT'].'/functions/del_avatar.php';
include $_SERVER['DOCUMENT_ROOT'].'/functions/ping_online.php';
include $_SERVER['DOCUMENT_ROOT'].'/functions/visits.php';
include $_SERVER['DOCUMENT_ROOT'].'/functions/otvety.php';
include $_SERVER['DOCUMENT_ROOT'].'/functions/edit_status.php';


include $_SERVER['DOCUMENT_ROOT']."/inc/agent.php";
$agent->init();
?>
<?php
include $_SERVER['DOCUMENT_ROOT'].'/inc/config.php';
include $_SERVER['DOCUMENT_ROOT'].'/inc/login.php';
$uid = $_GET['uid'];
$uid = addslashes($uid);
$uid = htmlspecialchars($uid);
include $_SERVER['DOCUMENT_ROOT'].'/inc/sql_social.php';

if ($my_id) {
$live_avatar = true;
$z_live_my_avatar = mysql_query("SELECT avatar FROM users WHERE id='$my_id'");
$o_live_my_avatar = mysql_fetch_array($z_live_my_avatar);
$live_my_avatar = $o_live_my_avatar['avatar'];

if ($live_my_avatar=='0') {
    $live_avatar = false;
}
}

$z_user_info = mysql_query("SELECT * FROM users WHERE id='$uid'");
$o_user_info = mysql_fetch_array($z_user_info);
$info_id = $o_user_info['id'];

$z_count_photos = mysql_query("SELECT photo_id FROM photo_to_users WHERE user_id='$uid' and photo_type='1' and live='1'");
$count_photos = mysql_num_rows($z_count_photos);

if ($info_id) {
    $info_firstname = $o_user_info['firstname'];
    $info_lastname = $o_user_info['lastname'];
    $info_sex = $o_user_info['sex'];
    if ($info_sex=='1') { $sex_name = 'girl'; } else { $sex_name = 'boy'; }
    $info_avatar = $o_user_info['avatar'];
    $info_status = $o_user_info['status'];
    if ($my_id==$uid and $info_status=='') {
        $info_status = $lang[60];
    }

    $rand = rand(10000, 99999);
    if ($info_avatar==0) {
        if ($info_sex==1) { $page_avatar = '/img/no_photo/girl.png?r='.$rand; }
        if ($info_sex==2) { $page_avatar = '/img/no_photo/boy.png?r='.$rand; }
    } else {
        $page_avatar = '/avatar/'.$uid.'.jpg?r='.$rand;
    }

    echo $avatar;

    $info_day = $o_user_info['day'];
    $info_month = $o_user_info['month'];
    if ($info_month==1) { $info_month = $lang[61]; }
    if ($info_month==2) { $info_month = $lang[62]; }
    if ($info_month==3) { $info_month = $lang[63]; }
    if ($info_month==4) { $info_month = $lang[64]; }
    if ($info_month==5) { $info_month = $lang[65]; }
    if ($info_month==6) { $info_month = $lang[66]; }
    if ($info_month==7) { $info_month = $lang[67]; }
    if ($info_month==8) { $info_month = $lang[68]; }
    if ($info_month==9) { $info_month = $lang[69]; }
    if ($info_month==10) { $info_month = $lang[70]; }
    if ($info_month==11) { $info_month = $lang[71]; }
    if ($info_month==12) { $info_month = $lang[72]; }
    $info_year = $o_user_info['year'];

    if ($info_day and $info_month and $info_year) { $info_firstday = $info_day.' '.$info_month.' '.$info_year; } else { $info_firstday = $lang[73]; }

    $info_marital_status = $o_user_info['marital_status'];
    if ($info_marital_status==0) { $info_marital_status = $lang[74]; }
    if ($info_marital_status==1) { $info_marital_status = $lang[75]; }
    if ($info_marital_status==2) { $info_marital_status = $lang[76]; }
    if ($info_marital_status==3) { $info_marital_status = $lang[77]; }
    if ($info_marital_status==4) { $info_marital_status = $lang[78]; }
    if ($info_marital_status==5) { $info_marital_status = $lang[79]; }
    if ($info_marital_status==6) { $info_marital_status = $lang[80]; }
    if ($info_marital_status==7) { $info_marital_status = $lang[81]; }

    $info_avatar = $o_user_info['avatar'];
    $info_country_id = $o_user_info['country'];
    $info_city_id = $o_user_info['city'];

    $location_value = $lang[82];
    $z_country_name = mysql_query("SELECT * FROM net_country WHERE id='$info_country_id'");
    $o_country_name = mysql_fetch_array($z_country_name);
    if ($o_country_name) { $location_value = $o_country_name['name_'.$js_lang]; }

    $z_city_name = mysql_query("SELECT * FROM net_city WHERE id='$info_city_id'");
    $o_city_name = mysql_fetch_array($z_city_name);
    if ($o_city_name) { $location_value = $location_value.', '.$o_city_name['name_'.$js_lang]; }

    if ($o_user_info['phone']) { $info_phone = $o_user_info['phone']; } else { $info_phone = $lang[83]; }
    if ($o_user_info['mail']) { $info_mail = $o_user_info['mail']; } else { $info_mail = $lang[84]; }
    if ($o_user_info['skype']) { $info_skype = $o_user_info['skype']; } else { $info_skype = $lang[85]; }
    if ($o_user_info['site']) {
        $arr_http = explode('http://', $o_user_info['site']);
        if (count($arr_http)<2) { $o_user_info['site'] = 'http://'.$o_user_info['site']; }
        $info_site = '<a href="'.$o_user_info['site'].'" target="_blank">'.$o_user_info['site'].'</a>'; 
    } else { 
        $info_site = $lang[85]; 
    }
    
    $live_acordion = false;

    $info_activity = $o_user_info['activity']; if ($info_activity) { $live_acordion = true; }
    $info_interests = $o_user_info['interests']; if ($info_interests) { $live_acordion = true; }
    $info_music = $o_user_info['music']; if ($info_music) { $live_acordion = true; }
    $info_movies = $o_user_info['movies']; if ($info_movies) { $live_acordion = true; }
    $info_tv = $o_user_info['tv']; if ($info_tv) { $live_acordion = true; }
    $info_books = $o_user_info['books']; if ($info_books) { $live_acordion = true; }
    $info_games = $o_user_info['games']; if ($info_games) { $live_acordion = true; }
    $info_quotations = $o_user_info['quotations']; if ($info_quotations) { $live_acordion = true; }
    $info_about = $o_user_info['about']; if ($info_about) { $live_acordion = true; }

    $info_institut = $o_user_info['institut']; if ($info_institut) { $live_acordion = true; }
    $info_department = $o_user_info['department']; if ($info_department) { $live_acordion = true; }
    $info_start_training = $o_user_info['start_training']; if ($info_start_training) { $live_acordion = true; }
    $info_finish_training = $o_user_info['finish_training']; if ($info_finish_training) { $live_acordion = true; }
    $info_education_info = $o_user_info['education_info']; if ($info_education_info) { $live_acordion = true; }

    $info_place_work = $o_user_info['place_work']; if ($info_place_work) { $live_acordion = true; }
    $info_position = $o_user_info['position']; if ($info_position) { $live_acordion = true; }
    $info_work_info = $o_user_info['work_info']; if ($info_work_info) { $live_acordion = true; }

    $info_policy = $o_user_info['policy']; if ($info_policy) { $live_acordion = true; }
    if ($info_policy==0) { $info_policy = false; }
    if ($info_policy==1) { $info_policy = $lang[86]; }
    if ($info_policy==2) { $info_policy = $lang[87]; }
    if ($info_policy==3) { $info_policy = $lang[88]; }
    if ($info_policy==4) { $info_policy = $lang[89]; }
    if ($info_policy==5) { $info_policy = $lang[90]; }
    if ($info_policy==6) { $info_policy = $lang[91]; }
    if ($info_policy==7) { $info_policy = $lang[92]; }
    if ($info_policy==8) { $info_policy = $lang[93]; }

    $info_world_view = $o_user_info['world_view']; if ($info_world_view) { $live_acordion = true; }
    if ($info_world_view==0) { $info_world_view = false; }
    if ($info_world_view==1) { $info_world_view = $lang[94]; }
    if ($info_world_view==2) { $info_world_view = $lang[95]; }
    if ($info_world_view==3) { $info_world_view = $lang[96]; }
    if ($info_world_view==4) { $info_world_view = $lang[97]; }
    if ($info_world_view==5) { $info_world_view = $lang[98]; }
    if ($info_world_view==6) { $info_world_view = $lang[99]; }
    if ($info_world_view==7) { $info_world_view = $lang[100]; }
    if ($info_world_view==8) { $info_world_view = $lang[101]; }
    if ($info_world_view==9) { $info_world_view = $lang[102]; }

    $info_important_live = $o_user_info['important_live']; if ($info_important_live) { $live_acordion = true; }
    if ($info_important_live==0) { $info_important_live = false; }
    if ($info_important_live==1) { $info_important_live = $lang[103]; }
    if ($info_important_live==2) { $info_important_live = $lang[104]; }
    if ($info_important_live==3) { $info_important_live = $lang[105]; }
    if ($info_important_live==4) { $info_important_live = $lang[106]; }
    if ($info_important_live==5) { $info_important_live = $lang[107]; }
    if ($info_important_live==6) { $info_important_live = $lang[108]; }
    if ($info_important_live==7) { $info_important_live = $lang[109]; }
    if ($info_important_live==8) { $info_important_livee = $lang[110]; }

    $info_important_peoples = $o_user_info['important_peoples']; if ($info_important_peoples) { $live_acordion = true; }
    if ($info_important_peoples==0) { $info_important_peoples = false; }
    if ($info_important_peoples==1) { $info_important_peoples = $lang[111]; }
    if ($info_important_peoples==2) { $info_important_peoples = $lang[112]; }
    if ($info_important_peoples==3) { $info_important_peoples = $lang[113]; }
    if ($info_important_peoples==4) { $info_important_peoples = $lang[114]; }
    if ($info_important_peoples==5) { $info_important_peoples = $lang[115]; }
    if ($info_important_peoples==6) { $info_important_peoples = $lang[116]; }

    $info_smoking = $o_user_info['smoking']; if ($info_smoking) { $live_acordion = true; }
    if ($info_smoking==0) { $info_smoking = false; }
    if ($info_smoking==1) { $info_smoking = $lang[117]; }
    if ($info_smoking==2) { $info_smoking = $lang[118]; }
    if ($info_smoking==3) { $info_smoking = $lang[119]; }
    if ($info_smoking==4) { $info_smoking = $lang[120]; }
    if ($info_smoking==5) { $info_smoking = $lang[121]; }

    $info_alcohol = $o_user_info['alcohol']; if ($info_alcohol) { $live_acordion = true; }
    if ($info_alcohol==0) { $info_alcoholo = false; }
    if ($info_alcohol==1) { $info_alcohol = $lang[117]; }
    if ($info_alcohol==2) { $info_alcohol = $lang[118]; }
    if ($info_alcohol==3) { $info_alcohol = $lang[119]; }
    if ($info_alcohol==4) { $info_alcohol = $lang[120]; }
    if ($info_alcohol==5) { $info_alcohol = $lang[121]; }

    $info_inspirations = $o_user_info['inspirations']; if ($info_inspirations) { $live_acordion = true; }

    $z_count_photos = mysql_query("SELECT photo_id FROM photo_to_users WHERE user_id='$uid' and photo_type='1' and live='1'");
    $count_photos = mysql_num_rows($z_count_photos);

    $z_count_friends = mysql_query("SELECT * FROM friends WHERE user_id='$uid' and status='1'");
    $count_friends = mysql_num_rows($z_count_friends);

    $z_count_wall = mysql_query("SELECT wall_id FROM wall WHERE page_id='$uid'");
    $count_wall = mysql_num_rows($z_count_wall);


    if ($count_photos>0) {
        $photo_slide = '';
        $photo_modal = '';
        $arr_photo = '';
        $photo_id = 0;
        $result = mysql_query("SELECT * FROM photo_to_users WHERE user_id='$uid' and photo_type='1' and live='1' ORDER BY photo_id DESC"); 
        while ( $myrow = mysql_fetch_array($result) )
        {
        if ($count_photos<6) {
            $photo_slide = $photo_slide.'
            <div style="padding:calc((100% / '.$count_photos.') / 2 - 1px); background-image:url(/photo/m_'.$myrow['photo_name'].'.jpg); margin-right:2px; background-size:cover; background-position:top; cursor:pointer;" onClick="photo_id='.$photo_id.'; start_photo=true; photo_show();"></div>
            ';    
        } else {
            $photo_slide = $photo_slide.'
            <div style="padding: calc(100% / '.($count_photos+10).' / 2 - 1px); background-image:url(/photo/m_'.$myrow['photo_name'].'.jpg); margin-right:2px; background-size:cover; background-position:top; cursor:pointer;" onClick="photo_id='.$photo_id.'; start_photo=true; photo_show();"></div>
            ';
        }

        $uid = $myrow['user_id'];
        $z_user_info = mysql_query("SELECT * FROM users WHERE id='$uid'");
        $o_user_info = mysql_fetch_array($z_user_info);
        $info_firstname = $o_user_info['firstname'];
        $rand = rand(10000, 99999);
        $date = date("d.m.Y H:i", $myrow['date']);
        $object_id = $myrow['photo_id'];

        $z_count_likes = mysql_query("SELECT likes_id FROM likes WHERE object_id='$object_id' and object_type='1'");
        $count_likes = mysql_num_rows($z_count_likes);

        if ($count_likes>0) {
            $likes_count = '<span style="color:#2B587A; font-size:13px;"><b id="like_count_1_'.$myrow['photo_id'].'">'.$count_likes.'</b></span>';
            $display_likes = 'block';
        } else {
            $likes_count = '<span style="color:#2B587A; font-size:13px;"><b id="like_count_1_'.$myrow['photo_id'].'"></b></span>';
            $display_likes = 'none';
        }

        $z_heart_likes = mysql_query("SELECT likes_id FROM likes WHERE object_id='$object_id' and object_type='1' and user_id='$my_id'");
        $heart_likes = mysql_num_rows($z_heart_likes);

        if ($heart_likes>0) {
            $likes_heart = '<span id="like_heart_1_'.$myrow['photo_id'].'" class="icon-heart" style="color:#5085ad; font-size:13px;"></span>';
        } else {
            $likes_heart = '<span id="like_heart_1_'.$myrow['photo_id'].'" class="icon-heart" style="color:#b4cee2; font-size:13px;"></span>';
        }


        $i = 0;
        $likes_body = '';
        $result_like = mysql_query("SELECT * FROM likes WHERE object_id='$object_id' and object_type='1' ORDER BY likes_id DESC, likes_id LIMIT 0, 5"); 
        while ( $myrow_like = mysql_fetch_array($result_like) )
        {
            
            $rand = rand(10000, 99999);
            $user_ava_id = $myrow_like['user_id'];
            $z_user_avatar = mysql_query("SELECT * FROM users WHERE id='$user_ava_id'");
            $o_user_avatar = mysql_fetch_array($z_user_avatar);
            $user_avatar = $o_user_avatar['avatar'];
            $user_sex = $o_user_avatar['sex'];
            if ($user_avatar==0) {
                if ($user_sex==1) { $avatar = '/img/no_photo/girl.png?r='.$rand; }
                if ($user_sex==2) { $avatar = '/img/no_photo/boy.png?r='.$rand; }
            } else {
                $avatar = '/avatar/'.$user_ava_id.'.jpg?r='.$rand;
            }
            
            if ($i==0) {
                $likes_body = '<img width=\'30\' height=\'30\' src=\''.$avatar.'\' style=\'border-radius:100px; margin:5px 0px 5px 0px;\' />'.$likes_body;
            } else {
                $likes_body = '<img width=\'30\' height=\'30\' src=\''.$avatar.'\' style=\'border-radius:100px; float:left; margin:5px 5px 5px 0px;\' />'.$likes_body;
            }
            $i++;
        }

        $rand = rand(10000, 99999);
        $user_ava_id = $myrow['user_id'];
        $z_user_avatar = mysql_query("SELECT * FROM users WHERE id='$user_ava_id'");
        $o_user_avatar = mysql_fetch_array($z_user_avatar);
        $user_avatar = $o_user_avatar['avatar'];
        $user_sex = $o_user_avatar['sex'];
        if ($user_avatar==0) {
            if ($user_sex==1) { $avatar = '/img/no_photo/girl.png?r='.$rand; }
            if ($user_sex==2) { $avatar = '/img/no_photo/boy.png?r='.$rand; }
        } else {
            $avatar = '/avatar/'.$user_ava_id.'.jpg?r='.$rand;
        }
        
        $uid_online = $myrow['user_id'];
        $z_user_online = mysql_query("SELECT time FROM users_to_online WHERE user_id='$uid_online'");
        $o_user_online = mysql_fetch_array($z_user_online);
        $user_online = $o_user_online['time'];
        $this_date = date('U');
        if ($user_online>($this_date-60)) {
            $user_online = ' <span class="icon-lamp" style="color:#46af48; font-size:10px;"></span>';
        } else {
            $user_online = '';
        }

        if ($my_id) {
            $photo_modal = $photo_modal.'
            <div>
            <img id="photo_'.$myrow['photo_id'].'" width="100%" src="/photo/'.$myrow['photo_name'].'.jpg" />
            <div style="padding:15px; height:60px; background:#f5f5f5; border-bottom:1px solid #e1e1e8;">
                <div style="width:50%; float:left;">
                    <div style="float:left;">
                        <a href="/id'.$myrow['user_id'].'"><img id="id_top_avatar" width="30" height="30" src="'.$avatar.'" style="border-radius:100px;"></a>
                    </div>
                    <div style="float:left; padding-left:10px;">
                        <a href="/id'.$myrow['user_id'].'">'.$info_firstname.$user_online.'</a>
                        <br>
                        <span style="font-size:11px; color:#777;">'.$date.'</span>
                    </div>
                </div>
                <div style="width:50%; float:left; cursor:pointer;" onselectstart="return false" onmousedown="return false">
                    <div style="float:right; cursor:pointer;" onClick="object_id='.$myrow['photo_id'].'; object_type=1; token=\''.md5($my_id.'_'.$myrow['photo_id'].'_1_like_'.$secret).'\'; like();">
                        '.$likes_heart.'
                        <span style="color:#2B587A; margin-left:5px;">'.$lang[122].'</span>
                        '.$likes_count.'
                    </div>
                    <span id="popover_1_'.$myrow['photo_id'].'" data-toggle="tooltip" data-placement="top" data-html="true" title="'.$likes_body.'" onclick="object_id='.$myrow['photo_id'].'; object_type=1; more=false; page=1; like_peoples();" onmouseover="$(\'#popover_1_'.$myrow['photo_id'].'\').tooltip(\'show\');" onmouseout="$(\'#popover_1_'.$myrow['photo_id'].'\').tooltip(\'hide\');" style="float:right; font-size:12px; color:#b4cee2; margin-right:10px; cursor:pointer; display:'.$display_likes.';">&bull;&bull;&bull;</span>
                </div>
            </div>
            </div>
            ';
        } else {
            $photo_modal = $photo_modal.'
            <div>
            <img id="photo_'.$myrow['photo_id'].'" width="100%" src="/photo/'.$myrow['photo_name'].'.jpg" />
            <div style="padding:15px; height:60px; background:#f5f5f5; border-bottom:1px solid #e1e1e8;">
                <div style="width:50%; float:left;">
                    <div style="float:left;">
                        <a href="/id'.$myrow['user_id'].'"><img id="id_top_avatar" width="30" height="30" src="'.$avatar.'" style="border-radius:100px;"></a>
                    </div>
                    <div style="float:left; padding-left:10px;">
                        <a href="/id'.$myrow['user_id'].'">'.$info_firstname.$user_online.'</a>
                        <br>
                        <span style="font-size:11px; color:#777;">'.$date.'</span>
                    </div>
                </div>
                <div style="width:50%; float:left;" onselectstart="return false" onmousedown="return false">
                    <div style="float:right;">
                        '.$likes_heart.'
                        <span style="color:#2B587A; margin-left:5px;">'.$lang[123].'</span>
                        '.$likes_count.'
                    </div>
                    <span id="popover_1_'.$myrow['photo_id'].'" data-toggle="tooltip" data-placement="top" data-html="true" title="'.$likes_body.'" onclick="object_id='.$myrow['photo_id'].'; object_type=1; more=false; page=1; like_peoples();" onmouseover="$(\'#popover_1_'.$myrow['photo_id'].'\').tooltip(\'show\');" onmouseout="$(\'#popover_1_'.$myrow['photo_id'].'\').tooltip(\'hide\');" style="float:right; font-size:12px; color:#b4cee2; margin-right:10px; cursor:pointer; display:'.$display_likes.';">&bull;&bull;&bull;</span>
                </div>
            </div>
            </div>
            ';
        }
        
        if ($arr_photo=='') { $arr_photo = $arr_photo.$myrow['photo_id']; } else { $arr_photo = $arr_photo.','.$myrow['photo_id']; }
        $photo_id++;
        }
    }

    if ($count_friends>0) {
        $friends_body = '';
        $result = mysql_query("SELECT friend_id FROM friends WHERE user_id='$uid' and status='1' ORDER BY RAND(), friend_id LIMIT 0, 6"); 
        while ( $myrow = mysql_fetch_array($result) )
        {
            $friend_id = $myrow['friend_id'];
            $z_friend = mysql_query("SELECT * FROM users WHERE id='$friend_id'");
            $o_friend = mysql_fetch_array($z_friend);
            $friend_firstname = $o_friend['firstname'];
            $user_avatar = $o_friend['avatar'];
            $user_sex = $o_friend['sex'];
            
            $rand = rand(10000, 99999);
            if ($user_avatar==0) {
                if ($user_sex==1) { $avatar = '/img/no_photo/girl.png?r='.$rand; }
                if ($user_sex==2) { $avatar = '/img/no_photo/boy.png?r='.$rand; }
            } else {
                $avatar = '/avatar/'.$friend_id.'.jpg?r='.$rand;
            }
                
            $friends_body = $friends_body.'
            <div style="width:33%; text-align:center; float:left;">
                <a href="/id'.$friend_id.'"><img width="45" height="45" src="'.$avatar.'" style="border-radius:100px;"/></a>
                <p><a href="/id'.$friend_id.'" style="font-size:11px;">'.$friend_firstname.'</a></p>
            </div>
            ';
        }
    } else {
        $friends_body = '<p style="text-align:center; margin-bottom:20px;">'.$lang[124].'</p>';
    }

    if ($count_photos>0) {
        $photos_body = '';
        $photos_arr = Array();
        $pi = 0;
        $result = mysql_query("SELECT * FROM photo_to_users WHERE user_id='$uid' and photo_type='1' and live='1' ORDER BY photo_id DESC"); 
        while ( $myrow = mysql_fetch_array($result) )
        {
            $photos_arr[$pi] = '
            <div style="width:33%; text-align:center; float:left; margin-bottom:15px;">
                <div style="width:45px; height:45px; margin-left:calc((100% - 45px) / 2); background-image:url(\'/photo/m_'.$myrow['photo_name'].'.jpg\'); background-size:cover; background-position:center top; cursor:pointer; border-radius:4px;" onclick="photo_id=#photo_id; photo_show();"></div>
            </div>#photo_number'.$pi;
            $pi++;
        }
        shuffle($photos_arr);
        for ($pi=0; $pi<6; $pi++) {
            $arr_photo_num = explode('#photo_number', $photos_arr[$pi]);
            $photos_arr[$pi] = str_replace('#photo_id', $arr_photo_num[1], $arr_photo_num[0]);
            $photos_body = $photos_body.$photos_arr[$pi];
        }
    } else {
        $photos_body = '<p style="text-align:center; margin-bottom:20px;">'.$lang[125].'</p>';
    }

    $z_user_online = mysql_query("SELECT time FROM users_to_online WHERE user_id='$uid'");
    $o_user_online = mysql_fetch_array($z_user_online);
    $user_online = $o_user_online['time'];
    $last_time_online = date("d.m.Y в H:i", $user_online);
    $this_date = date('U');
    if ($user_online>($this_date-60)) {
        $user_online = true;
    } else {
        $user_online = false;
    }
    
    if ($user_online) {
        $text_online = $lang[126];
    } else {
        if ($user_sex==1) {
            $text_online = $lang[127].' '.$last_time_online;
        } else {
            $text_online = $lang[128].' '.$last_time_online;
        }
    }

    if ($my_id and $my_id!==$uid) {
        $z_live_visit = mysql_query("SELECT visits_id FROM visits WHERE user_id='$my_id' and page_id='$uid'");
        $o_live_visit = mysql_fetch_array($z_live_visit);
        $live_visit = $o_live_visit['visits_id'];
        
        $time = date('U');
        if (!$live_visit) {
            mysql_query("INSERT visits SET user_id='$my_id', page_id='$uid', time='$time', status='1'");
        } else {
            mysql_query("UPDATE visits SET status='1', time='$time' WHERE user_id='$my_id' and page_id='$uid'");
        }
    }

    $z_count_otvety = mysql_query("SELECT * FROM news WHERE user_to='$my_id'");
    $count_otvety = mysql_num_rows($z_count_otvety);
    
    if ($my_id!==$uid) {
        $z_live_friend = mysql_query("SELECT user_id FROM friends WHERE user_id='$my_id' and friend_id='$uid' and status='1'");
        $o_live_friend = mysql_fetch_array($z_live_friend);
        $live_friend = $o_live_friend['user_id'];
    } else {
        $live_friend = false;
    }
}

mysql_close($msconnect);

$global_rand = rand(100000, 999999);
$title = $info_firstname.' '.$info_lastname;
?>
<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta name="description" content="">
        <meta name="author" content="">
        <title><?php echo $title; ?></title>
        <meta name="description" content="<?php echo $description; ?>" />
        <meta name="keywords" content="<?php echo $keywords; ?>" />
        <link href="/img/favicon.png" rel="shortcut icon" type="image/x-icon" />    
        <link rel="stylesheet" type="text/css" href="/css/bootstrap.css?r=<?php echo $global_rand; ?>" />
        <link rel="stylesheet" type="text/css" href="/css/jcrop.css?r=<?php echo $global_rand; ?>" />
        <link rel="stylesheet" type="text/css" href="/slick/slick.css?r=<?php echo $global_rand; ?>">
        <link rel="stylesheet" type="text/css" href="/slick/slick-theme.css?r=<?php echo $global_rand; ?>">
        <link rel="stylesheet" type="text/css" href="//fonts.googleapis.com/css?family=Lobster" />
        <link rel="stylesheet" type="text/css" href="/icon/style.css?r=<?php echo $global_rand; ?>" />
        <script>
        var uid = <?php echo $uid; ?>;
        var my_id = <?php if ($my_id) { echo $my_id; } else { echo 0; } ?>;
        var sex_name = '<?php echo $sex_name; ?>';
        var show_photo = true;
        var count_photos = <?php echo $count_photos; ?>;
        var live_uploads = <?php if ($uid==$my_id) { echo 'true'; } else { echo 'false'; } ?>;
        <?php if ($my_id):?>var otvety_count = <?php echo $count_otvety; ?>;<?php endif;?>
        <?php if ($arr_photo!==''):?>var photo_ids = [<?php echo $arr_photo; ?>];<?php endif;?>
        <?php if ($my_id):?>var tokens = ['<?php echo md5($my_id.'_wall_'.$secret);?>', '<?php echo md5($my_id.'_avatar_'.$secret);?>', '<?php echo md5($my_id.'_photo_'.$secret);?>', '<?php echo md5($my_id.'_'.$uid.'_sendcomment_'.$secret); ?>', '<?php echo md5($my_id.'_'.$uid.'_sendwall_'.$secret); ?>', '<?php echo md5($my_id.'_comment_'.$secret);?>', '<?php echo md5($my_id.'_delavatar_'.$secret); ?>', '<?php echo md5($my_id.'_editstatus_'.$secret); ?>', '<?php echo md5($my_id.'_resizeavatar_'.$secret); ?>'];<?php endif;?>
        </script>
    </head>
    <body role="document">
        <?php include $_SERVER['DOCUMENT_ROOT'].'/templates/header_user.tpl'; ?>
        <div class="container" style="margin-top:70px; margin-bottom:20px;">
            <div class="row">
                <div class="col-md-2" style="padding-bottom:15px;">
                <?php include $_SERVER['DOCUMENT_ROOT'].'/templates/user_left_menu.tpl'; ?>
                </div>    
                <?php if ($info_id):?>                
                <div class="col-md-10">
                    <div style="padding:20px; background-color:#ffffff; border:1px solid #e1e1e8; border-radius:4px; margin-bottom:20px;"> 
                        <div class="row">                    
                            <div class="col-md-2" style="text-align:center;">
                                <img id="id_avatar" <?php if ($uid==$my_id):?>data-toggle="tooltip" data-placement="top" title="<?php echo $lang[193]; ?>"<?php endif;?> width="100" height="100" src="<?php echo $page_avatar; ?>" style="border-radius:100px; <?php if ($uid==$my_id):?>cursor:pointer;<?php endif;?>" <?php if ($uid==$my_id):?>onClick="upload_avatar();" onMouseOver="$('#id_avatar').tooltip('show');" onMouseOut="$('#id_avatar').tooltip('hide');"<?php endif;?> />
                            </div>                    
                            <div class="col-md-3" style="text-align:center; padding-top:15px;">
                                <h4 style="margin:0px;"><?php echo $info_firstname; if ($user_online) { echo ' <span class="icon-lamp" style="color:#46af48; font-size:17px;"></span>'; } ?></h4>
                                <span style="color:#777; font-size:11px; line-height:1.5;"><?php echo $text_online; ?></span><br>
                                <?php if ($info_status!==''):?>
                                <p id="status_body" style="height:0px;"></p>
                                <span id="id_status_text" <?php if ($uid==$my_id):?>style="cursor:pointer;" onClick="status_edit();"<?php endif;?>><?php echo $info_status; ?></span>
                                <?php endif;?>
                            </div>                        
                            <div class="col-md-4">
                                <div class="row">
                                    <div style="width:33%; text-align:center; padding-top:15px; float:left;">
                                        <h4 style="color:#2B587A; margin:0px;"><?php echo $count_friends; ?></h4>
                                        <p style="font-size:11px;"><?php echo $lang[129]; ?></p>
                                    </div>
                                    <div style="width:33%; text-align:center; padding-top:15px; float:left;">
                                        <h4 style="color:#2B587A; margin:0px;"><?php echo $count_photos; ?></h4>
                                        <p style="font-size:11px;"><?php echo $lang[130]; ?></p>
                                    </div>
                                    <div style="width:33%; text-align:center; padding-top:15px; float:left;">
                                        <h4 style="color:#2B587A; margin:0px;"><?php echo $count_wall; ?></h4>
                                        <p style="font-size:11px;"><?php echo $lang[131]; ?></p>
                                    </div>
                                </div>
                            </div>                        
                            <div class="col-md-3" style="text-align:center; padding-top:15px;">
                            <?php if ($my_id):?>
                                <?php if ($uid==$my_id):?>
                                <a href="/<?php echo $link[5]; ?>"><button type="button" class="btn btn-primary" style="width:100%;" onclick=""><?php echo $lang[132]; ?></button></a>
                                <a href="/<?php echo $link[6]; ?>"><button type="button" class="btn btn-primary" style="width:100%; margin-top:10px;"><?php echo $lang[133]; ?></button></a>
                                <?php endif;?>
                                <?php if ($uid!==$my_id):?>
                                    <?php if (!$live_friend):?>
                                    <button type="button" class="btn btn-primary" style="width:100%;" onclick="friend_id=<?php echo $uid; ?>; token='<?php echo md5($my_id.'_'.$uid.'_addfriend_'.$secret); ?>'; add_friend();"><?php echo $lang[134]; ?></button>
                                    <?php endif;?>
                                    <?php if ($live_friend):?>
                                    <button type="button" class="btn btn-primary" style="width:100%;" onclick="friend_id=<?php echo $uid; ?>; token='<?php echo md5($my_id.'_'.$uid.'_deleteallfriends_'.$secret); ?>'; del_friend();"><?php echo $lang[135]; ?></button>
                                    <?php endif;?>
                                <a href="/<?php echo $link[2]; ?>?id=<?php echo $uid; ?>"><button type="button" class="btn btn-primary" style="width:100%; margin-top:10px;"><?php echo $lang[136]; ?></button></a>
                                <?php endif;?>
                            <?php endif;?>
                            <?php if (!$my_id):?>
                            <a href="/<?php echo $link[3]; ?>"><button type="button" class="btn btn-primary" style="width:100%;"><?php echo $lang[137]; ?></button></a>
                            <?php endif;?>
                            </div>
                        </div>
                        <?php if ($count_photos==0):?>
                            <?php if ($uid==$my_id):?>
                            <p style="padding:15px; background:#f5f5f5; border-radius:4px; margin-top:15px; text-align:center;"><?php echo $lang[138]; ?></p>
                            <?php endif;?>
                            <?php if ($uid!==$my_id):?>
                            <p style="padding:15px; background:#f5f5f5; border-radius:4px; margin-top:15px; text-align:center;"><?php echo $lang[139]; ?> <b><?php echo $info_firstname; ?> <?php echo $info_lastname; ?></b> <?php echo $lang[140]; ?>.</p>
                            <?php endif;?>
                        <?php endif;?>
                        <section id="slider_block" class="regular slider" style="margin-top:15px; display:none;">
                            <?php echo $photo_slide; ?>
                        </section>
                        <div id="upload_photoslide" class="row" style="margin:0px; margin-top:12px; <?php if ($uid==$my_id):?>display:none;<?php endif;?>">
                            <?php if ($uid==$my_id):?>
                            <div id="id_upload_foto_status" style="width:25%; float:left;"></div>
                            <?php endif;?>
                            <?php if ($count_photos>0):?>
                            <div style="<?php if ($uid==$my_id):?>width:75%;<?php endif;?> float:right; text-align:right;"><a href="/<?php echo $link[8]; ?>?id=<?php echo $uid; ?>" style="line-height:1.6;"><?php echo $lang[141]; ?></a></div>
                            <?php endif;?>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-md-3">
                            <div style="padding:20px; padding-bottom:0px; padding-top:7px; background-color:#ffffff; border:1px solid #e1e1e8; border-radius:4px; margin-bottom:20px;">
                                <div class="header-title-bg" style="margin-top:-7px;">
                                <?php if ($uid==$my_id):?>
                                    <a href="/<?php echo $link[1]; ?>"><?php echo $lang[142]; ?> <b><?php echo $count_friends; ?></b></a>
                                <?php endif;?>
                                <?php if ($uid!==$my_id):?>
                                    <a href="/<?php echo $link[1]; ?>?id=<?php echo $uid; ?>"><?php echo $lang[142]; ?> <b><?php echo $count_friends; ?></b></a>
                                <?php endif;?>
                                </div>
                                <div class="row" style="margin-top:55px;">
                                    <?php echo $friends_body; ?>
                                </div>
                            </div>
                            <div style="padding:20px; padding-bottom:0px; padding-top:7px; background-color:#ffffff; border:1px solid #e1e1e8; border-radius:4px; margin-bottom:20px;">
                                <div class="header-title-bg" style="margin-top:-7px;">
                                <?php if ($uid==$my_id):?>
                                    <a href="/<?php echo $link[8]; ?>"><?php echo $lang[143]; ?> <b><?php echo $count_photos; ?></b></a>
                                <?php endif;?>
                                <?php if ($uid!==$my_id):?>
                                    <a href="/<?php echo $link[8]; ?>?id=<?php echo $uid; ?>"><?php echo $lang[144]; ?> <b><?php echo $count_photos; ?></b></a>
                                <?php endif;?>
                                </div>
                                <div class="row" style="margin-top:55px;">
                                    <?php echo $photos_body; ?>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-9">        
                            <div style="padding:20px; padding-bottom:0px; padding-top:7px; background-color:#ffffff; border:1px solid #e1e1e8; border-radius:4px; margin-bottom:20px;">    
                            <div class="header-title-bg" style="margin-top:-7px;">
                                <?php echo $lang[145]; ?>
                            </div>
                                <div class="row" style="padding-top:50px; padding-bottom:15px;">
                                    <div class="col-md-6">                    
                                        <h6><b><?php echo $lang[146]; ?></b><?php if ($uid==$my_id):?><a href="/<?php echo $link[5]; ?>" class="icon-pencil" style="color:#999; float:right;"></a></h6><?php endif;?>
                                        <hr style="margin-top:5px; margin-bottom:5px;">
                                        <div class="row">
                                            <div class="col-md-6">
                                                <p style="color:#999;"><?php echo $lang[147]; ?>:</p>
                                            </div>
                                            <div class="col-md-6">
                                                <p><?php echo $info_firstday; ?></p>
                                            </div>
                                        </div>
                                        <div class="row">
                                            <div class="col-md-6">
                                                <p style="color:#999;"><?php echo $lang[148]; ?>:</p>
                                            </div>
                                            <div class="col-md-6">
                                                <p><?php echo $location_value; ?></p>
                                            </div>
                                        </div>
                                        <div class="row">
                                            <div class="col-md-6">
                                                <p style="color:#999;"><?php echo $lang[149]; ?>:</p>
                                            </div>
                                            <div class="col-md-6">
                                                <p><?php echo $info_marital_status; ?></p>
                                            </div>
                                        </div>                    
                                    </div>
                                    <div class="col-md-6">                    
                                    <h6><b><?php echo $lang[150]; ?>:</b><?php if ($uid==$my_id):?><a href="/<?php echo $link[5]; ?>" class="icon-pencil" style="color:#999; float:right;"></a></h6><?php endif;?>
                                    <hr style="margin-top:5px; margin-bottom:5px;">
                                    <div class="row">
                                        <div class="col-md-6">
                                            <p style="color:#999;"><?php echo $lang[151]; ?>:</p>
                                        </div>
                                        <div class="col-md-6">
                                            <p><?php echo $info_phone; ?></p>
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="col-md-6">
                                            <p style="color:#999;"><?php echo $lang[152]; ?>:</p>
                                        </div>
                                        <div class="col-md-6">
                                            <p><?php echo $info_skype; ?></p>
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="col-md-6">
                                            <p style="color:#999;"><?php echo $lang[153]; ?>:</p>
                                        </div>
                                        <div class="col-md-6">
                                            <p><?php echo $info_site; ?></p>
                                        </div>
                                    </div>
                                                        
                                    </div>
                                </div>
                                <?php if ($live_acordion):?>
                                <div class="panel-group" id="accordion">
                                    <div class="panel panel-default" style="border:0px; text-align:center;">
                                        <div class="panel-heading" style="border-radius:4px;">
                                            <a data-toggle="collapse" data-parent="#accordion" href="#fullinfo" class="collapsed">
                                                <?php echo $lang[154]; ?>
                                            </a>
                                        </div>
                                        <div id="fullinfo" class="panel-collapse collapse" style="height: 0px;">
                                        <?php if ($info_activity || $info_interests || $info_music || $info_movies || $info_tv || $info_books || $info_games || $info_about):?>
                                            <div class="panel-body" style="border:0px; padding:0px; text-align:left;">            
                                                <h6><b><?php echo $lang[155]; ?></b><?php if ($uid==$my_id):?><a href="/<?php echo $link[5]; ?>" class="icon-pencil" style="color:#999; float:right;"></a></h6><?php endif;?>
                                                <hr style="margin-top:5px; margin-bottom:5px;">
                                                <?php if ($info_activity):?>
                                                <div class="row">
                                                    <div class="col-md-3">
                                                        <p style="color:#999;"><?php echo $lang[156]; ?>:</p>
                                                    </div>
                                                    <div class="col-md-9">
                                                        <p><?php echo $info_activity; ?></p>
                                                    </div>
                                                </div>
                                                <?php endif;?>
                                                <?php if ($info_interests):?>
                                                <div class="row" style="margin-top:5px;">
                                                    <div class="col-md-3">
                                                        <p style="color:#999;"><?php echo $lang[157]; ?>:</p>
                                                    </div>
                                                    <div class="col-md-9">
                                                        <p><?php echo $info_interests; ?></p>
                                                    </div>
                                                </div>
                                                <?php endif;?>
                                                <?php if ($info_music):?>
                                                <div class="row" style="margin-top:5px;">
                                                    <div class="col-md-3">
                                                        <p style="color:#999;"><?php echo $lang[158]; ?>:</p>
                                                    </div>
                                                    <div class="col-md-9">
                                                        <p><?php echo $info_music; ?></p>
                                                    </div>
                                                </div>
                                                <?php endif;?>
                                                <?php if ($info_movies):?>
                                                <div class="row" style="margin-top:5px;">
                                                    <div class="col-md-3">
                                                        <p style="color:#999;"><?php echo $lang[159]; ?>:</p>
                                                    </div>
                                                    <div class="col-md-9">
                                                        <p><?php echo $info_movies; ?></p>
                                                    </div>
                                                </div>
                                                <?php endif;?>
                                                <?php if ($info_tv):?>
                                                <div class="row" style="margin-top:5px;">
                                                    <div class="col-md-3">
                                                        <p style="color:#999;"><?php echo $lang[160]; ?>:</p>
                                                    </div>
                                                    <div class="col-md-9">
                                                        <p><?php echo $info_tv; ?></p>
                                                    </div>
                                                </div>
                                                <?php endif;?>
                                                <?php if ($info_books):?>
                                                <div class="row" style="margin-top:5px;">
                                                    <div class="col-md-3">
                                                        <p style="color:#999;"><?php echo $lang[161]; ?>:</p>
                                                    </div>
                                                    <div class="col-md-9">
                                                        <p><?php echo $info_books; ?></p>
                                                    </div>
                                                </div>
                                                <?php endif;?>
                                                <?php if ($info_games):?>
                                                <div class="row" style="margin-top:5px;">
                                                    <div class="col-md-3">
                                                        <p style="color:#999;"><?php echo $lang[162]; ?>:</p>
                                                    </div>
                                                    <div class="col-md-9">
                                                        <p><?php echo $info_games; ?></p>
                                                    </div>
                                                </div>
                                                <?php endif;?>
                                                <?php if ($info_quotations):?>
                                                <div class="row" style="margin-top:5px;">
                                                    <div class="col-md-3">
                                                        <p style="color:#999;"><?php echo $lang[163]; ?>:</p>
                                                    </div>
                                                    <div class="col-md-9">
                                                        <p><?php echo $info_quotations; ?></p>
                                                    </div>
                                                </div>
                                                <?php endif;?>
                                                <?php if ($info_about):?>
                                                <div class="row" style="margin-top:5px;">
                                                    <div class="col-md-3">
                                                        <p style="color:#999;"><?php echo $lang[164]; ?>:</p>
                                                    </div>
                                                    <div class="col-md-9">
                                                        <p><?php echo $info_about; ?></p>
                                                    </div>
                                                </div>
                                                <?php endif;?>
                                            </div>
                                        <?php endif;?>
                                        <?php if ($info_institut || $info_department || $info_start_training || $info_finish_training || $info_education_info):?>
                                            <div class="panel-body" style="border:0px; padding:0px; text-align:left;">            
                                                <h6><b><?php echo $lang[165]; ?></b><?php if ($uid==$my_id):?><a href="/<?php echo $link[5]; ?>" class="icon-pencil" style="color:#999; float:right;"></a></h6><?php endif;?>
                                                <hr style="margin-top:5px; margin-bottom:5px;">
                                                <?php if ($info_institut):?>
                                                <div class="row">
                                                    <div class="col-md-3">
                                                        <p style="color:#999;"><?php echo $lang[166]; ?>:</p>
                                                    </div>
                                                    <div class="col-md-9">
                                                        <p><?php echo $info_institut; ?></p>
                                                    </div>
                                                </div>
                                                <?php endif;?>
                                                <?php if ($info_department):?>
                                                <div class="row" style="margin-top:5px;">
                                                    <div class="col-md-3">
                                                        <p style="color:#999;"><?php echo $lang[167]; ?>:</p>
                                                    </div>
                                                    <div class="col-md-9">
                                                        <p><?php echo $info_department; ?></p>
                                                    </div>
                                                </div>
                                                <?php endif;?>
                                                <?php if ($info_start_training || $info_finish_training):?>
                                                <div class="row" style="margin-top:5px;">
                                                    <div class="col-md-3">
                                                        <p style="color:#999;"><?php echo $lang[168]; ?>:</p>
                                                    </div>
                                                    <div class="col-md-9">
                                                        <?php if ($info_start_training and  $info_finish_training):?>
                                                        <p><?php echo $lang[169]; ?> <?php echo $info_start_training; ?> <?php echo $lang[170]; ?> <?php echo $info_finish_training; ?> <?php echo $lang[171]; ?></p>
                                                        <?php endif;?>
                                                        <?php if ($info_start_training and  !$info_finish_training):?>
                                                        <p><?php echo $lang[172]; ?> <?php echo $info_start_training; ?> <?php echo $lang[173]; ?></p>
                                                        <?php endif;?>
                                                        <?php if (!$info_start_training and  $info_finish_training):?>
                                                        <p><?php echo $lang[174]; ?> <?php echo $info_finish_training; ?> <?php echo $lang[175]; ?></p>
                                                        <?php endif;?>
                                                    </div>
                                                </div>
                                                <?php endif;?>
                                                <?php if ($info_education_info):?>
                                                <div class="row" style="margin-top:5px;">
                                                    <div class="col-md-3">
                                                        <p style="color:#999;"><?php echo $lang[176]; ?>:</p>
                                                    </div>
                                                    <div class="col-md-9">
                                                        <p><?php echo $info_education_info; ?></p>
                                                    </div>
                                                </div>
                                                <?php endif;?>
                                            </div>
                                        <?php endif;?>
                                        <?php if ($info_place_work || $info_position || $info_work_info):?>
                                            <div class="panel-body" style="border:0px; padding:0px; text-align:left;">            
                                                <h6><b><?php echo $lang[177]; ?></b><?php if ($uid==$my_id):?><a href="/<?php echo $link[5]; ?>" class="icon-pencil" style="color:#999; float:right;"></a></h6><?php endif;?>
                                                <hr style="margin-top:5px; margin-bottom:5px;">
                                                <?php if ($info_place_work):?>
                                                <div class="row">
                                                    <div class="col-md-3">
                                                        <p style="color:#999;"><?php echo $lang[178]; ?>:</p>
                                                    </div>
                                                    <div class="col-md-9">
                                                        <p><?php echo $info_place_work; ?></p>
                                                    </div>
                                                </div>
                                                <?php endif;?>
                                                <?php if ($info_position):?>
                                                <div class="row" style="margin-top:5px;">
                                                    <div class="col-md-3">
                                                        <p style="color:#999;"><?php echo $lang[179]; ?>:</p>
                                                    </div>
                                                    <div class="col-md-9">
                                                        <p><?php echo $info_position; ?></p>
                                                    </div>
                                                </div>
                                                <?php endif;?>
                                                <?php if ($info_work_info):?>
                                                <div class="row" style="margin-top:5px;">
                                                    <div class="col-md-3">
                                                        <p style="color:#999;"><?php echo $lang[180]; ?>:</p>
                                                    </div>
                                                    <div class="col-md-9">
                                                        <p><?php echo $info_work_info; ?></p>
                                                    </div>
                                                </div>
                                                <?php endif;?>
                                            </div>
                                        <?php endif;?>
                                        <?php if ($info_policy || $info_world_view || $info_important_live || $info_important_peoples || $info_smoking || $info_alcohol || $info_inspirations):?>
                                            <div class="panel-body" style="border:0px; padding:0px; text-align:left;">            
                                                <h6><b><?php echo $lang[181]; ?></b><?php if ($uid==$my_id):?><a href="/<?php echo $link[5]; ?>" class="icon-pencil" style="color:#999; float:right;"></a></h6><?php endif;?>
                                                <hr style="margin-top:5px; margin-bottom:5px;">
                                                <?php if ($info_policy):?>
                                                <div class="row">
                                                    <div class="col-md-3">
                                                        <p style="color:#999;"><?php echo $lang[182]; ?>:</p>
                                                    </div>
                                                    <div class="col-md-9">
                                                        <p><?php echo $info_policy; ?></p>
                                                    </div>
                                                </div>
                                                <?php endif;?>
                                                <?php if ($info_world_view):?>
                                                <div class="row" style="margin-top:5px;">
                                                    <div class="col-md-3">
                                                        <p style="color:#999;"><?php echo $lang[183]; ?>:</p>
                                                    </div>
                                                    <div class="col-md-9">
                                                        <p><?php echo $info_world_view; ?></p>
                                                    </div>
                                                </div>
                                                <?php endif;?>
                                                <?php if ($info_important_live):?>
                                                <div class="row" style="margin-top:5px;">
                                                    <div class="col-md-3">
                                                        <p style="color:#999;"><?php echo $lang[184]; ?>:</p>
                                                    </div>
                                                    <div class="col-md-9">
                                                        <p><?php echo $info_important_live; ?></p>
                                                    </div>
                                                </div>
                                                <?php endif;?>
                                                <?php if ($info_important_peoples):?>
                                                <div class="row" style="margin-top:5px;">
                                                    <div class="col-md-3">
                                                        <p style="color:#999;"><?php echo $lang[185]; ?>:</p>
                                                    </div>
                                                    <div class="col-md-9">
                                                        <p><?php echo $info_important_peoples; ?></p>
                                                    </div>
                                                </div>
                                                <?php endif;?>
                                                <?php if ($info_smoking):?>
                                                <div class="row" style="margin-top:5px;">
                                                    <div class="col-md-3">
                                                        <p style="color:#999;"><?php echo $lang[186]; ?>:</p>
                                                    </div>
                                                    <div class="col-md-9">
                                                        <p><?php echo $info_smoking; ?></p>
                                                    </div>
                                                </div>
                                                <?php endif;?>
                                                <?php if ($info_alcohol):?>
                                                <div class="row" style="margin-top:5px;">
                                                    <div class="col-md-3">
                                                        <p style="color:#999;"><?php echo $lang[187]; ?>:</p>
                                                    </div>
                                                    <div class="col-md-9">
                                                        <p><?php echo $info_alcohol; ?></p>
                                                    </div>
                                                </div>
                                                <?php endif;?>
                                                <?php if ($info_inspirations):?>
                                                <div class="row" style="margin-top:5px;">
                                                    <div class="col-md-3">
                                                        <p style="color:#999;"><?php echo $lang[188]; ?>:</p>
                                                    </div>
                                                    <div class="col-md-9">
                                                        <p><?php echo $info_inspirations; ?></p>
                                                    </div>
                                                </div>
                                                <?php endif;?>
                                            </div>
                                            <?php endif;?>
                                        </div>
                                    </div>
                                </div>
                                <?php endif;?>                                
                            </div>
                            <div style="padding:15px; padding-top:7px; background-color:#ffffff; border:1px solid #e1e1e8; border-radius:4px; margin-bottom:20px; padding-bottom:0px;">    
                                <div class="header-title-bg" style="margin-top:-7px; margin-left:-15px;">
                                    <?php echo $lang[189]; ?> <b><?php echo $count_wall; ?></b>
                                </div>
                                <div class="row" style="padding:0px; padding-top:40px;">
                                    <?php if ($my_id):?>
                                    <div style="padding:15px; background:#f5f5f5;">
                                        <div style="float:left;">
                                            <a href="/id<?php echo $my_id; ?>"><img width="30" height="30" src="<?php echo $page_avatar; ?>" style="border-radius:100px;"></a>
                                        </div>
                                        <div style="width:calc(100% - 30px); float:left; padding-left:10px;">
                                            <textarea id="id_wall" placeholder="<?php echo $lang[190]; ?>" style="height:33px; width:100%; padding:7px; resize:none; border:1px solid #e1e1e8;" onClick="this.style.height='70px';"></textarea>
                                            <div id="upload_wall_results"></div>
                                            <div id="id_upload_wall_status" style="width:30%; float:left; padding-top:15px;"></div>
                                            <div style="width:70%; float:left; padding-top:10px;">
                                                <button type="button" class="btn btn-primary" onclick="token='<?php echo md5($my_id.'_'.$uid.'_sendwall_'.$secret); ?>'; send_wall();" style="float:right;"><?php echo $lang[191]; ?></button>
                                                <span id="id_open_smiles_wall" data-toggle="popover" data-html="true" data-placement="top" data-content="<div><img width='20' height='20' src='/img/smiles/m_1.png' style='margin:2px; cursor:pointer;' onClick='smile_id=1; add_smile_wall();' /><img  width='20' height='20' src='/img/smiles/m_2.png' style='margin:2px; cursor:pointer;' onClick='smile_id=2; add_smile_wall();' /><img  width='20' height='20' src='/img/smiles/m_3.png' style='margin:2px; cursor:pointer;' onClick='smile_id=3; add_smile_wall();' /><img  width='20' height='20' src='/img/smiles/m_4.png' style='margin:2px; cursor:pointer;' onClick='smile_id=4; add_smile_wall();' /><img  width='20' height='20' src='/img/smiles/m_5.png' style='margin:2px; cursor:pointer;' onClick='smile_id=5; add_smile_wall();' /><img  width='20' height='20' src='/img/smiles/m_6.png' style='margin:2px; cursor:pointer;' onClick='smile_id=6; add_smile_wall();' /><img  width='20' height='20' src='/img/smiles/m_7.png' style='margin:2px; cursor:pointer;' onClick='smile_id=7; add_smile_wall();' /></div><div><img width='20' height='20' src='/img/smiles/m_8.png' style='margin:2px; cursor:pointer;' onClick='smile_id=8; add_smile_wall();' /><img  width='20' height='20' src='/img/smiles/m_9.png' style='margin:2px; cursor:pointer;' onClick='smile_id=9; add_smile_wall();' /><img  width='20' height='20' src='/img/smiles/m_10.png' style='margin:2px; cursor:pointer;' onClick='smile_id=10; add_smile_wall();' /><img  width='20' height='20' src='/img/smiles/m_11.png' style='margin:2px; cursor:pointer;' onClick='smile_id=11; add_smile_wall();' /><img  width='20' height='20' src='/img/smiles/m_12.png' style='margin:2px; cursor:pointer;' onClick='smile_id=12; add_smile_wall();' /><img  width='20' height='20' src='/img/smiles/m_13.png' style='margin:2px; cursor:pointer;' onClick='smile_id=13; add_smile_wall();' /><img  width='20' height='20' src='/img/smiles/m_14.png' style='margin:2px; cursor:pointer;' onClick='smile_id=14; add_smile_wall();' /></div><div><img width='20' height='20' src='/img/smiles/m_15.png' style='margin:2px; cursor:pointer;' onClick='smile_id=15; add_smile_wall();' /><img  width='20' height='20' src='/img/smiles/m_16.png' style='margin:2px; cursor:pointer;' onClick='smile_id=16; add_smile_wall();' /><img  width='20' height='20' src='/img/smiles/m_17.png' style='margin:2px; cursor:pointer;' onClick='smile_id=17; add_smile_wall();' /><img  width='20' height='20' src='/img/smiles/m_18.png' style='margin:2px; cursor:pointer;' onClick='smile_id=18; add_smile_wall();' /><img  width='20' height='20' src='/img/smiles/m_19.png' style='margin:2px; cursor:pointer;' onClick='smile_id=19; add_smile_wall();' /><img  width='20' height='20' src='/img/smiles/m_20.png' style='margin:2px; cursor:pointer;' onClick='smile_id=20; add_smile_wall();' /><img  width='20' height='20' src='/img/smiles/m_21.png' style='margin:2px; cursor:pointer;' onClick='smile_id=21; add_smile_wall();' /></div><div><img width='20' height='20' src='/img/smiles/m_22.png' style='margin:2px; cursor:pointer;' onClick='smile_id=22; add_smile_wall();' /><img  width='20' height='20' src='/img/smiles/m_23.png' style='margin:2px; cursor:pointer;' onClick='smile_id=23; add_smile_wall();' /><img  width='20' height='20' src='/img/smiles/m_24.png' style='margin:2px; cursor:pointer;' onClick='smile_id=24; add_smile_wall();' /><img  width='20' height='20' src='/img/smiles/m_25.png' style='margin:2px; cursor:pointer;' onClick='smile_id=25; add_smile_wall();' /><img  width='20' height='20' src='/img/smiles/m_26.png' style='margin:2px; cursor:pointer;' onClick='smile_id=26; add_smile_wall();' /><img  width='20' height='20' src='/img/smiles/m_27.png' style='margin:2px; cursor:pointer;' onClick='smile_id=27; add_smile_wall();' /><img  width='20' height='20' src='/img/smiles/m_28.png' style='margin:2px; cursor:pointer;' onClick='smile_id=28; add_smile_wall();' /></div><div><img width='20' height='20' src='/img/smiles/m_29.png' style='margin:2px; cursor:pointer;' onClick='smile_id=29; add_smile_wall();' /><img  width='20' height='20' src='/img/smiles/m_30.png' style='margin:2px; cursor:pointer;' onClick='smile_id=30; add_smile_wall();' /><img  width='20' height='20' src='/img/smiles/m_31.png' style='margin:2px; cursor:pointer;' onClick='smile_id=31; add_smile_wall();' /><img  width='20' height='20' src='/img/smiles/m_32.png' style='margin:2px; cursor:pointer;' onClick='smile_id=32; add_smile_wall();' /><img  width='20' height='20' src='/img/smiles/m_33.png' style='margin:2px; cursor:pointer;' onClick='smile_id=33; add_smile_wall();' /><img  width='20' height='20' src='/img/smiles/m_34.png' style='margin:2px; cursor:pointer;' onClick='smile_id=34; add_smile_wall();' /><img  width='20' height='20' src='/img/smiles/m_35.png' style='margin:2px; cursor:pointer;' onClick='smile_id=35; add_smile_wall();' /></div>" class="icon-bird" style="color:#999; font-size:20px; float:right; margin-top:7px; margin-right:15px; cursor:pointer;" onmouseover="$('#id_open_smiles_wall').popover();" data-original-title="" title=""></span>
                                            </div>
                                        </div>
                                    </div>
                                    <div style="padding:15px; background:#f5f5f5; border-bottom:1px solid #e1e1e8;"><div class="row"></div></div>
                                    <?php endif;?>
                                    <div id="id_wall_body" style="padding:15px;"></div>
                                </div>
                            </div>                        
                        </div>
                    </div>
                </div>
                <?php endif;?>
                <?php if (!$info_id):?>
                <div class="col-md-10">
                    <div style="padding:20px; background-color:#ffffff; border:1px solid #e1e1e8; border-radius:4px; margin-bottom:20px;"> 
                        <p style="padding:15px; background:#f5f5f5; border-radius:4px; margin-bottom:0px; text-align:center;"><?php echo $lang[192]; ?></p>
                    </div>
                </div>
                <?php endif;?>
            </div>                        
        </div>            
        <?php if ($uid==$my_id) { include $_SERVER['DOCUMENT_ROOT'].'/modal/avatar.php'; } ?>
        <?php include $_SERVER['DOCUMENT_ROOT'].'/modal/photo.php'; ?>
        <?php include $_SERVER['DOCUMENT_ROOT'].'/modal/likes.php'; ?>
        <?php include $_SERVER['DOCUMENT_ROOT'].'/modal/visits.php'; ?>
        <?php include $_SERVER['DOCUMENT_ROOT'].'/modal/otvety.php'; ?>
        <?php include $_SERVER['DOCUMENT_ROOT'].'/modal/load_photo.php'; ?>
        
        
        <div class="talker">
        <div class="talker_message"></div>
        </div>            
        <?php include $_SERVER['DOCUMENT_ROOT'].'/templates/footer.tpl'; ?>    
        <script src="/uploadify/jquery.uploadifive.min.js?r=<?php echo $global_rand; ?>" type="text/javascript"></script>
        <script src="/js/jcrop.js?r=<?php echo $global_rand; ?>"></script>
        <script src="/slick/slick.js?r=<?php echo $global_rand; ?>" type="text/javascript" charset="utf-8"></script>
        <script type="text/javascript">
        onload = function() {
            <?php if ($my_id):?>init_upload_wall();<?php endif;?>
            page = 1;
            more = false;
            loadwall();
            <?php if ($my_id):?>ping_online();<?php endif;?>
            <?php if ($my_id and !$live_avatar):?>upload_avatar();<?php endif;?>
        }
        </script>
        <script src="/js/system/<?php echo $js_lang; ?>/user.js?r=<?php echo $global_rand; ?>" type="text/javascript"></script>
    </body>
</html>