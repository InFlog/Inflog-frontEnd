<?php
include $_SERVER['DOCUMENT_ROOT'].'/inc/config.php';
include $_SERVER['DOCUMENT_ROOT'].'/inc/login.php';
include $_SERVER['DOCUMENT_ROOT'].'/inc/sql_social.php';

$_GET['query'] = addslashes($_GET['query']);
$_GET['query'] = htmlspecialchars($_GET['query']);

$country_list = '<li><a onClick="document.getElementById(\'id_country\').innerHTML=this.innerHTML; document.getElementById(\'id_city\').innerHTML=\''.$lang[448].'\'; document.getElementById(\'city_block\').style.display=\'none\'; more=false; page=1; start_search();">'.$lang[448].'</a></li>';
$result = mysql_query("SELECT * FROM net_country ORDER BY name_$js_lang ASC"); 
while ( $myrow = mysql_fetch_array($result) )
{
$country_list = $country_list.'<li><a onClick="document.getElementById(\'id_country\').innerHTML=this.innerHTML; document.getElementById(\'id_city\').innerHTML=\''.$lang[448].'\'; $(\'#id_toolcountry\').tooltip(\'destroy\'); country_id=\''.$myrow['id'].'\'; start_city_list(); more=false; page=1; start_search();">'.$myrow['name_'.$js_lang].'</a></li>
';
}

$z_count_otvety = mysql_query("SELECT * FROM news WHERE user_to='$my_id'");
$count_otvety = mysql_num_rows($z_count_otvety);

$global_rand = rand(100000, 999999);
$title = $lang[445];
mysql_close($msconnect);
?>
<?php
include $_SERVER['DOCUMENT_ROOT'].'/functions/top_search.php';
include $_SERVER['DOCUMENT_ROOT'].'/functions/login.php';
include $_SERVER['DOCUMENT_ROOT'].'/functions/city_list_search.php';
include $_SERVER['DOCUMENT_ROOT'].'/functions/search.php';
include $_SERVER['DOCUMENT_ROOT'].'/functions/add_friends.php';
include $_SERVER['DOCUMENT_ROOT'].'/functions/ping_online.php';
include $_SERVER['DOCUMENT_ROOT'].'/functions/visits.php';
include $_SERVER['DOCUMENT_ROOT'].'/functions/otvety.php';


include $_SERVER['DOCUMENT_ROOT']."/inc/agent.php";
$agent->init();
?>
<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta name="description" content="">
        <meta name="author" content="">
        <title><?php echo $title; ?></title>
        <link href="/img/favicon.png" rel="shortcut icon" type="image/x-icon" />        
        <link rel="stylesheet" type="text/css" href="/css/bootstrap.css" />
        <link rel="stylesheet" type="text/css" href="/icon/style.css" />
    </head>
    <body role="document">
        <?php include $_SERVER['DOCUMENT_ROOT'].'/templates/header_user.tpl'; ?>
        <div class="container" style="margin-top:70px; margin-bottom:20px;">
            <div class="row" class="bs-example bs-example-tabs">
                <div class="col-md-2" style="padding-bottom:15px;">
                    <?php include $_SERVER['DOCUMENT_ROOT'].'/templates/user_left_menu.tpl'; ?>
                </div>                            
                <div class="col-md-3">
                    <div class="header-title-bg" style="margin-left:1px; margin-top:1px;">
                        <?php echo $lang[446]; ?>
                    </div>
                    <div style="padding:20px; background-color:#ffffff; border:1px solid #e1e1e8; border-radius:4px; margin-bottom:20px; padding-top:60px;">
                        <div class="form-group">
                            <label><?php echo $lang[447]; ?></label>
                            <div class="row" data-toggle="tooltip" data-placement="top" title="">
                                <div class="col-md-12">
                                    <b class="caret" style="position:absolute; margin-top:15px; margin-left:calc(100% - 50px); z-index:1000; cursor:pointer;"></b><div id="id_country" class="form-control" class="dropdown-toggle" data-toggle="dropdown" aria-expanded="true" style="height:34px; padding-top:8px; border:1px solid #ccc; cursor:pointer;"><?php echo $lang[448]; ?></div>
                                    <ul class="dropdown-menu" style="min-width:calc(100% - 30px); width:calc(100% - 30px); height:115px; margin-left:15px; margin-top:-1px; overflow-y:scroll; overflow-x:hidden; border-color:#CCC;">
                                        <?php echo $country_list; ?>
                                    </ul>
                                </div>
                            </div>
                        </div>
                        <div id="city_block" class="form-group" style="display:none;">
                            <label><?php echo $lang[449]; ?></label>
                            <div class="row" data-toggle="tooltip" data-placement="top" title="">
                                <div class="col-md-12">
                                    <b class="caret" style="position:absolute; margin-top:15px; margin-left:calc(100% - 50px); z-index:1000; cursor:pointer;"></b><div id="id_city" class="form-control" class="dropdown-toggle" data-toggle="dropdown" aria-expanded="true" style="height:34px; padding-top:8px; border:1px solid #ccc; cursor:pointer;"><?php echo $lang[450]; ?></div>
                                    <ul id="id_city_list" class="dropdown-menu" style="min-width:calc(100% - 30px); width:calc(100% - 30px); height:115px; margin-left:15px; margin-top:-1px; overflow-y:scroll; overflow-x:hidden; border-color:#CCC;"></ul>
                                </div>
                            </div>
                        </div>
                        <hr style="margin-top:5px; margin-bottom:5px;">
                        <div class="form-group">
                            <label><?php echo $lang[451]; ?></label>
                            <div class="row" data-toggle="tooltip" data-placement="top" title="">
                                <div class="col-md-12">
                                    <b class="caret" style="position:absolute; margin-top:15px; margin-left:calc(100% - 50px); z-index:1000; cursor:pointer;"></b><div id="id_sex" class="form-control" class="dropdown-toggle" data-toggle="dropdown" aria-expanded="true" style="height:34px; padding-top:8px; border:1px solid #ccc; cursor:pointer;"><?php echo $lang[452]; ?></div>
                                    <ul class="dropdown-menu" style="min-width:calc(100% - 30px); width:calc(100% - 30px); margin-left:15px; margin-top:-1px; border-color:#CCC;">
                                        <li><a onClick="document.getElementById('id_sex').innerHTML=this.innerHTML; more=false; page=1; start_search();"><?php echo $lang[452]; ?></a></li>
                                        <li><a onClick="document.getElementById('id_sex').innerHTML=this.innerHTML; more=false; page=1; start_search();"><?php echo $lang[453]; ?></a></li>
                                        <li><a onClick="document.getElementById('id_sex').innerHTML=this.innerHTML; more=false; page=1; start_search();"><?php echo $lang[454]; ?></a></li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                        <div class="form-group">
                            <label><?php echo $lang[455]; ?></label>
                            <div class="row" data-toggle="tooltip" data-placement="top" title="">
                                <div class="col-md-12">
                                    <b class="caret" style="position:absolute; margin-top:15px; margin-left:calc(100% - 50px); z-index:1000; cursor:pointer;"></b><div id="id_age_from" class="form-control" class="dropdown-toggle" data-toggle="dropdown" aria-expanded="true" style="height:34px; padding-top:8px; border:1px solid #ccc; cursor:pointer;"><?php echo $lang[456]; ?></div>
                                    <ul class="dropdown-menu" style="min-width:calc(100% - 30px); width:calc(100% - 30px); height:115px; margin-left:15px; margin-top:-1px; overflow-y:scroll; overflow-x:hidden; border-color:#CCC;">
                                        <li><a onClick="document.getElementById('id_age_from').innerHTML=this.innerHTML; more=false; page=1; start_search();"><?php echo $lang[456]; ?></a></li>
                                        <?php
                                        for ($i=14; $i<81; $i++) {
                                        echo '<li><a onClick="document.getElementById(\'id_age_from\').innerHTML=this.innerHTML; more=false; page=1; start_search();">'.$i.'</a></li>
                                        ';    
                                        }
                                        ?>
                                    </ul>
                                </div>
                            </div>
                        </div>
                        <div class="form-group">
                            <label><?php echo $lang[457]; ?></label>
                            <div class="row" data-toggle="tooltip" data-placement="top" title="">
                                <div class="col-md-12">
                                    <b class="caret" style="position:absolute; margin-top:15px; margin-left:calc(100% - 50px); z-index:1000; cursor:pointer;"></b><div id="id_age_to" class="form-control" class="dropdown-toggle" data-toggle="dropdown" aria-expanded="true" style="height:34px; padding-top:8px; border:1px solid #ccc; cursor:pointer;"><?php echo $lang[458]; ?></div>
                                    <ul class="dropdown-menu" style="min-width:calc(100% - 30px); width:calc(100% - 30px); height:115px; margin-left:15px; margin-top:-1px; overflow-y:scroll; overflow-x:hidden; border-color:#CCC;">
                                        <li><a onClick="document.getElementById('id_age_to').innerHTML=this.innerHTML; more=false; page=1; start_search();"><?php echo $lang[458]; ?></a></li>
                                        <?php
                                        for ($i=14; $i<81; $i++) {
                                        echo '<li><a onClick="document.getElementById(\'id_age_to\').innerHTML=this.innerHTML; more=false; page=1; start_search();">'.$i.'</a></li>
                                        ';    
                                        }
                                        ?>
                                    </ul>
                                </div>
                            </div>
                        </div>
                        <div class="form-group">
                            <label><?php echo $lang[459]; ?></label>
                            <div class="row" data-toggle="tooltip" data-placement="top" title="">
                                <div class="col-md-12">
                                    <b class="caret" style="position:absolute; margin-top:15px; margin-left:calc(100% - 50px); z-index:1000; cursor:pointer;"></b><div id="id_marital_status" class="form-control" class="dropdown-toggle" data-toggle="dropdown" aria-expanded="true" style="height:34px; padding-top:8px; border:1px solid #ccc; cursor:pointer;"><?php echo $lang[460]; ?></div>
                                    <ul class="dropdown-menu" style="min-width:calc(100% - 30px); width:calc(100% - 30px); height:115px; margin-left:15px; margin-top:-1px; overflow-y:scroll; overflow-x:hidden; border-color:#CCC;">
                                        <li><a onClick="document.getElementById('id_marital_status').innerHTML='<?php echo $lang[448]; ?>'; more=false; page=1; start_search();"><?php echo $lang[460]; ?></a></li>
                                        <li><a onClick="document.getElementById('id_marital_status').innerHTML=this.innerHTML; more=false; page=1; start_search();"><?php echo $lang[461]; ?></a></li>
                                        <li><a onClick="document.getElementById('id_marital_status').innerHTML=this.innerHTML; more=false; page=1; start_search();"><?php echo $lang[462]; ?></a></li>
                                        <li><a onClick="document.getElementById('id_marital_status').innerHTML=this.innerHTML; more=false; page=1; start_search();"><?php echo $lang[463]; ?></a></li>
                                        <li><a onClick="document.getElementById('id_marital_status').innerHTML=this.innerHTML; more=false; page=1; start_search();"><?php echo $lang[464]; ?></a></li>
                                        <li><a onClick="document.getElementById('id_marital_status').innerHTML=this.innerHTML; more=false; page=1; start_search();"><?php echo $lang[465]; ?></a></li>
                                        <li><a onClick="document.getElementById('id_marital_status').innerHTML=this.innerHTML; more=false; page=1; start_search();"><?php echo $lang[466]; ?></a></li>
                                        <li><a onClick="document.getElementById('id_marital_status').innerHTML=this.innerHTML; more=false; page=1; start_search();"><?php echo $lang[467]; ?></a></li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                        <div class="form-group">
                            <label><?php echo $lang[468]; ?></label>
                            <div class="row" data-toggle="tooltip" data-placement="top" title="">
                                <div class="col-md-12">
                                    <b class="caret" style="position:absolute; margin-top:15px; margin-left:calc(100% - 50px); z-index:1000; cursor:pointer;"></b><div id="id_online" class="form-control" class="dropdown-toggle" data-toggle="dropdown" aria-expanded="true" style="height:34px; padding-top:8px; border:1px solid #ccc; cursor:pointer;"><?php echo $lang[469]; ?></div>
                                    <ul class="dropdown-menu" style="min-width:calc(100% - 30px); width:calc(100% - 30px); margin-left:15px; margin-top:-1px; border-color:#CCC;">
                                        <li><a onClick="document.getElementById('id_online').innerHTML='<?php echo $lang[448]; ?>'; more=false; page=1; start_search();"><?php echo $lang[469]; ?></a></li>
                                        <li><a onClick="document.getElementById('id_online').innerHTML=this.innerHTML; more=false; page=1; start_search();"><?php echo $lang[470]; ?></a></li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-md-7">
                    <div class="header-title-bg" style="margin-left:1px; margin-top:1px;">
                        <?php echo $lang[471]; ?> <b id="id_search_count"></b>
                    </div>
                    <div style="padding:0px; background-color:#ffffff; border:1px solid #e1e1e8; border-radius:4px; margin-bottom:20px; padding-top:47px;">
                        <div style="padding:20px; background: #f5f5f5; border-bottom: 1px solid #e1e1e8;">
                            <div class="form-group" style="margin-bottom:0px;">
                                <input id="id_query" placeholder="<?php echo $lang[472]; ?>" class="form-control" value="<?php echo $_GET['query']; ?>" onKeyDown="if(event.keyCode==13){more=false; page=1; start_search();}" />
                            </div>
                        </div>
                        <div id="id_query_body" style="padding:20px;">
                            <div style="text-align:center; padding:20px;"><img src="/img/preloader.gif" /></div>
                        </div>
                    </div>
                </div>                        
            </div>
        </div>                

        <?php include $_SERVER['DOCUMENT_ROOT'].'/modal/visits.php'; ?>
        <?php include $_SERVER['DOCUMENT_ROOT'].'/modal/otvety.php'; ?>
        
        <div class="talker">
        <div class="talker_message"></div>
        </div>            
        <?php include $_SERVER['DOCUMENT_ROOT'].'/templates/footer.tpl'; ?>    
        <script type="text/javascript">
            <?php
            if (isset($_GET['query'])) {
                $query = $_GET['query'];
            } else {
                $query = '';
            }
            ?>
            var query = '<?php echo $query; ?>';
            var more = false;
            var page = 1;
            <?php if ($my_id):?>var otvety_count = <?php echo $count_otvety; ?>;<?php endif;?>
            onload = function() {
                start_search();
                <?php if ($my_id):?>
                ping_online();
                <?php endif;?>
            }
        </script>
        <script src="/js/system/<?php echo $js_lang; ?>/search.js?r=<?php echo $global_rand; ?>" type="text/javascript"></script>
    </body>
</html>