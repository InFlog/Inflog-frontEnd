<?php
function edit_status($my_status, $token) {
    include $_SERVER['DOCUMENT_ROOT'].'/inc/config.php';
    $my_status = addslashes($my_status);
    $my_status = htmlspecialchars($my_status);
    
    include $_SERVER['DOCUMENT_ROOT'].'/inc/login.php';
    if ($token == md5($my_id.'_editstatus_'.$secret) and $my_id) {
        include $_SERVER['DOCUMENT_ROOT'].'/inc/sql_social.php';
        
        $my_status = mb_substr($my_status, 0, 40, 'UTF-8');
        $arr = explode(' ', $my_status);
        if (count($arr)<2) {
            $my_status = mb_substr($my_status, 0, 20, 'UTF-8');
        }
        mysql_query("UPDATE users SET status='$my_status' WHERE id='$my_id'");
        
        if ($my_status=='') {
            $my_status = $lang[535];
        }
        return $my_status;
    }
}
?>