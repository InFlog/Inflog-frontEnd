<?php
function login($l, $p) {
    $l = addslashes($l);
    $p = addslashes($p);
    
    $l = htmlspecialchars($l);
    $p = htmlspecialchars($p);
    
    $p = md5($p);
    $my_id = false;
    include $_SERVER['DOCUMENT_ROOT'].'/inc/sql_social.php';
    $z_my_id = mysql_query("SELECT id FROM users WHERE email='$l' and password='$p'");
    $o_my_id = mysql_fetch_array($z_my_id);
    if ($o_my_id) { 
        $my_id = $o_my_id['id'];
        setcookie('l', $my_id, time() + 60 * 60 * 24 * 30 * 12);
        setcookie('p', $p, time() + 60 * 60 * 24 * 30 * 12);     
    }
    mysql_close($msconnect);
    return $my_id;
}
?>