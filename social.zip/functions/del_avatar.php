<?php
function del_avatar($token) {
    include $_SERVER['DOCUMENT_ROOT'].'/inc/config.php';
    include $_SERVER['DOCUMENT_ROOT'].'/inc/login.php';
    if ($token == md5($my_id.'_delavatar_'.$secret) and $my_id) {
        include $_SERVER['DOCUMENT_ROOT'].'/inc/sql_social.php';
        mysql_query("UPDATE users SET avatar='0' WHERE id='$my_id'");
        mysql_close($msconnect);
    }
}
?>