<?php
function edit_work($place_work, $position, $work_info, $token) {
    include $_SERVER['DOCUMENT_ROOT'].'/inc/config.php';
    include $_SERVER['DOCUMENT_ROOT'].'/inc/login.php';
    if ($token == md5($my_id.'_work_'.$secret) and $my_id) {
        $place_work = addslashes($place_work);
        $position = addslashes($position);
        $work_info = addslashes($work_info);
        
        $place_work = htmlspecialchars($place_work);
        $position = htmlspecialchars($position);
        $work_info = htmlspecialchars($work_info);
        
        include $_SERVER['DOCUMENT_ROOT'].'/inc/login.php';
        if ($my_id) {
        $live_edit = true;

        if (mb_strlen($place_work, 'UTF-8')>300) { $live_edit = false; }
        if (mb_strlen($position, 'UTF-8')>300) { $live_edit = false; }
        if (mb_strlen($work_info, 'UTF-8')>10000) { $live_edit = false; }
        
        if ($live_edit) {
            include $_SERVER['DOCUMENT_ROOT'].'/inc/sql_social.php';
            mysql_query("UPDATE users SET place_work='$place_work', position='$position', work_info='$work_info' WHERE id='$my_id'");
            mysql_close($msconnect);
        }
        
        return $live_edit;
        }
    }
}
?>