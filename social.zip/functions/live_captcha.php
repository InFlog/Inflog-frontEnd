<?php
function live_captcha($captcha, $hash) {
    $captcha = addslashes($captcha);
    $hash = addslashes($hash);
    
    $captcha = htmlspecialchars($captcha);
    $hash = htmlspecialchars($hash);
    if (md5($captcha)==$hash) {
        return 1;
    } else {
        return 0;
    }
}
?>