<?php
function delwall($wall_id, $token) {
    include $_SERVER['DOCUMENT_ROOT'].'/inc/config.php';
    $wall_id = addslashes($wall_id);
    $wall_id = htmlspecialchars($wall_id);
    include $_SERVER['DOCUMENT_ROOT'].'/inc/login.php';
    if ($token == md5($my_id.'_'.$wall_id.'_delwall_'.$secret) and $my_id) {
        include $_SERVER['DOCUMENT_ROOT'].'/inc/sql_social.php';

        $z_wall_author_id = mysql_query("SELECT * FROM wall WHERE wall_id='$wall_id'");
        $o_wall_author_id = mysql_fetch_array($z_wall_author_id);
        $wall_author_id = $o_wall_author_id['user_id'];
        $page_id = $o_wall_author_id['page_id'];
        if ($wall_author_id==$my_id || $page_id==$my_id) {
            mysql_query("DELETE FROM wall WHERE wall_id='$wall_id'");
            mysql_query("DELETE FROM wall_to_users WHERE wall_id='$wall_id'");
        }
        mysql_close($msconnect);
    }
}
?>