<?php
function register($firstname, $lastname, $sex, $day, $month, $year, $email, $password_1, $password_2, $code, $hash) {
    include $_SERVER['DOCUMENT_ROOT'].'/inc/config.php';
    $firstname = addslashes($firstname);
    $lastname = addslashes($lastname);
    $sex = addslashes($sex);
    $day = addslashes($day);
    $month = addslashes($month);
    $year = addslashes($year);
    $email = addslashes($email);
    $password_1 = addslashes($password_1);
    $password_2 = addslashes($password_2);
    $code = addslashes($code);
    $hash = addslashes($hash);
    
    $firstname = htmlspecialchars($firstname);
    $lastname = htmlspecialchars($lastname);
    $sex = htmlspecialchars($sex);
    $day = htmlspecialchars($day);
    $month = htmlspecialchars($month);
    $year = htmlspecialchars($year);
    $email = htmlspecialchars($email);
    $password_1 = htmlspecialchars($password_1);
    $password_2 = htmlspecialchars($password_2);
    $code = htmlspecialchars($code);
    $hash = htmlspecialchars($hash);
    
    $live_register = true;
    if ($sex==$lang[623]) { $sex = ''; }
    if ($day==$lang[624]) { $day = ''; }
    if ($month==$lang[625]) { $month = ''; }
    if ($year==$lang[626]) { $year = ''; }

    if (mb_strlen($firstname, 'UTF-8')<2) { $live_register = false;    }
    if (ctype_digit($firstname)) { $live_register = false; }

    if (mb_strlen($lastname, 'UTF-8')<2) { $live_register = false;    }
    if (ctype_digit($lastname)) { $live_register = false; }

    $isex = '';
    if ($sex==$lang[627]) { $isex = '1'; }
    if ($sex==$lang[628]) { $isex = '2'; }
    if ($isex=='') { $live_register = false; }

    if ($day>0 and $day<32) {} else { $live_register = false; }

    $imonth = '';
    if ($month==$lang[629]) { $imonth = '1'; }
    if ($month==$lang[630]) { $imonth = '2'; }
    if ($month==$lang[631]) { $imonth = '3'; }
    if ($month==$lang[632]) { $imonth = '4'; }
    if ($month==$lang[633]) { $imonth = '5'; }
    if ($month==$lang[634]) { $imonth = '6'; }
    if ($month==$lang[635]) { $imonth = '7'; }
    if ($month==$lang[636]) { $imonth = '8'; }
    if ($month==$lang[637]) { $imonth = '9'; }
    if ($month==$lang[638]) { $imonth = '10'; }
    if ($month==$lang[639]) { $imonth = '11'; }
    if ($month==$lang[640]) { $imonth = '12'; }
    if ($imonth=='') { $live_register = false; }

    if ($year>1954 and $year<2006) {} else { $live_register = false; }

    if(!preg_match("/^([a-z0-9_\.-]+)@([a-z0-9_\.-]+)\.([a-z\.]{2,6})$/", $email)) { $live_register = false; }

    include $_SERVER['DOCUMENT_ROOT'].'/inc/sql_social.php';
    $z_live_email = mysql_query("SELECT id FROM users WHERE email='$email'");
    $o_live_email = mysql_fetch_array($z_live_email);
    $live_email = $o_live_email['id'];
    if ($live_email) { $live_register = false; }
    mysql_close($msconnect);

    if ($password_1!==$password_2) { $live_register = false; }
    if (mb_strlen($password_1, 'UTF-8')<6) { $live_register = false; }
    if (mb_strlen($password_2, 'UTF-8')<6) { $live_register = false; }

    if (md5($code)!==$hash) { $live_register = false; }
        
    if ($live_register) {
        $hpassword = md5($password_1);
        include $_SERVER['DOCUMENT_ROOT'].'/inc/sql_social.php';        
        mysql_query("INSERT users SET firstname='$firstname', lastname='$lastname', sex='$isex', day='$day', month='$imonth', year='$year', email='$email', password='$hpassword', avatar='0', country='0'");
        
        $z_last_user_id = mysql_query("SELECT id FROM users ORDER BY id DESC");
        $o_last_user_id = mysql_fetch_array($z_last_user_id);
        $last_user_id = $o_last_user_id['id'];
        
        $z_firstname_id = mysql_query("SELECT * FROM search_words WHERE word='$firstname'");
        $o_firstname_id = mysql_fetch_array($z_firstname_id);
        $firstname_id = $o_firstname_id['word_id'];
        
        if (!$firstname_id) {
            mysql_query("INSERT search_words SET word='$firstname'");
            $z_firstname_id = mysql_query("SELECT * FROM search_words WHERE word='$firstname'");
            $o_firstname_id = mysql_fetch_array($z_firstname_id);
            $firstname_id = $o_firstname_id['word_id'];    
        }
        
        $z_lastname_id = mysql_query("SELECT * FROM search_words WHERE word='$lastname'");
        $o_lastname_id = mysql_fetch_array($z_lastname_id);
        $lastname_id = $o_lastname_id['word_id'];
        
        if (!$lastname_id) {
            mysql_query("INSERT search_words SET word='$lastname'");
            $z_lastname_id = mysql_query("SELECT * FROM search_words WHERE word='$lastname'");
            $o_lastname_id = mysql_fetch_array($z_lastname_id);
            $lastname_id = $o_lastname_id['word_id'];
        }
        
        mysql_query("INSERT search_links SET user_id='$last_user_id', firstname_id='$firstname_id', lastname_id='$lastname_id', sex_id='$isex', year='$year'");
        
        setcookie("l", $last_user_id, time()+3600, "/", "", 0);
        setcookie("p", $hpassword, time()+3600, "/", "", 0);
        
        mysql_close($msconnect);        
    }    
        
    return $live_register;
}
?>