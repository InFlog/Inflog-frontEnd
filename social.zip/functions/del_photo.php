<?php
function del_photo($photo_id, $uid, $token) {
    include $_SERVER['DOCUMENT_ROOT'].'/inc/config.php';
    $photo_id = addslashes($photo_id);
    $uid = addslashes($uid);
    
    $photo_id = htmlspecialchars($photo_id);
    $uid = htmlspecialchars($uid);
    include $_SERVER['DOCUMENT_ROOT'].'/inc/login.php';
    if ($token == md5($my_id.'_'.$uid.'_delphoto_'.$secret) and $my_id) {
        include $_SERVER['DOCUMENT_ROOT'].'/inc/sql_social.php';

        $z_live_author = mysql_query("SELECT user_id FROM photo_to_users WHERE photo_id='$photo_id'");
        $o_live_author = mysql_fetch_array($z_live_author);
        $live_author = $o_live_author['user_id'];
        if ($my_id==$live_author) {
            mysql_query("UPDATE photo_to_users SET live='0' WHERE photo_id='$photo_id'");
        }
        mysql_close($msconnect);
    }
}
?>