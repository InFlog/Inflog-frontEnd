<?php
function edit_education($institut, $department, $start_training, $finish_training, $education_info, $token) {
    include $_SERVER['DOCUMENT_ROOT'].'/inc/config.php';
    include $_SERVER['DOCUMENT_ROOT'].'/inc/login.php';
    if ($token == md5($my_id.'_education_'.$secret) and $my_id) {
        $institut = addslashes($institut);
        $department = addslashes($department);
        $start_training = addslashes($start_training);
        $finish_training = addslashes($finish_training);
        $education_info = addslashes($education_info);
        
        $institut = htmlspecialchars($institut);
        $department = htmlspecialchars($department);
        $start_training = htmlspecialchars($start_training);
        $finish_training = htmlspecialchars($finish_training);
        $education_info = htmlspecialchars($education_info);
        
        include $_SERVER['DOCUMENT_ROOT'].'/inc/login.php';
        if ($my_id) {
        $live_edit = true;

        if (mb_strlen($institut, 'UTF-8')>300) { $live_edit = false; }
        if (mb_strlen($department, 'UTF-8')>300) { $live_edit = false; }
        if ($start_training!=='0') { if ($start_training>1954 and $start_training<2017) {} else { $live_edit = false; } }
        if ($finish_training!=='0') { if ($finish_training>1954 and $finish_training<2017) {} else { $live_edit = false; } }
        if (mb_strlen($education_info, 'UTF-8')>10000) { $live_edit = false; }
        
        if ($live_edit) {
            include $_SERVER['DOCUMENT_ROOT'].'/inc/sql_social.php';
            mysql_query("UPDATE users SET institut='$institut', department='$department', start_training='$start_training', finish_training='$finish_training', education_info='$education_info' WHERE id='$my_id'");
            mysql_close($msconnect);
        }
        
        return $live_edit;
        }
    }
}
?>