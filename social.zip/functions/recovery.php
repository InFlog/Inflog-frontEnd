<?php
function get_data($smtp_conn) {
    $smtp_conn = addslashes($smtp_conn);
    $smtp_conn = htmlspecialchars($smtp_conn);
    
    $data="";
    while($str = fgets($smtp_conn,515)) 
    {
        $data .= $str;
        if(substr($str,3,1) == " ") { break; }
    }
    return $data;
}

function recovery($email) {
    include $_SERVER['DOCUMENT_ROOT'].'/inc/config.php';
    $email = addslashes($email);
    $email = htmlspecialchars($email);
    include $_SERVER['DOCUMENT_ROOT'].'/inc/sql_social.php';    
    
    $z_live_email = mysql_query("SELECT * FROM users WHERE email='$email'");
    $o_live_email = mysql_fetch_array($z_live_email);
    $live_email = $o_live_email['email'];
    $user_id = $o_live_email['id'];
    $user_password = $o_live_email['password'];
    $firstname = $o_live_email['firstname'];
    $lastname = $o_live_email['lastname'];
    $sex = $o_live_email['sex'];
    
    if ($sex==1) {
        $start_text = $lang[619].' '.$firstname.' '.$lastname;
    } else {
        $start_text = $lang[620].' '.$firstname.' '.$lastname;
    }
    
    if ($live_email) {
        include $_SERVER['DOCUMENT_ROOT'].'/inc/mail_social.php';
        $to = $live_email;
        $header = "From: $from\r\nSubject: $lang[617]\r\nContent-type: text/html; charset=utf-8\r\n";
        $text = '
        <table cellspacing="0" cellpadding="0" width="100%" bgcolor="#F5F5F5"><tbody><tr><td width="15"><table cellspacing="0" cellpadding="0" width="15"><tbody><tr><td><div style="height:0;line-height:0;font-size:0">&nbsp;</div></td></tr></tbody></table></td><td align="center" style="padding:15px 0;"><table cellspacing="0" cellpadding="0" width="600" bgcolor="#FFFFFF"><tbody><tr><td><table cellspacing="0" cellpadding="0" width="100%"><tbody><tr><td width="100%" bgcolor="#2B587A" valign="top" style="border-radius:4px 4px 0px 0px; padding-left:18px;"><p style="width:10px;height:14px;font-family:Arial;font-size:14px;background:#234763;color:#fff;padding:8px 10px 8px 10px;border-radius:4px;border-radius:4px;line-height:1;"><b>В</b></p></td></tr></tbody></table></td></tr><tr><td><div style="padding:18px 18px 13px 18px;border-left:1px solid #dadee3;border-right:1px solid #dadee3;font-size:12px;color:black;"><h1 style="margin:2px 0px 15px 0;padding:0px 0px 4px;border-bottom:1px solid #D8DFE6;font-family:Arial;font-size:14px;">'.$lang[618].'</h1><div style="line-height:160%;font-family:Arial;">'.$start_text.', '.$lang[621].' <b style="font-size:14px;">'.$user_password.'</b><br><br>'.$lang[622].'</div></div></td></tr><tr><td><table cellspacing="0" cellpadding="0" width="100%"><tbody><tr><td width="3"><div style="width:0;height:1px;max-height:1px;line-height:1px;font-size:0;border-left:1px solid #e6e7eb;border-right:1px solid #e8ebed;"></div><div style="width:0;height:1px;max-height:1px;line-height:1px;font-size:0;border-left:1px solid #f5f5f5;border-right:1px solid #e6e7eb;"></div></td><td width="100%" valign="bottom"><div style="height:1px;max-height:1px;line-height:0;font-size:0;border-bottom:1px solid #dadee3;">&nbsp;</div></td><td width="3" align="right"><div style="width:0;height:1px;max-height:1px;line-height:1px;font-size:0;border-left:1px solid #e8ebed;border-right:1px solid #e6e7eb;"></div><div style="width:0;height:1px;max-height:1px;line-height:1px;font-size:0;border-left:1px solid #e6e7eb;border-right:1px solid #f5f5f5;"></div></td></tr></tbody></table></td></tr><tr><td bgcolor="#F5F5F5" align="center" style="padding:13px 0 0 0;font-size:12px;color:#888888;"></td></tr></tbody></table></td><td width="15"><table cellspacing="0" cellpadding="0" width="15"><tbody><tr><td><div style="height:0;line-height:0;font-size:0">&nbsp;</div></td></tr></tbody></table></td></tr></tbody></table>
        ';
        $port = 25;
        $smtp_conn = fsockopen($host, $port, $errno, $errstr, 10);
        if(!$smtp_conn) {
            fclose($smtp_conn); exit;
        }  
        $data = get_data($smtp_conn);
        fputs($smtp_conn,"EHLO mail.tutnaidut.com\r\n");
        $code = substr(get_data($smtp_conn),0,3);
        if($code != 250) {
            fclose($smtp_conn); exit;
        }
        fputs($smtp_conn,"AUTH LOGIN\r\n");
        $code = substr(get_data($smtp_conn),0,3);
        if($code != 334) {
            fclose($smtp_conn); exit;
        }
        fputs($smtp_conn,base64_encode("$login")."\r\n");
        $code = substr(get_data($smtp_conn),0,3);
        if($code != 334) {
            fclose($smtp_conn); exit;
        }
        fputs($smtp_conn,base64_encode("$password")."\r\n");
        $code = substr(get_data($smtp_conn),0,3);                 
        if($code != 235) {
            fclose($smtp_conn); exit;
        }
        fputs($smtp_conn,"MAIL FROM:$login\r\n");
        $code = substr(get_data($smtp_conn),0,3);
        if($code != 250) {
            fclose($smtp_conn); exit;
        }
        fputs($smtp_conn,"RCPT TO:$to\r\n");
        $code = substr(get_data($smtp_conn),0,3);
        if($code != 250 AND $code != 251) {
            fclose($smtp_conn); exit;
        }
        fputs($smtp_conn,"DATA\r\n");
        $code = substr(get_data($smtp_conn),0,3);
        if($code != 354) {
            fclose($smtp_conn); exit;
        }
        fputs($smtp_conn,$header.$text."\r\n.\r\n");
        $code = substr(get_data($smtp_conn),0,3);
        if($code != 250) {
            fclose($smtp_conn); exit;
        }
        fputs($smtp_conn,"QUIT\r\n");
        fclose($smtp_conn);
        
        return $user_id;
    } else {
        return 0;
    }
    
    mysql_close($msconnect);
}

function recovery_login($uid, $recovery_password) {
    $uid = addslashes($uid);
    $recovery_password = addslashes($recovery_password);
    
    $uid = htmlspecialchars($uid);
    $recovery_password = htmlspecialchars($recovery_password);
    include $_SERVER['DOCUMENT_ROOT'].'/inc/sql_social.php';    
    
    $z_live_user = mysql_query("SELECT id FROM users WHERE id='$uid' and password='$recovery_password'");
    $o_live_user = mysql_fetch_array($z_live_user);
    $id = $o_live_user['id'];
    
    if ($id) {
        setcookie('l', $uid, time() + 60 * 60 * 24 * 30 * 12);
        setcookie('p', $recovery_password, time() + 60 * 60 * 24 * 30 * 12);
        return $id;
    } else {
        return 0;
    }
    
    mysql_close($msconnect);
}
?>