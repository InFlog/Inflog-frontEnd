<?php
function send_messages($message, $str_messages_photos, $talk_id, $token) {
    include $_SERVER['DOCUMENT_ROOT'].'/inc/config.php';
    $message = addslashes($message);
    $str_messages_photos = addslashes($str_messages_photos);
    $talk_id = addslashes($talk_id);
    
    $message = htmlspecialchars($message);
    $str_messages_photos = htmlspecialchars($str_messages_photos);
    $talk_id = htmlspecialchars($talk_id);
    
    include $_SERVER['DOCUMENT_ROOT'].'/inc/login.php';
    if ($token == md5($my_id.'_'.$talk_id.'_sendmessages_'.$secret) and $my_id) {
        include $_SERVER['DOCUMENT_ROOT'].'/inc/sql_social.php';
        $this_date = date('U');
        mysql_query("INSERT messages SET user_from='$my_id', user_to='$talk_id', message='$message', photos='$str_messages_photos', date='$this_date'");
        
        $z_dialog_id = mysql_query("SELECT * FROM dialogs WHERE user_from='$my_id' and user_to='$talk_id' OR user_to='$my_id' and user_from='$talk_id'");
        $o_dialog_id = mysql_fetch_array($z_dialog_id);
        $dialog_id = $o_dialog_id['dialog_id'];
        
        $date = date('U');
        if ($dialog_id) {
            mysql_query("UPDATE dialogs SET user_from='$my_id', user_to='$talk_id', status='1', date='$date' WHERE dialog_id='$dialog_id'");
        } else {
            mysql_query("INSERT dialogs SET user_from='$my_id', user_to='$talk_id', status='1', date='$date'");
        }
        
        mysql_close($msconnect);
    }
}
?>