<?php
function add_onfriends($friend_id, $token) {
    include $_SERVER['DOCUMENT_ROOT'].'/inc/config.php';
    $friend_id = addslashes($friend_id);
    $friend_id = htmlspecialchars($friend_id);
    include $_SERVER['DOCUMENT_ROOT'].'/inc/login.php';
    if ($token == md5($my_id.'_'.$friend_id.'_addonfriends_'.$secret) and $my_id) {
        include $_SERVER['DOCUMENT_ROOT'].'/inc/sql_social.php';
        mysql_query("UPDATE friends SET status='1' WHERE user_id='$friend_id' and friend_id='$my_id' and status='0'");
        
        $z_live_user_friend = mysql_query("SELECT user_id FROM friends WHERE user_id='$my_id' and friend_id='$friend_id' and status='1'");
        $o_live_user_friend = mysql_fetch_array($z_live_user_friend);
        $live_user_friend = $o_live_user_friend['user_id'];
        
        if (!$live_user_friend) { 
            mysql_query("INSERT friends SET user_id='$my_id', friend_id='$friend_id', status='1'"); 
            $time = date('U');
            mysql_query("INSERT news SET user_from='$my_id', user_to='$friend_id', object_id='$friend_id', news_type='8', status='1', time='$time'");
        }
        
        $z_user_info = mysql_query("SELECT * FROM users WHERE id='$friend_id'");
        $o_user_info = mysql_fetch_array($z_user_info);
        $info_firstname = $o_user_info['firstname'];
        $info_lastname = $o_user_info['lastname'];
        mysql_close($msconnect);
        return $info_firstname.' '.$info_lastname;
    }
}
?>