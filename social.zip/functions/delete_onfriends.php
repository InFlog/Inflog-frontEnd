<?php
function delete_onfriends($friend_id, $token) {
    include $_SERVER['DOCUMENT_ROOT'].'/inc/config.php';
    $friend_id = addslashes($friend_id);
    $friend_id = htmlspecialchars($friend_id);
    include $_SERVER['DOCUMENT_ROOT'].'/inc/login.php';
    if ($token == md5($my_id.'_'.$friend_id.'_deleteonfriends_'.$secret) and $my_id) {
        include $_SERVER['DOCUMENT_ROOT'].'/inc/sql_social.php';
        mysql_query("DELETE FROM friends WHERE user_id='$friend_id' and friend_id='$my_id' and status='0'");
        $z_user_info = mysql_query("SELECT * FROM users WHERE id='$friend_id'");
        $o_user_info = mysql_fetch_array($z_user_info);
        $info_firstname = $o_user_info['firstname'];
        $info_lastname = $o_user_info['lastname'];
        mysql_close($msconnect);
        return $info_firstname.' '.$info_lastname;
    }
}
?>