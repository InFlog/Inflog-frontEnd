<?php
function live_email($email) {
    $email = addslashes($email);
    $email = htmlspecialchars($email);
    include $_SERVER['DOCUMENT_ROOT'].'/inc/sql_social.php';
    $z_live_email = mysql_query("SELECT id FROM users WHERE email='$email'");
    $o_live_email = mysql_fetch_array($z_live_email);
    $live_email = $o_live_email['id'];
    mysql_close($msconnect);
    if ($live_email) {
        return 1;
    } else {
        return 0;
    }
}
?>