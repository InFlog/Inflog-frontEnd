<?php
function delchat($chat_id, $token) {
    include $_SERVER['DOCUMENT_ROOT'].'/inc/config.php';
    $chat_id = addslashes($chat_id);
    $chat_id = htmlspecialchars($chat_id);
    include $_SERVER['DOCUMENT_ROOT'].'/inc/login.php';
    if ($token == md5($my_id.'_'.$chat_id.'_delchat_'.$secret) and $my_id) {
        include $_SERVER['DOCUMENT_ROOT'].'/inc/sql_social.php';

        $z_chat_author_id = mysql_query("SELECT user_id FROM chat WHERE chat_id='$chat_id'");
        $o_chat_author_id = mysql_fetch_array($z_chat_author_id);
        $chat_author_id = $o_chat_author_id['user_id'];
        if ($chat_author_id==$my_id) {
            mysql_query("DELETE FROM chat WHERE chat_id='$chat_id'");
        }
        mysql_close($msconnect);
    }
}
?>