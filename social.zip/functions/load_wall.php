<?php
function load_wall($page_id, $page) {
    include $_SERVER['DOCUMENT_ROOT'].'/inc/config.php';
    $page_id = addslashes($page_id);
    $page = addslashes($page);
    
    $page_id = htmlspecialchars($page_id);
    $page = htmlspecialchars($page);
    
    include $_SERVER['DOCUMENT_ROOT'].'/inc/login.php';
    include $_SERVER['DOCUMENT_ROOT'].'/inc/sql_social.php';
    
    $body_comments = '';
    $page_start = $page*10-10;
    $page_next = ($page_start+10);
    $result = mysql_query("SELECT * FROM wall WHERE page_id='$page_id' ORDER BY wall_id DESC, wall_id LIMIT $page_start, 10"); 
    
    $z_live_next = mysql_query("SELECT * FROM wall WHERE page_id='$page_id' ORDER BY wall_id DESC, wall_id LIMIT $page_next, 1");
    $o_live_next = mysql_fetch_array($z_live_next);
    $live_next = $o_live_next['wall_id'];
    
    while ( $myrow = mysql_fetch_array($result) )
    {
        $uid = $myrow['user_id'];
        $z_user_info = mysql_query("SELECT * FROM users WHERE id='$uid'");
        $o_user_info = mysql_fetch_array($z_user_info);
        $info_firstname = $o_user_info['firstname'];
        $date = date("d.m.Y H:i", $myrow['date']);
        $object_id = $myrow['wall_id'];
        $page_id = $myrow['page_id'];
        
        if ($uid==$my_id || $page_id==$my_id) {
            $del_wall = '<span style="font-size:11px; color:#777; float:right; cursor:pointer;" onClick="wall_id='.$object_id.'; token=\''.md5($my_id.'_'.$object_id.'_delwall_'.$secret).'\'; del_wall();">'.$lang[686].'</span>';
        } else {
            $del_wall = '';
        }
        
        $z_count_likes = mysql_query("SELECT likes_id FROM likes WHERE object_id='$object_id' and object_type='3'");
        $count_likes = mysql_num_rows($z_count_likes);

        if ($count_likes>0) {
            $likes_count = '<span style="color:#2B587A; font-size:13px;"><b id="like_count_3_'.$myrow['wall_id'].'">'.$count_likes.'</b></span>';
            $display_likes = 'block';
        } else {
            $likes_count = '<span style="color:#2B587A; font-size:13px;"><b id="like_count_3_'.$myrow['wall_id'].'"></b></span>';
            $display_likes = 'none';
        }

        $z_heart_likes = mysql_query("SELECT likes_id FROM likes WHERE object_id='$object_id' and object_type='3' and user_id='$my_id'");
        $heart_likes = mysql_num_rows($z_heart_likes);

        if ($heart_likes>0) {
            $likes_heart = '<span id="like_heart_3_'.$myrow['wall_id'].'" class="icon-heart" style="color:#5085ad; font-size:13px;"></span>';
        } else {
            $likes_heart = '<span id="like_heart_3_'.$myrow['wall_id'].'" class="icon-heart" style="color:#b4cee2; font-size:13px;"></span>';
        }
        
        $i = 0;
        $likes_body = '';
        $result_like = mysql_query("SELECT * FROM likes WHERE object_id='$object_id' and object_type='3' ORDER BY likes_id DESC, likes_id LIMIT 0, 2"); 
        while ( $myrow_like = mysql_fetch_array($result_like) )
        {
            
            $rand = rand(10000, 99999);
            $user_ava_id = $myrow_like['user_id'];
            $z_user_avatar = mysql_query("SELECT * FROM users WHERE id='$user_ava_id'");
            $o_user_avatar = mysql_fetch_array($z_user_avatar);
            $user_avatar = $o_user_avatar['avatar'];
            $user_sex = $o_user_avatar['sex'];
            if ($user_avatar==0) {
                if ($user_sex==1) { $avatar = '/img/no_photo/girl.png?r='.$rand; }
                if ($user_sex==2) { $avatar = '/img/no_photo/boy.png?r='.$rand; }
            } else {
                $avatar = '/avatar/'.$user_ava_id.'.jpg?r='.$rand;
            }
            
            if ($i==0) {
                $likes_body = '<img width=\'30\' height=\'30\' src=\''.$avatar.'\' style=\'border-radius:100px; margin:5px 0px 5px 0px;\' />'.$likes_body;
            } else {
                $likes_body = '<img width=\'30\' height=\'30\' src=\''.$avatar.'\' style=\'border-radius:100px; margin:5px 5px 5px 0px;\' />'.$likes_body;
            }
            $i++;
        }
        
        for ($ic=1; $ic<36; $ic++) {
            $myrow['message'] = str_replace('&lt;smile'.$ic.' /&gt;', '<img src=\'/img/smiles/'.$ic.'.png\' />', $myrow['message']);
        }
        
        if ($myrow['photos'] and $myrow['photos']!=='') {
            $photos_body = '';
            $arr_photos = explode(',', $myrow['photos']);
            for ($ip=0; $ip<count($arr_photos); $ip++) {
                $photos_body = $photos_body.'<div style="width:'.(200/count($arr_photos)).'px; height:'.(200/count($arr_photos)).'px; background-image: url(\'/photo/m_'.$arr_photos[$ip].'.jpg\'); background-size:cover; background-position:center top; border-radius:4px; float:left; margin-right:2px; cursor:pointer;" onClick="photo_name=\''.$arr_photos[$ip].'\'; photo_type=2; comment_photo_show();"></div>';
            }
            $myrow['message'] = $myrow['message'].'<div style="padding-left:40px; height:'.(200/count($arr_photos)).'px;">'.$photos_body.'</div>';
        }
        
        $rand = rand(10000, 99999);
        $user_ava_id = $myrow['user_id'];
        $z_user_avatar = mysql_query("SELECT * FROM users WHERE id='$user_ava_id'");
        $o_user_avatar = mysql_fetch_array($z_user_avatar);
        $user_avatar = $o_user_avatar['avatar'];
        $user_sex = $o_user_avatar['sex'];
        if ($user_avatar==0) {
            if ($user_sex==1) { $avatar = '/img/no_photo/girl.png?r='.$rand; }
            if ($user_sex==2) { $avatar = '/img/no_photo/boy.png?r='.$rand; }
        } else {
            $avatar = '/avatar/'.$user_ava_id.'.jpg?r='.$rand;
        }
        
        $uid_online = $myrow['user_id'];
        $z_user_online = mysql_query("SELECT time FROM users_to_online WHERE user_id='$uid_online'");
        $o_user_online = mysql_fetch_array($z_user_online);
        $user_online = $o_user_online['time'];
        $this_date = date('U');
        if ($user_online>($this_date-60)) {
            $user_online = ' <span class="icon-lamp" style="color:#46af48; font-size:10px;"></span>';
        } else {
            $user_online = '';
        }
        
        if ($my_id) {
            $body_comments = $body_comments. '
                <div id="wall_'.$myrow['wall_id'].'">
                    <div style="width:75%; float:left;">
                        <div style="float:left;">
                            <a href="/id'.$myrow['user_id'].'"><img id="id_top_avatar" width="30" height="30" src="'.$avatar.'" style="border-radius:100px;"></a>
                        </div>
                        <div style="float:left; padding-left:10px;">
                            <a href="/id'.$myrow['user_id'].'">'.$info_firstname.$user_online.'</a>
                            <br>
                            <span style="font-size:11px; color:#777;">'.$date.'</span>
                        </div>
                    </div>
                    <div style="width:25%; float:left;" onselectstart="return false" onmousedown="return false">
                        <div style="float:right; cursor:pointer;" onClick="object_id='.$myrow['wall_id'].'; object_type=3; token=\''.md5($my_id.'_'.$myrow['wall_id'].'_3_like_'.$secret).'\'; like();">
                            '.$likes_heart.'

                            '.$likes_count.'
                        </div>
                        <span id="popover_3_'.$myrow['wall_id'].'" data-toggle="tooltip" data-placement="top" data-html="true" title="'.$likes_body.'" onclick="object_id='.$object_id.'; object_type=3; more=false; page=1; like_peoples();" onmouseover="$(\'#popover_3_'.$object_id.'\').tooltip(\'show\');" onmouseout="$(\'#popover_3_'.$object_id.'\').tooltip(\'hide\');" style="float:right; font-size:12px; color:#b4cee2; margin-right:10px; cursor:pointer; display:'.$display_likes.';">&bull;&bull;&bull;</span>
                    </div>
                    <div>'.$del_wall.'</div>
                    <br><br>
                    <p style="padding-left:40px; padding-top:10px;">'.$myrow['message'].'</p>
                    <hr>
                </div>
            ';
        } else {
            $body_comments = $body_comments. '
                <div id="wall_'.$myrow['wall_id'].'">
                    <div style="width:75%; float:left;">
                        <div style="float:left;">
                            <a href="/id'.$myrow['user_id'].'"><img id="id_top_avatar" width="30" height="30" src="'.$avatar.'" style="border-radius:100px;"></a>
                        </div>
                        <div style="float:left; padding-left:10px;">
                            <a href="/id'.$myrow['user_id'].'">'.$info_firstname.$user_online.'</a>
                            <br>
                            <span style="font-size:11px; color:#777;">'.$date.'</span>
                        </div>
                    </div>
                    <div style="width:25%; float:left;" onselectstart="return false" onmousedown="return false">
                        <div style="float:right;">
                            '.$likes_heart.'

                            '.$likes_count.'
                        </div>
                        <span id="popover_3_'.$myrow['wall_id'].'" data-toggle="tooltip" data-placement="top" data-html="true" title="'.$likes_body.'" onclick="object_id='.$object_id.'; object_type=3; more=false; page=1; like_peoples();" onmouseover="$(\'#popover_3_'.$object_id.'\').tooltip(\'show\');" onmouseout="$(\'#popover_3_'.$object_id.'\').tooltip(\'hide\');" style="float:right; font-size:12px; color:#b4cee2; margin-right:10px; cursor:pointer; display:'.$display_likes.';">&bull;&bull;&bull;</span>
                    </div>
                    <div>'.$del_wall.'</div>
                    <br><br>
                    <p style="padding-left:40px; padding-top:10px;">'.$myrow['message'].'</p>
                    <hr>
                </div>
            ';
        }
    }
    
    if ($live_next) {
        $body_comments = $body_comments. '
        <p id="id_search_more_wall" style="text-align:center;"><button id="but_add" type="button" class="btn btn-sm" onClick="more=true; page='.($page+1).'; loadwall();">'.$lang[561].'</button></p>
        ';
    }
    
    mysql_close($msconnect);
    return $body_comments;
}
?>