<?php
function topsearch($top_query) {
    include $_SERVER['DOCUMENT_ROOT'].'/inc/config.php';
    $top_query = addslashes($top_query);
    $top_query = htmlspecialchars($top_query);
    include $_SERVER['DOCUMENT_ROOT'].'/inc/sql_social.php';

    $pb = '  ';
    for ($a=0; $a<10; $a++) {
        $top_query = str_replace($pb, ' ', $top_query);
        $pb = $pb.' ';
    }
    
    $sql = '';
    $arr_query = explode(' ', $top_query);
    $firstname = $arr_query[0];
    $lastname = $arr_query[1];
    if ($firstname) {
        $z_firstname_id = mysql_query("SELECT * FROM search_words WHERE word='$firstname'");
        $o_firstname_id = mysql_fetch_array($z_firstname_id);
        $firstname_id = $o_firstname_id['word_id'];
        if ($sql=='') { $sql = $sql." firstname_id='$firstname_id' "; } else { $sql = $sql." and firstname_id='$firstname_id' "; }
    }
    if ($lastname) {
        $z_lastname_id = mysql_query("SELECT * FROM search_words WHERE word='$lastname'");
        $o_lastname_id = mysql_fetch_array($z_lastname_id);
        $lastname_id = $o_lastname_id['word_id'];
        if ($sql=='') { $sql = $sql." lastname_id='$lastname_id' "; } else { $sql = $sql." and lastname_id='$lastname_id' "; }
    }
    
    if ($sql!=='') {
        $sql = ' WHERE '.$sql;
    }
    
    $body_search = '';
    $result = mysql_query("SELECT user_id FROM search_links".$sql." ORDER BY user_id ASC, user_id LIMIT 0, 5");     
    while ( $myrow = mysql_fetch_array($result) )
    {
        $user_id = $myrow['user_id'];
        $z_user_info = mysql_query("SELECT * FROM users WHERE id='$user_id'");
        $o_user_info = mysql_fetch_array($z_user_info);
        $info_firstname = $o_user_info['firstname'];
        $info_lastname = $o_user_info['lastname'];
        $info_sex = $o_user_info['sex'];
        $info_day = $o_user_info['day'];
        $info_month = $o_user_info['month'];
        if ($info_month==1) { $info_month = $lang[660]; }
        if ($info_month==2) { $info_month = $lang[661]; }
        if ($info_month==3) { $info_month = $lang[662]; }
        if ($info_month==4) { $info_month = $lang[663]; }
        if ($info_month==5) { $info_month = $lang[664]; }
        if ($info_month==6) { $info_month = $lang[665]; }
        if ($info_month==7) { $info_month = $lang[666]; }
        if ($info_month==8) { $info_month = $lang[667]; }
        if ($info_month==9) { $info_month = $lang[668]; }
        if ($info_month==10) { $info_month = $lang[669]; }
        if ($info_month==11) { $info_month = $lang[670]; }
        if ($info_month==12) { $info_month = $lang[671]; }
        $info_year = $o_user_info['year'];
        if ($info_day and $info_month and $info_year) { $info_firstday = $info_day.' '.$info_month.' '.$info_year; } else { $info_firstday = ''; }
        $info_avatar = $o_user_info['avatar'];
        $info_country_id = $o_user_info['country'];
        $info_city_id = $o_user_info['city'];
        
        $rand = rand(10000, 99999);
        $z_user_avatar = mysql_query("SELECT * FROM users WHERE id='$user_id'");
        $o_user_avatar = mysql_fetch_array($z_user_avatar);
        $user_avatar = $o_user_avatar['avatar'];
        $user_sex = $o_user_avatar['sex'];
        if ($user_avatar==0) {
            if ($user_sex==1) { $avatar = '/img/no_photo/girl.png?r='.$rand; }
            if ($user_sex==2) { $avatar = '/img/no_photo/boy.png?r='.$rand; }
        } else {
            $avatar = '/avatar/'.$user_id.'.jpg?r='.$rand;
        }
        
        $uid_online = $user_id;
        $z_user_online = mysql_query("SELECT time FROM users_to_online WHERE user_id='$uid_online'");
        $o_user_online = mysql_fetch_array($z_user_online);
        $user_online = $o_user_online['time'];
        $this_date = date('U');
        if ($user_online>($this_date-60)) {
            $user_online = ' <span class="icon-lamp" style="color:#46af48; font-size:10px;"></span>';
        } else {
            $user_online = '';
        }
        
        $body_search = $body_search.'
        <div>
            <div style="float:left;">
                <div style="float:left;">
                    <a href="/id'.$user_id.'"><img id="id_top_avatar" width="30" height="30" src="'.$avatar.'" style="border-radius:100px;"></a>
                </div>
                <div style="float:left; padding-left:10px;">
                    <a href="/id'.$user_id.'">'.$info_firstname.$user_online.'</a>
                    <br>
                    <span style="font-size:12px; color:#777;">'.$info_firstday.'</span>
                </div>
            </div>
        </div><br><br><br>
        ';
    }
    
    mysql_close($msconnect);
    return $body_search;
}
?>