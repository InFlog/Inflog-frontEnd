<?php
function all_friends($uid, $page) {
    $uid = addslashes($uid);
    $page = addslashes($page);
    
    $uid = htmlspecialchars($uid);
    $page = htmlspecialchars($page);
    
    include $_SERVER['DOCUMENT_ROOT'].'/inc/config.php';
    include $_SERVER['DOCUMENT_ROOT'].'/inc/login.php';
    if ($uid) {
        include $_SERVER['DOCUMENT_ROOT'].'/inc/sql_social.php';
        
        $body_search = '';
        $page_start = $page*10-10;
        $page_next = ($page_start+10);
        $result = mysql_query("SELECT friend_id FROM friends WHERE user_id='$uid' and status='1' ORDER BY user_id ASC, user_id LIMIT $page_start, 10"); 
        
        $z_live_next = mysql_query("SELECT friend_id FROM friends WHERE user_id='$uid' and status='1' ORDER BY user_id ASC, user_id LIMIT $page_next, 1");
        $o_live_next = mysql_fetch_array($z_live_next);
        $live_next = $o_live_next['friend_id'];
        
        while ( $myrow = mysql_fetch_array($result) )
        {
            $user_id = $myrow['friend_id'];
            $z_user_info = mysql_query("SELECT * FROM users WHERE id='$user_id'");
            $o_user_info = mysql_fetch_array($z_user_info);
            $info_firstname = $o_user_info['firstname'];
            $info_lastname = $o_user_info['lastname'];
            $info_sex = $o_user_info['sex'];
            $info_day = $o_user_info['day'];
            $info_month = $o_user_info['month'];
            if ($info_month==1) { $info_month = $lang[502]; }
            if ($info_month==2) { $info_month = $lang[503]; }
            if ($info_month==3) { $info_month = $lang[504]; }
            if ($info_month==4) { $info_month = $lang[505]; }
            if ($info_month==5) { $info_month = $lang[506]; }
            if ($info_month==6) { $info_month = $lang[507]; }
            if ($info_month==7) { $info_month = $lang[508]; }
            if ($info_month==8) { $info_month = $lang[509]; }
            if ($info_month==9) { $info_month = $lang[510]; }
            if ($info_month==10) { $info_month = $lang[511]; }
            if ($info_month==11) { $info_month = $lang[512]; }
            if ($info_month==12) { $info_month = $lang[513]; }
            $info_year = $o_user_info['year'];
            if ($info_day and $info_month and $info_year) { $info_firstday = $info_day.' '.$info_month.' '.$info_year; } else { $info_firstday = ''; }
            $info_avatar = $o_user_info['avatar'];
            $info_country_id = $o_user_info['country'];
            $info_city_id = $o_user_info['city'];

            $location_value = '';
            $z_country_name = mysql_query("SELECT * FROM net_country WHERE id='$info_country_id'");
            $o_country_name = mysql_fetch_array($z_country_name);
            if ($o_country_name) { $location_value = $o_country_name['name_'.$js_lang]; }

            $z_city_name = mysql_query("SELECT * FROM net_city WHERE id='$info_city_id'");
            $o_city_name = mysql_fetch_array($z_city_name);
            if ($o_city_name) { $location_value = $location_value.', '.$o_city_name['name_'.$js_lang]; }
            
            if (iconv_strlen($location_value, 'UTF-8')>15) {
                $location_value = mb_substr($location_value, 0, 15, 'UTF-8').'...';
            }
            
            $rand = rand(10000, 99999);
            if ($info_avatar==0) {
                if ($info_sex==1) { $avatar = '/img/no_photo/girl.png?r='.$rand; }
                if ($info_sex==2) { $avatar = '/img/no_photo/boy.png?r='.$rand; }
            } else {
                $avatar = '/avatar/'.$user_id.'.jpg?r='.$rand;
            }
            
            $uid_online = $user_id;
            $z_user_online = mysql_query("SELECT time FROM users_to_online WHERE user_id='$uid_online'");
            $o_user_online = mysql_fetch_array($z_user_online);
            $user_online = $o_user_online['time'];
            $this_date = date('U');
            if ($user_online>($this_date-60)) {
                $user_online = ' <span class="icon-lamp" style="color:#46af48; font-size:10px;"></span>';
            } else {
                $user_online = '';
            }
            
            if ($uid==$my_id) {
                $but_del = '<button type="button" class="btn btn-success btn-sm" style="width:80px; float:right;" onClick="friend_id='.$user_id.'; token=\''.md5($my_id.'_'.$user_id.'_deleteallfriends_'.$secret).'\'; delete_all_friends();">'.$lang[514].'</button>';
            } else {
                $but_del = '';
            }
            
            $body_search = $body_search.'
            <div id="friend_all_'.$user_id.'">
                <div style="width:75%; float:left;">
                    <div style="float:left;">
                        <a href="/id'.$user_id.'"><img id="id_top_avatar" width="50" height="50" src="'.$avatar.'" style="border-radius:100px;"></a>
                    </div>
                    <div style="float:left; padding-left:10px;">
                        <a href="/id'.$user_id.'">'.$info_firstname.' '.$info_lastname.$user_online.'</a>
                        <br>
                        <span style="font-size:12px; color:#777;">'.$info_firstday.'</span>
                        <br>
                        <span style="font-size:12px; color:#777;">'.$location_value.'</span>
                    </div>
                </div>
                <div style="width:25%; float:right;">
                    <div style="float:right;">
                        '.$but_del.'
                    </div>
                </div>
                <br><br><br>
                <hr style="margin-top:15px; margin-bottom:15px;">
            </div>
            ';
        }
        
        if ($live_next) {
            $body_search = $body_search.'
            <p id="id_friends_more_all" style="text-align:center;"><button id="but_add" type="button" class="btn btn-sm" onClick="more=true; page='.($page+1).'; start_all_friends();">'.$lang[515].'</button></p>
            ';
        }
        
        mysql_close($msconnect);
        return $body_search;
    }
}
?>