<?php
function search($query, $country, $city, $sex, $age_from, $age_to, $marital_status, $online_id, $page) {
    include $_SERVER['DOCUMENT_ROOT'].'/inc/config.php';
    $query = addslashes($query);
    $country = addslashes($country);
    $city = addslashes($city);
    $sex = addslashes($sex);
    $age_from = addslashes($age_from);
    $age_to = addslashes($age_to);
    $marital_status = addslashes($marital_status);
    $online_id = addslashes($online_id);
    $page = addslashes($page);
    
    $query = htmlspecialchars($query);
    $country = htmlspecialchars($country);
    $city = htmlspecialchars($city);
    $sex = htmlspecialchars($sex);
    $age_from = htmlspecialchars($age_from);
    $age_to = htmlspecialchars($age_to);
    $marital_status = htmlspecialchars($marital_status);
    $online_id = htmlspecialchars($online_id);
    $page = htmlspecialchars($page);
    
    $arr = Array();
    include $_SERVER['DOCUMENT_ROOT'].'/inc/login.php';
    include $_SERVER['DOCUMENT_ROOT'].'/inc/sql_social.php';

    $pb = '  ';
    for ($a=0; $a<10; $a++) {
        $query = str_replace($pb, ' ', $query);
        $pb = $pb.' ';
    }
    
    $sql = '';
    $arr_query = explode(' ', $query);
    $firstname = $arr_query[0];
    $lastname = $arr_query[1];
    if ($firstname) {
        $z_firstname_id = mysql_query("SELECT * FROM search_words WHERE word='$firstname'");
        $o_firstname_id = mysql_fetch_array($z_firstname_id);
        $firstname_id = $o_firstname_id['word_id'];
        if ($sql=='') { $sql = $sql." firstname_id='$firstname_id' "; } else { $sql = $sql." and firstname_id='$firstname_id' "; }
    }
    if ($lastname) {
        $z_lastname_id = mysql_query("SELECT * FROM search_words WHERE word='$lastname'");
        $o_lastname_id = mysql_fetch_array($z_lastname_id);
        $lastname_id = $o_lastname_id['word_id'];
        if ($sql=='') { $sql = $sql." lastname_id='$lastname_id' "; } else { $sql = $sql." and lastname_id='$lastname_id' "; }
    }
    if ($country==$lang[642]) { $country = ''; }
    $z_country_id = mysql_query("SELECT * FROM net_country WHERE name_$js_lang='$country'");
    $o_country_id = mysql_fetch_array($z_country_id);
    $country_id = $o_country_id['id'];
    if ($country_id) {
        if ($sql=='') { $sql = $sql." country_id='$country_id' "; } else { $sql = $sql." and country_id='$country_id' "; }
    }
    if ($city==$lang[643]) { $city = ''; }
    $z_city_id = mysql_query("SELECT * FROM net_city WHERE name_$js_lang='$city'");
    $o_city_id = mysql_fetch_array($z_city_id);
    $city_id = $o_city_id['id'];
    if ($city_id) {
        if ($sql=='') { $sql = $sql." city_id='$city_id' "; } else { $sql = $sql." and city_id='$city_id' "; }
    }
    if ($sex==$lang[644]) { $sex_id = 1; }
    if ($sex==$lang[645]) { $sex_id = 2; }
    if ($sex==$lang[646]) { $sex_id = ''; }
    if ($sex_id) {
        if ($sql=='') { $sql = $sql." sex_id='$sex_id' "; } else { $sql = $sql." and sex_id='$sex_id' "; }
    }
    if ($age_from==$lang[647]) { $age_from = ''; }
    if ($age_from) {
        $d_from = intval(date('Y'))-intval($age_from);
        if ($sql=='') { $sql = $sql." year<='$d_from' "; } else { $sql = $sql." and year<='$d_from' "; }
    }
    if ($age_to==$lang[648]) { $age_to = ''; }
    if ($age_to) {
        $d_to = intval(date('Y'))-intval($age_to);
        if ($sql=='') { $sql = $sql." year>='$d_to' "; } else { $sql = $sql." and year>='$d_to' "; }
    }
    if ($marital_status==$lang[649]) { $marital_status_id = ''; }
    if ($marital_status==$lang[650]) { $marital_status_id = 1; }
    if ($marital_status==$lang[651]) { $marital_status_id = 2; }
    if ($marital_status==$lang[652]) { $marital_status_id = 3; }
    if ($marital_status==$lang[653]) { $marital_status_id = 4; }
    if ($marital_status==$lang[654]) { $marital_status_id = 5; }
    if ($marital_status==$lang[655]) { $marital_status_id = 6; }
    if ($marital_status==$lang[656]) { $marital_status_id = 7; }
    if ($marital_status_id) {
        if ($sql=='') { $sql = $sql." marital_status_id='$marital_status_id' "; } else { $sql = $sql." and marital_status_id='$marital_status_id' "; }
    }
    
    if ($online_id==$lang[673]) {
        $search_date = date('U')-60;
        if ($sql=='') { $sql = $sql." time>'$search_date' "; } else { $sql = $sql." and time>'$search_date' "; }
    }
    
    
    
    
    if ($sql!=='') {
        $sql = ' WHERE '.$sql;
    }
    
    $body_search = '';
    $page_start = $page*10-10;
    $page_next = ($page_start+10);
    $result = mysql_query("SELECT user_id FROM search_links".$sql." ORDER BY user_id ASC, user_id LIMIT $page_start, 10"); 
    
    $z_live_next = mysql_query("SELECT user_id FROM search_links".$sql." ORDER BY user_id ASC, user_id LIMIT $page_next, 1");
    $o_live_next = mysql_fetch_array($z_live_next);
    $live_next = $o_live_next['user_id'];
    
    $z_search_count = mysql_query("SELECT user_id FROM search_links".$sql."");
    $search_count = mysql_num_rows($z_search_count);
    
    while ( $myrow = mysql_fetch_array($result) )
    {
        $user_id = $myrow['user_id'];
        $z_user_info = mysql_query("SELECT * FROM users WHERE id='$user_id'");
        $o_user_info = mysql_fetch_array($z_user_info);
        $info_firstname = $o_user_info['firstname'];
        $info_lastname = $o_user_info['lastname'];
        $info_sex = $o_user_info['sex'];
        $info_day = $o_user_info['day'];
        $info_month = $o_user_info['month'];
        if ($info_month==1) { $info_month = $lang[674]; }
        if ($info_month==2) { $info_month = $lang[675]; }
        if ($info_month==3) { $info_month = $lang[676]; }
        if ($info_month==4) { $info_month = $lang[677]; }
        if ($info_month==5) { $info_month = $lang[678]; }
        if ($info_month==6) { $info_month = $lang[679]; }
        if ($info_month==7) { $info_month = $lang[680]; }
        if ($info_month==8) { $info_month = $lang[681]; }
        if ($info_month==9) { $info_month = $lang[682]; }
        if ($info_month==10) { $info_month = $lang[683]; }
        if ($info_month==11) { $info_month = $lang[684]; }
        if ($info_month==12) { $info_month = $lang[685]; }
        $info_year = $o_user_info['year'];
        if ($info_day and $info_month and $info_year) { $info_firstday = $info_day.' '.$info_month.' '.$info_year; } else { $info_firstday = ''; }
        $info_avatar = $o_user_info['avatar'];
        $info_country_id = $o_user_info['country'];
        $info_city_id = $o_user_info['city'];

        $location_value = '';
        $z_country_name = mysql_query("SELECT * FROM net_country WHERE id='$info_country_id'");
        $o_country_name = mysql_fetch_array($z_country_name);
        if ($o_country_name) { $location_value = $o_country_name['name_'.$js_lang]; }

        $z_city_name = mysql_query("SELECT * FROM net_city WHERE id='$info_city_id'");
        $o_city_name = mysql_fetch_array($z_city_name);
        if ($o_city_name) { $location_value = $location_value.', '.$o_city_name['name_'.$js_lang]; }
        
        $rand = rand(10000, 99999);
        if ($info_avatar==0) {
            if ($info_sex==1) { $avatar = '/img/no_photo/girl.png?r='.$rand; }
            if ($info_sex==2) { $avatar = '/img/no_photo/boy.png?r='.$rand; }
        } else {
            $avatar = '/avatar/'.$user_id.'.jpg?r='.$rand;
        }
        
        if ($user_id!==$my_id) {
            $z_live_addfriend = mysql_query("SELECT user_id FROM friends WHERE user_id='$my_id' and friend_id='$user_id' and status='1'");
            $o_live_addfriend = mysql_fetch_array($z_live_addfriend);
            $live_addfriend = $o_live_addfriend['user_id'];
            
            if (!$live_addfriend) {
                $button_add_friend = '<button type="button" class="btn btn-success btn-sm" style="width:80px; float:right;" onClick="friend_id='.$user_id.'; token=\''.md5($my_id.'_'.$user_id.'_addfriend_'.$secret).'\'; add_friend(); this.style.display=\'none\';">'.$lang[657].'</button>';
            } else {
                $button_add_friend = '<a href="/'.$link[2].'?id='.$user_id.'"><button type="button" class="btn btn-success btn-sm" style="width:80px; float:right;">'.$lang[658].'</button></a>';
            }
        } else {
            $button_add_friend = '';
        }
        
        $uid_online = $user_id;
        $z_user_online = mysql_query("SELECT time FROM users_to_online WHERE user_id='$uid_online'");
        $o_user_online = mysql_fetch_array($z_user_online);
        $user_online = $o_user_online['time'];
        $this_date = date('U');
        if ($user_online>($this_date-60)) {
            $user_online = ' <span class="icon-lamp" style="color:#46af48; font-size:10px;"></span>';
        } else {
            $user_online = '';
        }
        
        if (iconv_strlen($location_value, 'UTF-8')>15) {
            $location_value = mb_substr($location_value, 0, 15, 'UTF-8').'...';
        }
        
        if ($my_id) {
            $body_search = $body_search.'
            <div>
                <div style="width:75%; float:left;">
                    <div style="float:left;">
                        <a href="/id'.$user_id.'"><img id="id_top_avatar" width="50" height="50" src="'.$avatar.'" style="border-radius:100px;"></a>
                    </div>
                    <div style="float:left; padding-left:10px;">
                        <a href="/id'.$user_id.'">'.$info_firstname.$user_online.'</a>
                        <br>
                        <span style="font-size:12px; color:#777;">'.$info_firstday.'</span>
                        <br>
                        <span style="font-size:12px; color:#777;">'.$location_value.'</span>
                    </div>
                </div>
                <div style="width:25%; float:right;">
                    <div style="float:right;">
                        '.$button_add_friend.'
                    </div>
                </div>
                <br><br><br>
            </div>
            <hr style="margin-top:15px; margin-bottom:15px;">
            ';
        } else {
            $body_search = $body_search.'
            <div>
                <div style="float:left;">
                    <div style="float:left;">
                        <a href="/id'.$user_id.'"><img id="id_top_avatar" width="50" height="50" src="'.$avatar.'" style="border-radius:100px;"></a>
                    </div>
                    <div style="float:left; padding-left:10px;">
                        <a href="/id'.$user_id.'">'.$info_firstname.$user_online.'</a>
                        <br>
                        <span style="font-size:12px; color:#777;">'.$info_firstday.'</span>
                        <br>
                        <span style="font-size:12px; color:#777;">'.$location_value.'</span>
                    </div>
                </div>
                <br><br><br>
            </div>
            <hr style="margin-top:15px; margin-bottom:15px;">
            ';
        }
    }
    
    if ($live_next) {
        $body_search = $body_search.'
        <p id="id_search_more" style="text-align:center;"><button id="but_add" type="button" class="btn btn-sm" onClick="more=true; page='.($page+1).'; start_search();">'.$lang[659].'</button></p>
        ';
    }
    
    $arr[0] = $body_search;
    $arr[1] = $search_count;
    mysql_close($msconnect);
    return $arr;
}
?>