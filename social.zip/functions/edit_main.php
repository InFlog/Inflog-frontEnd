<?php
function edit_main($firstname, $lastname, $sex, $day, $month, $year, $marital_status, $country, $city, $token) {
    include $_SERVER['DOCUMENT_ROOT'].'/inc/config.php';
    include $_SERVER['DOCUMENT_ROOT'].'/inc/login.php';
    if ($token == md5($my_id.'_main_'.$secret) and $my_id) {
        $firstname = addslashes($firstname);
        $lastname = addslashes($lastname);
        $sex = addslashes($sex);
        $day = addslashes($day);
        $month = addslashes($month);
        $year = addslashes($year);
        $marital_status = addslashes($marital_status);
        $country = addslashes($country);
        $city = addslashes($city);
        
        $firstname = htmlspecialchars($firstname);
        $lastname = htmlspecialchars($lastname);
        $sex = htmlspecialchars($sex);
        $day = htmlspecialchars($day);
        $month = htmlspecialchars($month);
        $year = htmlspecialchars($year);
        $marital_status = htmlspecialchars($marital_status);
        $country = htmlspecialchars($country);
        $city = htmlspecialchars($city);
        
        include $_SERVER['DOCUMENT_ROOT'].'/inc/login.php';
        if ($my_id) {
        $live_edit = true;

        if (mb_strlen($firstname, 'UTF-8')<2) { $live_edit = false;    }
        if (ctype_digit($firstname)) { $live_edit = false; }

        if (mb_strlen($lastname, 'UTF-8')<2) { $live_edit = false;    }
        if (ctype_digit($lastname)) { $live_edit = false; }

        $isex = '';
        if ($sex==$lang[519]) { $isex = '1'; }
        if ($sex==$lang[520]) { $isex = '2'; }
        if ($isex=='') { $live_edit = false; }

        if ($day>0 and $day<32) {} else { $live_edit = false; }

        $imonth = '';
        if ($month==$lang[521]) { $imonth = '1'; }
        if ($month==$lang[522]) { $imonth = '2'; }
        if ($month==$lang[523]) { $imonth = '3'; }
        if ($month==$lang[524]) { $imonth = '4'; }
        if ($month==$lang[525]) { $imonth = '5'; }
        if ($month==$lang[526]) { $imonth = '6'; }
        if ($month==$lang[527]) { $imonth = '7'; }
        if ($month==$lang[528]) { $imonth = '8'; }
        if ($month==$lang[529]) { $imonth = '9'; }
        if ($month==$lang[530]) { $imonth = '10'; }
        if ($month==$lang[531]) { $imonth = '11'; }
        if ($month==$lang[532]) { $imonth = '12'; }
        if ($imonth=='') { $live_edit = false; }

        if ($year>1954 and $year<2006) {} else { $live_edit = false; }
        if ($marital_status>-1 and $marital_status<8) {} else { $live_edit = false; }
        
        if ($country==$lang[533]) { $country = ''; }
        if ($city==$lang[534]) { $city = ''; }
        
        include $_SERVER['DOCUMENT_ROOT'].'/inc/sql_social.php';
        
        if ($country!=='') {
            $z_country_id = mysql_query("SELECT * FROM net_country WHERE name_$js_lang='$country'");
            $o_country_id = mysql_fetch_array($z_country_id);
            $country_id = $o_country_id['id'];
            
            if (!$country_id) { $live_edit = false; }
        }
        
        if ($city!=='') {
            $z_city_id = mysql_query("SELECT * FROM net_city WHERE name_$js_lang='$city'");
            $o_city_id = mysql_fetch_array($z_city_id);
            $city_id = $o_city_id['id'];
            
            if (!$city_id) { $live_edit = false; }
        }
        
        if ($live_edit) {
            mysql_query("UPDATE users SET firstname='$firstname', lastname='$lastname', sex='$isex', day='$day', month='$imonth', year='$year', marital_status='$marital_status', country='$country_id', city='$city_id' WHERE id='$my_id'");
        
            $z_firstname_id = mysql_query("SELECT * FROM search_words WHERE word='$firstname'");
            $o_firstname_id = mysql_fetch_array($z_firstname_id);
            $firstname_id = $o_firstname_id['word_id'];
            
            if (!$firstname_id) {
                mysql_query("INSERT search_words SET word='$firstname'");
                $z_firstname_id = mysql_query("SELECT * FROM search_words WHERE word='$firstname'");
                $o_firstname_id = mysql_fetch_array($z_firstname_id);
                $firstname_id = $o_firstname_id['word_id'];    
            }
            
            $z_lastname_id = mysql_query("SELECT * FROM search_words WHERE word='$lastname'");
            $o_lastname_id = mysql_fetch_array($z_lastname_id);
            $lastname_id = $o_lastname_id['word_id'];
            
            if (!$lastname_id) {
                mysql_query("INSERT search_words SET word='$lastname'");
                $z_lastname_id = mysql_query("SELECT * FROM search_words WHERE word='$lastname'");
                $o_lastname_id = mysql_fetch_array($z_lastname_id);
                $lastname_id = $o_lastname_id['word_id'];
            }
            
            mysql_query("UPDATE search_links SET firstname_id='$firstname_id', lastname_id='$lastname_id', sex_id='$isex', year='$year', marital_status_id='$marital_status', country_id='$country_id', city_id='$city_id' WHERE user_id='$my_id'");
        
        
        }
        mysql_close($msconnect);
        
        return $live_edit;
        }
    }
}
?>