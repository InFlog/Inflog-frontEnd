<?php
function save_photo($photo_id, $uid, $token) {
    include $_SERVER['DOCUMENT_ROOT'].'/inc/config.php';
    $photo_id = addslashes($photo_id);
    $uid = addslashes($uid);
    
    $photo_id = htmlspecialchars($photo_id);
    $uid = htmlspecialchars($uid);
    include $_SERVER['DOCUMENT_ROOT'].'/inc/login.php';
    if ($token == md5($my_id.'_'.$uid.'_savephoto_'.$secret) and $my_id) {
        include $_SERVER['DOCUMENT_ROOT'].'/inc/sql_social.php';
        
        $date = date('U');
        
        $z_user_info = mysql_query("SELECT * FROM users WHERE id='$uid'");
        $o_user_info = mysql_fetch_array($z_user_info);
        $info_firstname = $o_user_info['firstname'];
        $info_lastname = $o_user_info['lastname'];
        
        $z_photo_name = mysql_query("SELECT * FROM photo_to_users WHERE photo_id='$photo_id'");
        $o_photo_name = mysql_fetch_array($z_photo_name);
        $photo_name = $o_photo_name['photo_name'];
        
        if ($uid==$my_id) {
            $message = '';
        } else {
            $message = $lang[641].' <a href="/id'.$uid.'"><b>'.$info_firstname.' '.$info_lastname.'</b></a>';
        }
        
        mysql_query("INSERT wall SET user_id='$my_id', page_id='$my_id', message='$message', photos='$photo_name', date='$date'");
        
        mysql_close($msconnect);
    }
}
?>