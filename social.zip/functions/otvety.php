<?php
function otvety($more, $page, $token) {
    include $_SERVER['DOCUMENT_ROOT'].'/inc/config.php';
    $more = addslashes($more);
    $page = addslashes($page);
    
    $more = htmlspecialchars($more);
    $page = htmlspecialchars($page);
    
    $arr = Array();
    include $_SERVER['DOCUMENT_ROOT'].'/inc/login.php';
    if ($token==md5($my_id.'_otvety_'.$secret) and $my_id) {
        include $_SERVER['DOCUMENT_ROOT'].'/inc/sql_social.php';
        
        
        $body_news = '';
        $page_start = $page*10-10;
        $page_next = ($page_start+10);
        $result = mysql_query("SELECT * FROM news WHERE user_to='$my_id' ORDER BY news_id DESC, news_id LIMIT $page_start, 10"); 
        
        $z_live_next = mysql_query("SELECT news_id FROM news WHERE user_to='$my_id' ORDER BY news_id DESC, news_id LIMIT $page_next, 1");
        $o_live_next = mysql_fetch_array($z_live_next);
        $live_next = $o_live_next['news_id'];
        
        $z_news_count = mysql_query("SELECT news_id FROM news WHERE user_to='$my_id'");
        $news_count = mysql_num_rows($z_news_count);
        
        while ( $myrow = mysql_fetch_array($result) )
        {
            $user_id = $myrow['user_from'];
            $z_user_info = mysql_query("SELECT * FROM users WHERE id='$user_id'");
            $o_user_info = mysql_fetch_array($z_user_info);
            $info_firstname = $o_user_info['firstname'];
            $info_sex = $o_user_info['sex'];
            $info_avatar = $o_user_info['avatar'];
            
            $time = date("d.m.Y H:i", $myrow['time']);
            $rand = rand(10000, 99999);
            if ($info_avatar==0) {
                if ($info_sex==1) { $avatar = '/img/no_photo/girl.png?r='.$rand; }
                if ($info_sex==2) { $avatar = '/img/no_photo/boy.png?r='.$rand; }
            } else {
                $avatar = '/avatar/'.$user_id.'.jpg?r='.$rand;
            }
            
            if ($info_sex==1) {
                $t1 = $lang[563]; $t2 = $lang[564]; $t3 = $lang[565]; 
            } else {
                $t1 = $lang[566]; $t2 = $lang[567]; $t3 = $lang[568];
            }
            
            $uid_online = $myrow['user_from'];
            $z_user_online = mysql_query("SELECT time FROM users_to_online WHERE user_id='$uid_online'");
            $o_user_online = mysql_fetch_array($z_user_online);
            $user_online = $o_user_online['time'];
            $this_date = date('U');
            if ($user_online>($this_date-60)) {
                $user_online = ' <span class="icon-lamp" style="color:#46af48; font-size:10px;"></span>';
            } else {
                $user_online = '';
            }
            
            
            if ($myrow['news_type']==1) {
                $photo_id = $myrow['object_id'];
                $z_photo_name = mysql_query("SELECT photo_name FROM photo_to_users WHERE photo_id='$photo_id'");
                $o_photo_name = mysql_fetch_array($z_photo_name);
                $photo_name = $o_photo_name['photo_name'];
                
                $news_text = '<b>'.$info_firstname.'</b> '.$t1.' '.$lang[573].'<br><div style="width:45px; height:45px; margin-left:40px; background-image:url(\'/photo/m_'.$photo_name.'.jpg\'); background-size:cover; background-position:center top; border-radius:4px;"></div><span class="icon-heart" style="position:relative; margin-top:-52px; margin-left:67px; padding:5px; font-size:14px; background:#ecf1f5; color:#5085ad; border-radius:4px; float:left;"></span>';
            }
            
            if ($myrow['news_type']==2) {
                $photo_id = $myrow['object_id'];
                
                $z_photo_name = mysql_query("SELECT photo_name FROM photo_to_users WHERE photo_id='$photo_id'");
                $o_photo_name = mysql_fetch_array($z_photo_name);
                $photo_name = $o_photo_name['photo_name'];
                
                $news_text = '<b>'.$info_firstname.'</b> '.$t1.' '.$lang[569].'<br><div style="width:45px; height:45px; margin-left:40px; background-image:url(\'/photo/m_'.$photo_name.'.jpg\'); background-size:cover; background-position:center top; border-radius:4px;"></div><span class="icon-heart" style="position:relative; margin-top:-52px; margin-left:67px; padding:5px; font-size:14px; background:#ecf1f5; color:#5085ad; border-radius:4px; float:left;"></span>';
            }
            
            if ($myrow['news_type']==3) {
                $comments_id = $myrow['object_id'];
                $news_text = '<b>'.$info_firstname.'</b> '.$t1.' '.$lang[570].'<br><div class="icon-newspaper" style="width:45px; height:45px; margin-left:40px; background:#86a8c1; color:#fff; background-size:cover; background-position:center top; border-radius:4px; font-size:24px; padding:10px;"></div><span class="icon-heart" style="position:relative; margin-top:-52px; margin-left:67px; padding:5px; font-size:14px; background:#ecf1f5; color:#5085ad; border-radius:4px; float:left;"></span>';
            }
            
            if ($myrow['news_type']==4) {
                $photo_id = $myrow['object_id'];
                $z_photo_name = mysql_query("SELECT photo_name FROM photo_to_users WHERE photo_id='$photo_id'");
                $o_photo_name = mysql_fetch_array($z_photo_name);
                $photo_name = $o_photo_name['photo_name'];
                
                $news_text = '<b>'.$info_firstname.'</b> '.$t2.' '.$lang[571].'<br><div style="width:45px; height:45px; margin-left:40px; background-image:url(\'/photo/m_'.$photo_name.'.jpg\'); background-size:cover; background-position:center top; border-radius:4px;"></div><span class="icon-pencil" style="position:relative; margin-top:-52px; margin-left:67px; padding:5px; font-size:14px; background:#ecf1f5; color:#5085ad; border-radius:4px; float:left;"></span>';
            }
            
            if ($myrow['news_type']==5) {
                $news_text = '<b>'.$info_firstname.'</b> '.$t2.' '.$lang[572].'<br><div class="icon-newspaper" style="width:45px; height:45px; margin-left:40px; background:#86a8c1; color:#fff; background-size:cover; background-position:center top; border-radius:4px; font-size:24px; padding:10px;"></div><span class="icon-pencil" style="position:relative; margin-top:-52px; margin-left:67px; padding:5px; font-size:14px; background:#ecf1f5; color:#5085ad; border-radius:4px; float:left;"></span>';
            }
            
            if ($myrow['news_type']==6) {
                $photo_id = $myrow['object_id'];
                $z_photo_name = mysql_query("SELECT photo_name FROM photo_to_users WHERE photo_id='$photo_id'");
                $o_photo_name = mysql_fetch_array($z_photo_name);
                $photo_name = $o_photo_name['photo_name'];
                
                $news_text = '<b>'.$info_firstname.'</b> '.$t1.' '.$lang[573].'<br><div style="width:45px; height:45px; margin-left:40px; background-image:url(\'/photo/m_'.$photo_name.'.jpg\'); background-size:cover; background-position:center top; border-radius:4px;"></div><span class="icon-heart" style="position:relative; margin-top:-52px; margin-left:67px; padding:5px; font-size:14px; background:#ecf1f5; color:#5085ad; border-radius:4px; float:left;"></span>';
            }
            
            if ($myrow['news_type']==7) {
                $news_text = '<b>'.$info_firstname.'</b> '.$t1.' '.$lang[574].'<br><div class="icon-newspaper" style="width:45px; height:45px; margin-left:40px; background:#86a8c1; color:#fff; background-size:cover; background-position:center top; border-radius:4px; font-size:24px; padding:10px;"></div><span class="icon-heart" style="position:relative; margin-top:-52px; margin-left:67px; padding:5px; font-size:14px; background:#ecf1f5; color:#5085ad; border-radius:4px; float:left;"></span>';
            }
            
            if ($myrow['news_type']==8) {
                $news_text = '<b>'.$info_firstname.'</b> '.$t3.' '.$lang[575].'<br><div style="width:45px; height:45px; margin-left:40px; background-image:url(\''.$avatar.'\'); background-size:cover; background-position:center top; border-radius:4px;"></div><span class="icon-user2" style="position:relative; margin-top:-52px; margin-left:67px; padding:5px; font-size:14px; background:#ecf1f5; color:#5085ad; border-radius:4px; float:left;"></span>';
            }
            
            $body_news = $body_news.'
            <div>
                <div>
                    <div style="float:left;">
                        <a href="/id'.$user_id.'"><img id="id_top_avatar" width="30" height="30" src="'.$avatar.'" style="border-radius:100px;"></a>
                    </div>
                    <div style="float:left; padding-left:10px; text-align:left;">
                        <a href="/id'.$user_id.'">'.$info_firstname.$user_online.'</a>
                        <br>
                        <span style="font-size:11px; color:#777;">'.$time.'</span>
                    </div>
                </div>
                <br><br>
                <p style="padding-left:40px; padding-top:10px; text-align:left;">'.$news_text.'</p>
                <hr>
            </div>
            ';
        }
        
        if ($live_next) {
            $body_news = $body_news.'
            <p id="id_otvety_more_all" style="text-align:center;"><button id="but_add" type="button" class="btn btn-sm" onClick="token=\''.md5($my_id.'_otvety_'.$secret).'\'; more=true; page='.($page+1).'; otvety();">'.$lang[576].'</button></p>
            ';
        }
        mysql_query("UPDATE news SET status='0' WHERE user_to='$my_id'");
        
        $arr[0] = $body_news;
        $arr[1] = $news_count;
        mysql_close($msconnect);
        return $arr;
    }
}
?>