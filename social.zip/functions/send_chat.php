<?php
function send_chat($comment_chat, $str_chat_photos, $talk_id, $token) {
    include $_SERVER['DOCUMENT_ROOT'].'/inc/config.php';
    $comment_chat = addslashes($comment_chat);
    $page_id = addslashes($page_id);
    $str_chat_photos = addslashes($str_chat_photos);
    
    
    $comment_chat = htmlspecialchars($comment_chat);
    $page_id = htmlspecialchars($page_id);
    $str_chat_photos = htmlspecialchars($str_chat_photos);
    
    include $_SERVER['DOCUMENT_ROOT'].'/inc/login.php';
    if ($token == md5($my_id.'_sendchat_'.$secret) and $my_id) {
        include $_SERVER['DOCUMENT_ROOT'].'/inc/sql_social.php';
        $this_date = date('U');
        mysql_query("INSERT chat SET user_id='$my_id', message='$comment_chat', photos='$str_chat_photos', date='$this_date', talk_id='$talk_id'");
        mysql_close($msconnect);
    }
}
?>