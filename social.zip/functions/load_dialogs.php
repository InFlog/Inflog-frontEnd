<?php
function load_dialogs($page, $dialogs_type, $token) {
    include $_SERVER['DOCUMENT_ROOT'].'/inc/config.php';
    $page = addslashes($page);
    $dialogs_type = addslashes($dialogs_type);
    
    $page = htmlspecialchars($page);
    $dialogs_type = htmlspecialchars($dialogs_type);
    $arr = Array();
    include $_SERVER['DOCUMENT_ROOT'].'/inc/login.php';
    if ($token == md5($my_id.'_loaddialogs_'.$secret) and $my_id) {
        include $_SERVER['DOCUMENT_ROOT'].'/inc/sql_social.php';
        
        $body_dialogs = '';
        $page_start = $page*10-10;
        $page_next = ($page_start+10);
        if ($dialogs_type=='1') {
            $result = mysql_query("SELECT DISTINCT (dialog_id) FROM dialogs WHERE user_to='$my_id' OR user_from='$my_id' ORDER BY date DESC, dialog_id LIMIT $page_start, 10");
        } else {
            $result = mysql_query("SELECT DISTINCT (dialog_id) FROM dialogs WHERE user_to='$my_id' and status='1' ORDER BY date DESC, dialog_id LIMIT $page_start, 10");
        }
        
        if ($dialogs_type=='1') {
            $z_live_next = mysql_query("SELECT dialog_id FROM dialogs WHERE user_to='$my_id' OR user_from='$my_id' ORDER BY date DESC, dialog_id LIMIT $page_next, 1");
        } else {
            $z_live_next = mysql_query("SELECT dialog_id FROM dialogs WHERE user_to='$my_id' and status='1' ORDER BY date DESC, dialog_id LIMIT $page_next, 1");
        }
        $o_live_next = mysql_fetch_array($z_live_next);
        $live_next = $o_live_next['dialog_id'];
        
        while ( $myrow = mysql_fetch_array($result) )
        {
            $dialog_id = $myrow['dialog_id'];
            $z_dialog_info = mysql_query("SELECT * FROM dialogs WHERE dialog_id='$dialog_id'");
            $o_dialog_info = mysql_fetch_array($z_dialog_info);
            $user_from = $o_dialog_info['user_from'];
            $user_to = $o_dialog_info['user_to'];
            $status = $o_dialog_info['status'];
            $message = $o_dialog_info['message'];
            $photos = $o_dialog_info['photos'];
            $date = $o_dialog_info['date'];
            
            if ($status=='1') {
                $new_bg = 'background:#f5f5f5;';
            } else {
                $new_bg = 'background:#fff;';
            }

            if ($user_from!==$my_id) {
                $user_send = $user_from;
            } else {
                $user_send = $user_to;
            }
            
            $z_user_info = mysql_query("SELECT * FROM users WHERE id='$user_send'");
            $o_user_info = mysql_fetch_array($z_user_info);
            $info_firstname = $o_user_info['firstname'];
            
            $rand = rand(10000, 99999);
            $z_user_avatar = mysql_query("SELECT * FROM users WHERE id='$user_send'");
            $o_user_avatar = mysql_fetch_array($z_user_avatar);
            $user_avatar = $o_user_avatar['avatar'];
            $user_sex = $o_user_avatar['sex'];
            if ($user_avatar==0) {
                if ($user_sex==1) { $avatar = '/img/no_photo/girl.png?r='.$rand; }
                if ($user_sex==2) { $avatar = '/img/no_photo/boy.png?r='.$rand; }
            } else {
                $avatar = '/avatar/'.$user_send.'.jpg?r='.$rand;
            }
            
            $z_user_online = mysql_query("SELECT time FROM users_to_online WHERE user_id='$user_send'");
            $o_user_online = mysql_fetch_array($z_user_online);
            $user_online = $o_user_online['time'];
            $this_date = date('U');
            if ($user_online>($this_date-60)) {
                $user_online = ' <span class="icon-lamp" style="color:#46af48; font-size:10px;"></span>';
            } else {
                $user_online = '';
            }
            
            $date = date("d.m.Y H:i", $date);
            $z_message = mysql_query("SELECT * FROM messages WHERE user_from='$my_id' and user_to='$user_send' OR user_to='$my_id' and user_from='$user_send' ORDER BY message_id DESC");
            $o_message = mysql_fetch_array($z_message);
            $message = $o_message['message']; 
            $photos = $o_message['photos']; 
            
            if ($photos) {
                $message = $lang[688];
            } else {
                $arr_stickers = explode('&lt;smile', $message);
                if (count($arr_stickers)>1) {
                $message = $lang[689];
                } else {
                    if (iconv_strlen($message, 'UTF-8')>15) {
                        $message = mb_substr($message, 0, 15, 'UTF-8').'...';
                    } else {
                        $message = mb_substr($message, 0, 15, 'UTF-8');
                    }
                }
            }
            
            $body_dialogs = $body_dialogs.'
                <div style="padding:15px; '.$new_bg.'">
                    <div style="width:75%; float:left;">
                        <div style="float:left;">
                            <a href="/id'.$user_send.'"><img id="id_top_avatar" width="50" height="50" src="'.$avatar.'" style="border-radius:100px;"></a>
                        </div>
                        <div style="float:left; padding-left:10px;">
                            <a href="/id'.$user_send.'">'.$info_firstname.$user_online.'</a>
                            <br>
                            <span style="font-size:12px; color:#777;">'.$date.'</span>
                            <br>
                            <span style="font-size:12px; color:#333;">'.$message.'</span>
                        </div>
                        <div><div class="row"></div></div>
                    </div>
                    <div style="width:25%; float:right;">
                        <div style="float:right;">
                            <a href="/'.$link[2].'?id='.$user_send.'"><button type="button" class="btn btn-primary btn-sm" style="width:80px; float:right;">'.$lang[556].'</button></a>
                        </div>
                    </div>
                    <div><div class="row"></div></div>
                </div>
                <hr style="margin-top:0px; margin-bottom:0px;">
            ';
        }
        
        if ($live_next) {
            $body_dialogs = $body_dialogs.'
            <p id="id_dialogs_more" style="text-align:center; margin-top:20px;"><button id="but_add" type="button" class="btn btn-sm" onClick="more=true; page='.($page+1).'; token=\''.md5($my_id.'_loaddialogs_'.$secret).'\'; load_dialogs();">'.$lang[557].'</button></p>
            ';
        }
        
        if ($dialogs_type=='1') {
            $z_count_my_dialogs = mysql_query("SELECT dialog_id FROM dialogs WHERE user_to='$my_id' OR user_from='$my_id'");
            $count_my_dialogs = mysql_num_rows($z_count_my_dialogs);
        } else {
            $z_count_my_dialogs = mysql_query("SELECT dialog_id FROM dialogs WHERE user_to='$my_id' and status='1'");
            $count_my_dialogs = mysql_num_rows($z_count_my_dialogs);
        }
        
        mysql_close($msconnect);
        $arr[0] = $body_dialogs;
        $arr[1] = $count_my_dialogs;
        
        return $arr;
    }
}
?>