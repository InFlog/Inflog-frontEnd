<?php
function edit_position($policy, $world_view, $important_live, $important_peoples, $smoking, $alcohol, $inspirations, $token) {
    include $_SERVER['DOCUMENT_ROOT'].'/inc/config.php';
    include $_SERVER['DOCUMENT_ROOT'].'/inc/login.php';
    if ($token == md5($my_id.'_position_'.$secret) and $my_id) {
        $policy = addslashes($policy);
        $world_view = addslashes($world_view);
        $important_live = addslashes($important_live);
        $important_peoples = addslashes($important_peoples);
        $smoking = addslashes($smoking);
        $alcohol = addslashes($alcohol);
        $inspirations = addslashes($inspirations);
        
        $policy = htmlspecialchars($policy);
        $world_view = htmlspecialchars($world_view);
        $important_live = htmlspecialchars($important_live);
        $important_peoples = htmlspecialchars($important_peoples);
        $smoking = htmlspecialchars($smoking);
        $alcohol = htmlspecialchars($alcohol);
        $inspirations = htmlspecialchars($inspirations);
        
        include $_SERVER['DOCUMENT_ROOT'].'/inc/login.php';
        if ($my_id) {
        $live_edit = true;
        
        if ($policy>-1 and $policy<9) {} else { $live_edit = false; }
        if ($world_view>-1 and $world_view<10) {} else { $live_edit = false; }
        if ($important_live>-1 and $important_live<9) {} else { $live_edit = false; }
        if ($important_peoples>-1 and $important_peoples<7) {} else { $live_edit = false; }
        if ($smoking>-1 and $smoking<6) {} else { $live_edit = false; }
        if ($alcohol>-1 and $alcohol<6) {} else { $live_edit = false; }
        if (mb_strlen($inspirations, 'UTF-8')>1000) { $live_edit = false; }
        
        if ($live_edit) {
            include $_SERVER['DOCUMENT_ROOT'].'/inc/sql_social.php';
            mysql_query("UPDATE users SET policy='$policy', world_view='$world_view', important_live='$important_live', important_peoples='$important_peoples', smoking='$smoking', alcohol='$alcohol', inspirations='$inspirations' WHERE id='$my_id'");
            mysql_close($msconnect);
        }
        $live_edit = true;
        return $live_edit;
        }
    }
}
?>