<?php
function city_list($country_id) {
    include $_SERVER['DOCUMENT_ROOT'].'/inc/config.php';
    $country_id = addslashes($country_id);
    $country_id  = htmlspecialchars($country_id);
    include $_SERVER['DOCUMENT_ROOT'].'/inc/sql_social.php';    
    $city_list = '<li><a onClick="document.getElementById(\'id_city\').innerHTML=this.innerHTML; $(\'#id_toolcity\').tooltip(\'destroy\');">'.$lang[516].'</a></li>';
    $result = mysql_query("SELECT distinct (name_$js_lang) FROM net_city WHERE country_id='$country_id' ORDER BY name_$js_lang ASC"); 
    while ( $myrow = mysql_fetch_array($result) )
    {
        $city_list = $city_list.'<li><a onClick="document.getElementById(\'id_city\').innerHTML=this.innerHTML; $(\'#id_toolcity\').tooltip(\'destroy\');">'.$myrow['name_'.$js_lang].'</a></li>
        ';
    }
    mysql_close($msconnect);
    if ($country_id!=='0') {
        return $city_list;
    }
}
?>