<?php
function change_email($email_last, $email_next, $token_email) {
    include $_SERVER['DOCUMENT_ROOT'].'/inc/config.php';
    $email_last = addslashes($email_last);
    $email_next = addslashes($email_next);
    
    $email_last = htmlspecialchars($email_last);
    $email_next = htmlspecialchars($email_next);
    include $_SERVER['DOCUMENT_ROOT'].'/inc/login.php';
    if ($token_email==md5($my_id.'_editemail_'.$secret)) {
        $live_email = true;
        if(!preg_match("/^([a-z0-9_\.-]+)@([a-z0-9_\.-]+)\.([a-z\.]{2,6})$/", $email_last)) { $live_email = false; }
        if(!preg_match("/^([a-z0-9_\.-]+)@([a-z0-9_\.-]+)\.([a-z\.]{2,6})$/", $email_next)) { $live_email = false; }

        if ($live_email) {
            include $_SERVER['DOCUMENT_ROOT'].'/inc/sql_social.php';
            
            $z_live_email = mysql_query("SELECT id FROM users WHERE email='$email_next'");
            $o_live_email = mysql_fetch_array($z_live_email);
            $live_email = $o_live_email['id'];
            
            if (!$live_email) {
                
                $z_last_email = mysql_query("SELECT id FROM users WHERE email='$email_last' and id='$my_id'");
                $o_last_email = mysql_fetch_array($z_last_email);
                $last_email = $o_last_email['id'];
                
                if ($last_email) {
                    mysql_query("UPDATE users SET email='$email_next' WHERE id='$my_id'");
                    return 3;
                } else {
                    return 2;
                }
                
                
            } else {
                return 1;
            }
            
            mysql_close($msconnect);            
        } else {
            return 0;
        }
    }
}
?>