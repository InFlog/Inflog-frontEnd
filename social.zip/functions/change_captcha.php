<?php
function change_captcha() {
    $width = 100;
    $height = 34;
    $font_size = 10;
    $let_amount = 5;
    $fon_let_amount = 30;
    $font = $_SERVER['DOCUMENT_ROOT'].'/fonts/lobster.ttf';
    header ("Content-type: image/png");
    $letters = array('1','2','3','4','5','6','7','8','9','0','a','b','c','d','e','f','g','h','i','j','k','l','m','n','o','p','q','r','s','t','u','v','w','x','y','z');        
    $foreground_color = array(42, 88, 122);
    $src = imagecreatetruecolor($width,$height);            
    $fon = imagecolorallocate($src, 255, 255, 255);
    imagefill($src,0,0,$fon);
    for($i=0; $i < $let_amount; $i++){
        $color = imagecolorallocatealpha($src, $foreground_color[0], $foreground_color[1], $foreground_color[2], rand(20,40));
        $letter = $letters[rand(0,sizeof($letters)-1)];
        $size = rand($font_size*2,$font_size*2);
        $x = ($i+1)*$font_size + 5*$i;
        $y = (($height*2)/3)+3;                            
        $cod[] = $letter;
        imagettftext($src,$size,rand(0,15),$x,$y,$color,$font,$letter);
    }
    $cod = implode("", $cod);
    imagepng($src, $_SERVER['DOCUMENT_ROOT'].'/code/captcha.png');
    imagedestroy($src);
    return md5($cod);
}
?>