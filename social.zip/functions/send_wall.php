<?php
function send_wall($comment_wall, $page_id, $str_wall_photos, $token) {
    include $_SERVER['DOCUMENT_ROOT'].'/inc/config.php';
    $comment_wall = addslashes($comment_wall);
    $page_id = addslashes($page_id);
    $str_wall_photos = addslashes($str_wall_photos);
    
    $comment_wall = htmlspecialchars($comment_wall);
    $page_id = htmlspecialchars($page_id);
    $str_wall_photos = htmlspecialchars($str_wall_photos);
    
    include $_SERVER['DOCUMENT_ROOT'].'/inc/login.php';
    if ($token == md5($my_id.'_'.$page_id.'_sendwall_'.$secret) and $my_id) {
        include $_SERVER['DOCUMENT_ROOT'].'/inc/sql_social.php';
        $this_date = date('U');
        mysql_query("INSERT wall SET user_id='$my_id', page_id='$page_id', message='$comment_wall', photos='$str_wall_photos', date='$this_date'");
        
        if ($page_id==$my_id) {
            $z_last_wall_id = mysql_query("SELECT wall_id FROM wall WHERE user_id='$my_id' ORDER BY wall_id DESC");
            $o_last_wall_id = mysql_fetch_array($z_last_wall_id);
            $last_wall_id = $o_last_wall_id['wall_id'];
            $result = mysql_query("SELECT friend_id FROM friends WHERE user_id='$my_id' and status='1'"); 
            while ( $myrow = mysql_fetch_array($result) )
            {
                $friend_id = $myrow['friend_id'];
                mysql_query("INSERT wall_to_users SET wall_id='$last_wall_id', user_id='$friend_id', status='1'");
            }
            mysql_query("INSERT wall_to_users SET wall_id='$last_wall_id', user_id='$my_id', status='0'");
        }
        
        if ($my_id) {    
            if ($page_id!==$my_id) {
                $time = date('U');
                mysql_query("INSERT news SET user_from='$my_id', user_to='$page_id', object_id='$page_id', news_type='5', status='1', time='$time'");
            }
        }
        
        mysql_close($msconnect);
    }
}
?>