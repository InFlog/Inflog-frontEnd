<?php
function edit_contacts($phone, $mail, $skype, $site, $token) {
    include $_SERVER['DOCUMENT_ROOT'].'/inc/config.php';
    include $_SERVER['DOCUMENT_ROOT'].'/inc/login.php';
    if ($token == md5($my_id.'_contacts_'.$secret) and $my_id) {
        $phone = addslashes($phone);
        $mail = addslashes($mail);
        $skype = addslashes($skype);
        $site = addslashes($site);
        
        $phone = htmlspecialchars($phone);
        $mail = htmlspecialchars($mail);
        $skype = htmlspecialchars($skype);
        $site = htmlspecialchars($site);
        
        include $_SERVER['DOCUMENT_ROOT'].'/inc/login.php';
        if ($my_id) {
        $live_edit = true;
        
        if ($phone!=='') {
        if(!preg_match("/^[0-9]{5,11}$/", $phone)) { $live_edit = false; }
        }
        if ($mail!=='') {
        if(!preg_match("/^[0-9a-zA-Z\-_\.]+@[0-9a-zA-Z\-_\.]+\.[a-zA-Z]{2,4}$/", $mail)) { $live_edit = false; }
        }
        if ($skype!=='') {
        if(!preg_match("/^[a-z0-9._-]{3,16}$/", $skype)) { $live_edit = false; }
        }
        if ($site!=='') {
        if(!preg_match("/^(https?:\/\/)?([\da-z\.-]+)\.([a-z\.]{2,6})([\/\w \.-]*)*\/?$/", $site)) { $live_edit = false; }
        }
        
        if ($live_edit) {
            include $_SERVER['DOCUMENT_ROOT'].'/inc/sql_social.php';
            mysql_query("UPDATE users SET phone='$phone', mail='$mail', skype='$skype', site='$site' WHERE id='$my_id'");
            mysql_close($msconnect);
        }
        
        return $live_edit;
        }
    }
}
?>