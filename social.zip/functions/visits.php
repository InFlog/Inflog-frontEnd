<?php
function visits($more, $page, $token) {
    include $_SERVER['DOCUMENT_ROOT'].'/inc/config.php';
    $more = addslashes($more);
    $page = addslashes($page);
    
    $more = htmlspecialchars($more);
    $page = htmlspecialchars($page);
    
    $arr = Array();
    include $_SERVER['DOCUMENT_ROOT'].'/inc/login.php';
    if ($token == md5($my_id.'_visits_'.$secret) and $my_id) {
        include $_SERVER['DOCUMENT_ROOT'].'/inc/sql_social.php';
        
        
        $body_likes = '';
        $page_start = $page*8-8;
        $page_next = ($page_start+8);
        $result = mysql_query("SELECT * FROM visits WHERE page_id='$my_id' ORDER BY time DESC, visits_id LIMIT $page_start, 8"); 
        
        $z_live_next = mysql_query("SELECT user_id FROM visits WHERE page_id='$my_id' ORDER BY time DESC, visits_id LIMIT $page_next, 1");
        $o_live_next = mysql_fetch_array($z_live_next);
        $live_next = $o_live_next['user_id'];
        
        $z_like_count = mysql_query("SELECT user_id FROM visits WHERE page_id='$my_id'");
        $like_count = mysql_num_rows($z_like_count);
        
        while ( $myrow = mysql_fetch_array($result) )
        {
            $user_id = $myrow['user_id'];
            $z_user_info = mysql_query("SELECT * FROM users WHERE id='$user_id'");
            $o_user_info = mysql_fetch_array($z_user_info);
            $info_firstname = $o_user_info['firstname'];
            $info_sex = $o_user_info['sex'];
            $info_avatar = $o_user_info['avatar'];
            
            $rand = rand(100000, 999999);
            if ($info_avatar==0) {
                if ($info_sex==1) { $avatar = '/img/no_photo/girl.png?r='.$rand; }
                if ($info_sex==2) { $avatar = '/img/no_photo/boy.png?r='.$rand; }
            } else {
                $avatar = '/avatar/'.$user_id.'.jpg?r='.$rand;
            }
            $date_1 = date("d.m.Y", $myrow['time']);
            $date_2 = date("H:i", $myrow['time']);
            
            if ($myrow['status']=='1') {
                $style = '';
            } else {
                $style = '-webkit-filter:grayscale(100%); -moz-filter:grayscale(100%); -ms-filter:grayscale(100%); -o-filter:grayscale(100%); filter:grayscale(100%); filter:gray;';
            }
            
            $body_likes = $body_likes.'
            <div style="width:25%; text-align:center; float:left; margin-bottom:10px;">
                <a href="/id'.$user_id.'"><img width="60" height="60" src="'.$avatar.'" style="border-radius:100%; '.$style.'" /></a>
                <p><a href="/id'.$user_id.'" style="font-size:12px;">'.$info_firstname.'</a></p>
            </div>
            ';
        }
        mysql_query("UPDATE visits SET status='0' WHERE page_id='$my_id'");
        
        if ($live_next) {
            $body_likes = $body_likes.'
            <p id="id_visits_more_all" style="text-align:center;"><button id="but_add" type="button" class="btn btn-sm" onClick="token=\''.md5($my_id.'_visits_'.$secret).'\'; more=true; page='.($page+1).'; visits();">'.$lang[672].'</button></p>
            ';
        }
        
        $arr[0] = $body_likes;
        $arr[1] = $like_count;
        mysql_close($msconnect);
        return $arr;
    }
}
?>