<?php
function change_password($password_last, $password_next, $token_password) {
    include $_SERVER['DOCUMENT_ROOT'].'/inc/config.php';
    $password_last = addslashes($password_last);
    $password_next = addslashes($password_next);
    
    $password_last  = htmlspecialchars($password_last);
    $password_next = htmlspecialchars($password_next);
    include $_SERVER['DOCUMENT_ROOT'].'/inc/login.php';
    if ($token_password==md5($my_id.'_editpassword_'.$secret)) {
        $live_password = true;
        if (mb_strlen($password_last, 'UTF-8')<6) { $live_password = false; }
        if (mb_strlen($password_next, 'UTF-8')<6) { $live_password = false; }

        if ($live_password) {
            include $_SERVER['DOCUMENT_ROOT'].'/inc/sql_social.php';
            $password_last = md5($password_last);
        
                $z_last_password = mysql_query("SELECT id FROM users WHERE password='$password_last' and id='$my_id'");
                $o_last_password = mysql_fetch_array($z_last_password);
                $last_password = $o_last_password['id'];
                
                if ($last_password) {
                    $new_password = md5($password_next);
                    mysql_query("UPDATE users SET password='$new_password' WHERE id='$my_id'");
                    setcookie("l", $my_id, time()+3600, "/", "", 0);
                    setcookie("p", $new_password, time()+3600, "/", "", 0);
                    return 3;
                } else {
                    return 2;
                }

            
            mysql_close($msconnect);            
        } else {
            return 0;
        }
    }
}
?>