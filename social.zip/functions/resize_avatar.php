<?php
function resize_avatar($ava_x, $ava_y, $ava_x2, $ava_y2, $ava_w, $ava_h, $img_w, $img_h, $token) {
    include $_SERVER['DOCUMENT_ROOT'].'/inc/config.php';
    include $_SERVER['DOCUMENT_ROOT'].'/inc/login.php';    
    if ($token == md5($my_id.'_resizeavatar_'.$secret) and $my_id) {
        $ava_x = addslashes($ava_x);
        $ava_y = addslashes($ava_y);
        $ava_x2 = addslashes($ava_x2);
        $ava_y2 = addslashes($ava_y2);
        $ava_w = addslashes($ava_w);
        $ava_h = addslashes($ava_h);
        $img_w = addslashes($img_w);
        $img_h = addslashes($img_h); 

        $ava_x = htmlspecialchars($ava_x);
        $ava_y = htmlspecialchars($ava_y);
        $ava_x2 = htmlspecialchars($ava_x2);
        $ava_y2 = htmlspecialchars($ava_y2);
        $ava_w = htmlspecialchars($ava_w);
        $ava_h = htmlspecialchars($ava_h);
        $img_w = htmlspecialchars($img_w);
        $img_h = htmlspecialchars($img_h);

        $uploadDir = '/uploads/';
        $saveDir = '/photo/';
        $uploadDir  = $_SERVER['DOCUMENT_ROOT'] . $uploadDir;
        $saveDir  = $_SERVER['DOCUMENT_ROOT'] . $saveDir;
        
        include $_SERVER['DOCUMENT_ROOT'].'/inc/sql_social.php';
        
        $rand = rand(1000000, 9999999);
        $targetFile = $_SERVER['DOCUMENT_ROOT'].'/uploads/upload_'.$my_id.'.jpg';
        move_uploaded_file($tempFile, $targetFile);
        $saveFile = $saveDir . $rand . '.jpg';
        $saveFileMini = $saveDir . 'm_' . $rand . '.jpg';
                
        $im = imagecreatefromjpeg($targetFile);
        list($w,$h) = getimagesize($targetFile);
        $koe=$w/600;
        $new_h=ceil($h/$koe);
        $im1 = imagecreatetruecolor(600, $new_h); 
        imagecopyresampled($im1,$im,0,0,0,0,600,$new_h,imagesx($im),imagesy($im));  
        imagejpeg($im1, $saveFile, 100);
        imagedestroy($im); 
        imagedestroy($im1);
                
        $save_h = $new_h;
                
        if ($h>$w) {
            $im = imagecreatefromjpeg($targetFile);
            list($w,$h) = getimagesize($targetFile);
            $koe=$w/200;
            $new_h=ceil($h/$koe);
            $im1 = imagecreatetruecolor(200, $new_h); 
            imagecopyresampled($im1,$im,0,0,0,0,200,$new_h,imagesx($im),imagesy($im));  
            imagejpeg($im1, $saveFileMini, 200);
            imagedestroy($im); 
            imagedestroy($im1);
        } else {
            $im = imagecreatefromjpeg($targetFile);
            list($w,$h) = getimagesize($targetFile);
            $koe=$h/200;
            $new_w=ceil($w/$koe);
            $im1 = imagecreatetruecolor($new_w, 200); 
            imagecopyresampled($im1,$im,0,0,0,0,$new_w,200,imagesx($im),imagesy($im));  
            imagejpeg($im1, $saveFileMini, 200);
            imagedestroy($im); 
            imagedestroy($im1);
        }
                
        $date = date('U');
        mysql_query("INSERT photo_to_users SET user_id='$my_id', photo_name='$rand', width='600', height='$save_h', date='$date', photo_type='1', live='1'");
        mysql_query("INSERT wall SET user_id='$my_id', page_id='$my_id', photos='$rand', date='$date'");
        
        $z_last_wall_id = mysql_query("SELECT wall_id FROM wall WHERE user_id='$my_id' ORDER BY wall_id DESC");
        $o_last_wall_id = mysql_fetch_array($z_last_wall_id);
        $last_wall_id = $o_last_wall_id['wall_id'];
        $result = mysql_query("SELECT friend_id FROM friends WHERE user_id='$my_id' and status='1'"); 
        while ( $myrow = mysql_fetch_array($result) )
        {
            $friend_id = $myrow['friend_id'];
            mysql_query("INSERT wall_to_users SET wall_id='$last_wall_id', user_id='$friend_id', status='1'");
        }
        mysql_query("INSERT wall_to_users SET wall_id='$last_wall_id', user_id='$my_id', status='0'");

        $src = $_SERVER['DOCUMENT_ROOT'].'/uploads/upload_'.$my_id.'.jpg';
        $src2 = $_SERVER['DOCUMENT_ROOT'].'/avatar/'.$my_id.'.jpg';
        $size = getimagesize($src);
        $kx = $size[0]/$img_w;
        $ky = $size[1]/$img_h;

        $new_width = $ava_w*$kx;
        $new_height = $ava_h*$ky;
        $left = $ava_x*$kx;
        $top = $ava_y*$ky;

        $size = getimagesize($src);
        $format = strtolower(substr($size['mime'], strpos($size['mime'], '/')+1));
        $icfunc = "imagecreatefrom" . $format;
        $isrc = $icfunc($src);
        $dst = imagecreatetruecolor($new_width, $new_height);
        imagecopyresampled($dst, $isrc, 0, 0, $left, $top, $new_width, $new_height, $new_width, $new_height);
        imagejpeg($dst, $src, 100);
        imagedestroy($dst);


        $im = imagecreatefromjpeg($src);
        list($w,$h) = getimagesize($src);
        $koe=$w/100;
        $new_h=ceil($h/$koe);
        $im1 = imagecreatetruecolor(100, $new_h); 
        imagecopyresampled($im1,$im,0,0,0,0,100,$new_h,imagesx($im),imagesy($im));  
        imagejpeg($im1, $src2, 100);
        imagedestroy($im); 
        imagedestroy($im1);

        unlink($src);
        mysql_query("UPDATE users SET avatar='1' WHERE id='$my_id'");
        mysql_close($msconnect);
    }
}
?>