<?php
function load_message($page, $more, $uid, $token) {
    include $_SERVER['DOCUMENT_ROOT'].'/inc/config.php';
    include $_SERVER['DOCUMENT_ROOT'].'/inc/login.php';
    if ($token == md5($uid.'_loadmessages_'.$secret) and $my_id) {
        $uid = addslashes($uid);
        $page = addslashes($page);
        $more = addslashes($more);
        
        $uid = htmlspecialchars($uid);
        $page = htmlspecialchars($page);
        $more = htmlspecialchars($more);
        $arr = Array();
        
        include $_SERVER['DOCUMENT_ROOT'].'/inc/sql_social.php';
        
        $body_messages = '';
        $page_start = $page*10-10;
        $page_next = ($page_start+10);
        $result = mysql_query("SELECT * FROM messages WHERE user_from='$my_id' and user_to='$uid' OR user_from='$uid' and user_to='$my_id' ORDER BY message_id DESC, message_id LIMIT $page_start, 10"); 
        
        $z_live_next = mysql_query("SELECT * FROM messages WHERE user_from='$my_id' and user_to='$uid' OR user_from='$uid' and user_to='$my_id' ORDER BY message_id DESC, message_id LIMIT $page_next, 1");
        $o_live_next = mysql_fetch_array($z_live_next);
        $live_next = $o_live_next['message_id'];
        
        $z_last_messages_id = mysql_query("SELECT message_id FROM messages WHERE user_from='$my_id' and user_to='$uid' OR user_from='$uid' and user_to='$my_id' ORDER BY message_id DESC");
        $o_last_messages_id = mysql_fetch_array($z_last_messages_id);
        $last_messages_id = $o_last_messages_id['message_id'];
        
        while ( $myrow = mysql_fetch_array($result) )
        {
            $uid = $myrow['user_from'];
            $z_user_info = mysql_query("SELECT * FROM users WHERE id='$uid'");
            $o_user_info = mysql_fetch_array($z_user_info);
            $info_firstname = $o_user_info['firstname'];
            $date = date("H:i", $myrow['date']);
            
            for ($ic=1; $ic<36; $ic++) {
                $myrow['message'] = str_replace('&lt;smile'.$ic.' /&gt;', '<img src=\'/img/smiles/'.$ic.'.png\' style="margin-top:15px;" />', $myrow['message']);
            }
            
            if ($myrow['photos'] and $myrow['photos']!=='') {
                $photos_body = '';
                $arr_photos = explode(',', $myrow['photos']);
                for ($ip=0; $ip<count($arr_photos); $ip++) {
                    $photos_body = $photos_body.'<div style="width:30px; height:30px; background-image: url(\'/photo/m_'.$arr_photos[$ip].'.jpg\'); background-size:cover; background-position:center top; border-radius:4px; float:left; margin-right:2px; cursor:pointer;" onClick="photo_name=\''.$arr_photos[$ip].'\'; photo_type=2; message_photo_show();"></div>';
                }
                $myrow['message'] = $myrow['message'].'<div style="padding-left:0px; height:30px; margin-top:5px;">'.$photos_body.'</div>';
            }
            
            $rand = rand(10000, 99999);
            $z_user_avatar = mysql_query("SELECT * FROM users WHERE id='$uid'");
            $o_user_avatar = mysql_fetch_array($z_user_avatar);
            $user_avatar = $o_user_avatar['avatar'];
            $user_sex = $o_user_avatar['sex'];
            if ($user_avatar==0) {
                if ($user_sex==1) { $avatar = '/img/no_photo/girl.png?r='.$rand; }
                if ($user_sex==2) { $avatar = '/img/no_photo/boy.png?r='.$rand; }
            } else {
                $avatar = '/avatar/'.$uid.'.jpg?r='.$rand;
            }
            
            if ($myrow['user_from']!==$my_id) {
                $body_messages = '
                <div style="float:left; width:40px;"><a href="/id'.$uid.'"><img src="'.$avatar.'" style="width:35px; height:35px; border-radius:40px;" /></a></div>
                <div style="float:left; min-width:0px; max-width:calc(100% - 90px);">
                    <div style="padding:10px; background:#edf0f3; margin-left:10px; border-radius:5px; font-size:12px; color:#333;"><a><b>'.$info_firstname.'</b></a> <span style="font-size:11px; color:#999;">'.$date.'</span><br>'.$myrow['message'].'</div>
                </div>
                <div style="margin-bottom:5px;"><div class="row"></div></div>
                '.$body_messages;
            } else {
                $body_messages = '
                <div style="float:right; width:40px;"><a href="/id'.$uid.'"><img src="'.$avatar.'" style="width:35px; height:35px; border-radius:40px;" /></a></div>
                <div style="float:right; min-width:0px; max-width:calc(100% - 90px);">
                    <div style="padding:10px; background:#edf0f3; margin-right:10px; border-radius:5px; font-size:12px; color:#333;"><a><b>'.$info_firstname.'</b></a> <span style="font-size:11px; color:#999;">'.$date.'</span><br>'.$myrow['message'].'</div>
                </div>
                <div style="margin-bottom:5px;"><div class="row"></div></div>
                '.$body_messages;
            }
        }
        
        if ($live_next) {
            $body_messages = '
            <p id="id_more_message" style="text-align:center;"><button id="but_add" type="button" class="btn btn-sm" onClick="more=true; page='.($page+1).'; load_message();">'.$lang[558].'</button></p>
            '.$body_messages;
        }
            
        mysql_close($msconnect);
        $arr[0] = $body_messages;
        $arr[1] = $last_messages_id;
        return $arr;
    }
}
?>