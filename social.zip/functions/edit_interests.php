<?php
function edit_interests($activity, $interests, $music, $movies, $tv, $books, $games, $quotations, $about, $token) {
    include $_SERVER['DOCUMENT_ROOT'].'/inc/config.php';
    include $_SERVER['DOCUMENT_ROOT'].'/inc/login.php';
    if ($token == md5($my_id.'_interests_'.$secret) and $my_id) {
        $activity = addslashes($activity);
        $interests = addslashes($interests);
        $music = addslashes($music);
        $movies = addslashes($movies);
        $tv = addslashes($tv);
        $books = addslashes($books);
        $games = addslashes($games);
        $quotations = addslashes($quotations);
        $about = addslashes($about);
        
        $activity = htmlspecialchars($activity);
        $interests = htmlspecialchars($interests);
        $music = htmlspecialchars($music);
        $movies = htmlspecialchars($movies);
        $tv = htmlspecialchars($tv);
        $books = htmlspecialchars($books);
        $games = htmlspecialchars($games);
        $quotations = htmlspecialchars($quotations);
        $about = htmlspecialchars($about);
        
        include $_SERVER['DOCUMENT_ROOT'].'/inc/login.php';
        if ($my_id) {
        $live_edit = true;
        
        if (mb_strlen($activity, 'UTF-8')>10000) { $live_edit = false; }
        if (mb_strlen($interests, 'UTF-8')>10000) { $live_edit = false; }
        if (mb_strlen($music, 'UTF-8')>10000) { $live_edit = false;    }
        if (mb_strlen($movies, 'UTF-8')>10000) { $live_edit = false; }
        if (mb_strlen($tv, 'UTF-8')>10000) { $live_edit = false; }
        if (mb_strlen($books, 'UTF-8')>10000) { $live_edit = false; }
        if (mb_strlen($games, 'UTF-8')>10000) { $live_edit = false; }
        if (mb_strlen($quotations, 'UTF-8')>10000) { $live_edit = false; }
        if (mb_strlen($aboute, 'UTF-8')>10000) { $live_edit = false; }
        
        if ($live_edit) {
            include $_SERVER['DOCUMENT_ROOT'].'/inc/sql_social.php';
            mysql_query("UPDATE users SET activity='$activity', interests='$interests', music='$music', movies='$movies', tv='$tv', books='$books', games='$games', quotations='$quotations', about='$about' WHERE id='$my_id'");
            mysql_close($msconnect);
        }
        
        return $live_edit;
        }
    }
}
?>