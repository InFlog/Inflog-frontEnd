<?php
function like($object_id, $object_type, $token) {
    include $_SERVER['DOCUMENT_ROOT'].'/inc/config.php';
    $object_id = addslashes($object_id);
    $object_type = addslashes($object_type);
    
    $object_id = htmlspecialchars($object_id);
    $object_type = htmlspecialchars($object_type);
    include $_SERVER['DOCUMENT_ROOT'].'/inc/login.php';
    if ($token == md5($my_id.'_'.$object_id.'_'.$object_type.'_like_'.$secret) and $my_id) {
        include $_SERVER['DOCUMENT_ROOT'].'/inc/sql_social.php';
        $arr = Array();
        $z_like_id = mysql_query("SELECT likes_id FROM likes WHERE object_id='$object_id' and object_type='$object_type' and user_id='$my_id'");
        $o_like_id = mysql_fetch_array($z_like_id);
        $like_id = $o_like_id['likes_id'];
        if ($like_id) {
            mysql_query("DELETE FROM likes WHERE likes_id='$like_id'");
            $arr[0] = 0;
        } else {
            mysql_query("INSERT likes SET object_id='$object_id', object_type='$object_type', user_id='$my_id'");
            $arr[0] = 1;
            
            if ($my_id) {
                if ($object_type=='1') {
                    $z_user_to_photo = mysql_query("SELECT user_id FROM photo_to_users WHERE photo_id='$object_id'");
                    $o_user_to_photo = mysql_fetch_array($z_user_to_photo);
                    $user_to_photo = $o_user_to_photo['user_id'];
                    
                    if ($user_to_photo!==$my_id) {
                        $z_live_news = mysql_query("SELECT object_id FROM news WHERE user_from='$my_id' and user_to='$user_to_photo' and object_id='$object_id' and news_type='1'");
                        $o_live_news = mysql_fetch_array($z_live_news);
                        $live_news = $o_live_news['object_id'];
                        if (!$live_news) {
                            $time = date('U');
                            mysql_query("INSERT news SET user_from='$my_id', user_to='$user_to_photo', object_id='$object_id', news_type='1', status='1', time='$time'");
                        }
                    }
                }
                if ($object_type=='2') {
                    $z_user_to_comment = mysql_query("SELECT * FROM comments WHERE comments_id='$object_id'");
                    $o_user_to_comment = mysql_fetch_array($z_user_to_comment);
                    $user_to_comment = $o_user_to_comment['user_id'];
                    $photo_id = $o_user_to_comment['photo_id'];
                    
                    if ($user_to_comment!==$my_id) {
                        $z_live_news = mysql_query("SELECT object_id FROM news WHERE user_from='$my_id' and user_to='$user_to_comment' and object_id='$photo_id' and news_type='2'");
                        $o_live_news = mysql_fetch_array($z_live_news);
                        $live_news = $o_live_news['object_id'];
                        if (!$live_news) {
                            $time = date('U');
                            mysql_query("INSERT news SET user_from='$my_id', user_to='$user_to_comment', object_id='$photo_id', news_type='2', status='1', time='$time'");
                        }
                    }
                }
                if ($object_type=='3') {
                    $z_user_to_wall = mysql_query("SELECT user_id FROM wall WHERE wall_id='$object_id'");
                    $o_user_to_wall = mysql_fetch_array($z_user_to_wall);
                    $user_to_wall = $o_user_to_wall['user_id'];
                    
                    if ($user_to_wall!==$my_id) {
                        $z_live_news = mysql_query("SELECT object_id FROM news WHERE user_from='$my_id' and user_to='$user_to_wall' and object_id='$object_id' and news_type='3'");
                        $o_live_news = mysql_fetch_array($z_live_news);
                        $live_news = $o_live_news['object_id'];
                        if (!$live_news) {
                            $time = date('U');
                            mysql_query("INSERT news SET user_from='$my_id', user_to='$user_to_wall', object_id='$object_id', news_type='3', status='1', time='$time'");
                        }
                    }
                }
                if ($object_type=='5') {
                    $z_user_to_photo = mysql_query("SELECT user_id FROM photo_to_users WHERE photo_id='$object_id'");
                    $o_user_to_photo = mysql_fetch_array($z_user_to_photo);
                    $user_to_photo = $o_user_to_photo['user_id'];
                    
                    if ($user_to_photo!==$my_id) {
                        $z_live_news = mysql_query("SELECT object_id FROM news WHERE user_from='$my_id' and user_to='$user_to_photo' and object_id='$object_id' and news_type='6'");
                        $o_live_news = mysql_fetch_array($z_live_news);
                        $live_news = $o_live_news['object_id'];
                        if (!$live_news) {
                            $time = date('U');
                            mysql_query("INSERT news SET user_from='$my_id', user_to='$user_to_photo', object_id='$object_id', news_type='6', status='1', time='$time'");
                        }
                    }
                }
            }
        }
        
        if ($object_type=='1') {
        $i = 0;
        $likes_body = '';
        $result_like = mysql_query("SELECT * FROM likes WHERE object_id='$object_id' and object_type='1' ORDER BY likes_id DESC, likes_id LIMIT 0, 5"); 
        while ( $myrow_like = mysql_fetch_array($result_like) )
        {    
            
            $rand = rand(10000, 99999);
            $user_ava_id = $myrow_like['user_id'];
            $z_user_avatar = mysql_query("SELECT * FROM users WHERE id='$user_ava_id'");
            $o_user_avatar = mysql_fetch_array($z_user_avatar);
            $user_avatar = $o_user_avatar['avatar'];
            $user_sex = $o_user_avatar['sex'];
            if ($user_avatar==0) {
                if ($user_sex==1) { $avatar = '/img/no_photo/girl.png?r='.$rand; }
                if ($user_sex==2) { $avatar = '/img/no_photo/boy.png?r='.$rand; }
            } else {
                $avatar = '/avatar/'.$user_ava_id.'.jpg?r='.$rand;
            }
            
            if ($i==0) {
                $likes_body = '<img width=\'30\' height=\'30\' src=\''.$avatar.'\' style=\'border-radius:100px; margin:5px 0px 5px 0px;\' />'.$likes_body;
            } else {
                $likes_body = '<img width=\'30\' height=\'30\' src=\''.$avatar.'\' style=\'border-radius:100px; float:left; margin:5px 5px 5px 0px;\' />'.$likes_body;
            }
            $i++;
        }    
        $arr[1] = $likes_body;
        }
        
        if ($object_type=='2') {
        $i = 0;
        $likes_body = '';
        $result_like = mysql_query("SELECT * FROM likes WHERE object_id='$object_id' and object_type='2' ORDER BY likes_id DESC, likes_id LIMIT 0, 2"); 
        while ( $myrow_like = mysql_fetch_array($result_like) )
        {
            
            $rand = rand(10000, 99999);
            $user_ava_id = $myrow_like['user_id'];
            $z_user_avatar = mysql_query("SELECT * FROM users WHERE id='$user_ava_id'");
            $o_user_avatar = mysql_fetch_array($z_user_avatar);
            $user_avatar = $o_user_avatar['avatar'];
            $user_sex = $o_user_avatar['sex'];
            if ($user_avatar==0) {
                if ($user_sex==1) { $avatar = '/img/no_photo/girl.png?r='.$rand; }
                if ($user_sex==2) { $avatar = '/img/no_photo/boy.png?r='.$rand; }
            } else {
                $avatar = '/avatar/'.$user_ava_id.'.jpg?r='.$rand;
            }
            
            if ($i==0) {
                $likes_body = '<img width=\'30\' height=\'30\' src=\''.$avatar.'\' style=\'border-radius:100px; margin:5px 0px 5px 0px;\' />'.$likes_body;
            } else {
                $likes_body = '<img width=\'30\' height=\'30\' src=\''.$avatar.'\' style=\'border-radius:100px; margin:5px 5px 5px 0px;\' />'.$likes_body;
            }
            $i++;
        }    
        $arr[1] = $likes_body;
        }
        
        if ($object_type=='3') {
        $i = 0;
        $likes_body = '';
        $result_like = mysql_query("SELECT * FROM likes WHERE object_id='$object_id' and object_type='3' ORDER BY likes_id DESC, likes_id LIMIT 0, 2"); 
        while ( $myrow_like = mysql_fetch_array($result_like) )
        {
            
            $rand = rand(10000, 99999);
            $user_ava_id = $myrow_like['user_id'];
            $z_user_avatar = mysql_query("SELECT * FROM users WHERE id='$user_ava_id'");
            $o_user_avatar = mysql_fetch_array($z_user_avatar);
            $user_avatar = $o_user_avatar['avatar'];
            $user_sex = $o_user_avatar['sex'];
            if ($user_avatar==0) {
                if ($user_sex==1) { $avatar = '/img/no_photo/girl.png?r='.$rand; }
                if ($user_sex==2) { $avatar = '/img/no_photo/boy.png?r='.$rand; }
            } else {
                $avatar = '/avatar/'.$user_ava_id.'.jpg?r='.$rand;
            }
            
            if ($i==0) {
                $likes_body = '<img width=\'30\' height=\'30\' src=\''.$avatar.'\' style=\'border-radius:100px; margin:5px 0px 5px 0px;\' />'.$likes_body;
            } else {
                $likes_body = '<img width=\'30\' height=\'30\' src=\''.$avatar.'\' style=\'border-radius:100px; margin:5px 5px 5px 0px;\' />'.$likes_body;
            }
            $i++;
        }    
        $arr[1] = $likes_body;
        }
        
        if ($object_type=='5') {
        $i = 0;
        $likes_body = '';
        $result_like = mysql_query("SELECT * FROM likes WHERE object_id='$object_id' and object_type='5' ORDER BY likes_id DESC, likes_id LIMIT 0, 2"); 
        while ( $myrow_like = mysql_fetch_array($result_like) )
        {
            
            $rand = rand(10000, 99999);
            $user_ava_id = $myrow_like['user_id'];
            $z_user_avatar = mysql_query("SELECT * FROM users WHERE id='$user_ava_id'");
            $o_user_avatar = mysql_fetch_array($z_user_avatar);
            $user_avatar = $o_user_avatar['avatar'];
            $user_sex = $o_user_avatar['sex'];
            if ($user_avatar==0) {
                if ($user_sex==1) { $avatar = '/img/no_photo/girl.png?r='.$rand; }
                if ($user_sex==2) { $avatar = '/img/no_photo/boy.png?r='.$rand; }
            } else {
                $avatar = '/avatar/'.$user_ava_id.'.jpg?r='.$rand;
            }
            
            if ($i==0) {
                $likes_body = '<img width=\'30\' height=\'30\' src=\''.$avatar.'\' style=\'border-radius:100px; margin:5px 0px 5px 0px;\' />'.$likes_body;
            } else {
                $likes_body = '<img width=\'30\' height=\'30\' src=\''.$avatar.'\' style=\'border-radius:100px; margin:5px 5px 5px 0px;\' />'.$likes_body;
            }
            $i++;
        }    
        $arr[1] = $likes_body;
        }
        
        mysql_close($msconnect);
        return $arr;
    }
}
?>