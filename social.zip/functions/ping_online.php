<?php
function ping_online($otvety_count) {
    $otvety_count = addslashes($otvety_count);
    $otvety_count = htmlspecialchars($otvety_count);
    
    include $_SERVER['DOCUMENT_ROOT'].'/inc/config.php';
    include $_SERVER['DOCUMENT_ROOT'].'/inc/login.php';
    if ($my_id) {    
        include $_SERVER['DOCUMENT_ROOT'].'/inc/sql_social.php';
        $arr = Array();
        
        $z_user_id = mysql_query("SELECT user_id FROM users_to_online WHERE user_id='$my_id'");
        $o_user_id = mysql_fetch_array($z_user_id);
        $user_id = $o_user_id['user_id'];
        $this_date = date('U');
                    
        if ($user_id) {
            mysql_query("UPDATE users_to_online SET time='$this_date' WHERE user_id='$user_id'");
            mysql_query("UPDATE search_links SET time='$this_date' WHERE user_id='$user_id'");
        } else {
            mysql_query("INSERT users_to_online SET user_id='$my_id', time='$this_date'");
            mysql_query("UPDATE search_links SET time='$this_date' WHERE user_id='$user_id'");
        }
        
        $z_count_visits = mysql_query("SELECT visits_id FROM visits WHERE page_id='$my_id' and status='1'");
        $count_visits = mysql_num_rows($z_count_visits);
        
        $z_count_news = mysql_query("SELECT id FROM wall_to_users WHERE user_id='$my_id' and status='1'");
        $count_news = mysql_num_rows($z_count_news);
        
        $z_count_friends = mysql_query("SELECT * FROM friends WHERE friend_id='$my_id' and status_menu='1'");
        $count_friends = mysql_num_rows($z_count_friends);
        
        $z_count_otvety = mysql_query("SELECT * FROM news WHERE user_to='$my_id' and status='1'");
        $count_otvety = mysql_num_rows($z_count_otvety);
        
        $z_count_otvety_off = mysql_query("SELECT * FROM news WHERE user_to='$my_id'");
        $count_otvety_off = mysql_num_rows($z_count_otvety_off);
        
        if ($otvety_count!==$count_otvety_off) {
            $z_last_news = mysql_query("SELECT * FROM news WHERE user_to='$my_id' ORDER BY news_id DESC");
            $o_last_news = mysql_fetch_array($z_last_news);
            $user_from_id = $o_last_news['user_from'];
            $news_type = $o_last_news['news_type'];
            
            $z_user_info = mysql_query("SELECT * FROM users WHERE id='$user_from_id'");
            $o_user_info = mysql_fetch_array($z_user_info);
            $info_firstname = $o_user_info['firstname'];
            $info_sex = $o_user_info['sex'];
            $info_avatar = $o_user_info['avatar'];
            
            $time = date("d.m.Y H:i", $myrow['time']);
            $rand = rand(10000, 99999);
            if ($info_avatar==0) {
                if ($info_sex==1) { $avatar = '/img/no_photo/girl.png?r='.$rand; }
                if ($info_sex==2) { $avatar = '/img/no_photo/boy.png?r='.$rand; }
            } else {
                $avatar = '/avatar/'.$user_from_id.'.jpg?r='.$rand;
            }
            
            if ($info_sex==1) {
                $t1 = $lang[603]; $t2 = $lang[604]; $t3 = $lang[605]; 
            } else {
                $t1 = $lang[606]; $t2 = $lang[607]; $t3 = $lang[608]; 
            }
            
            if ($news_type==1) {
                $news_text = '<div style="height:30px;"><img src="'.$avatar.'" style="width:30px; height:30px; border-radius:4px; float:left;" /> <span style="float:left; margin-left:10px;"><b>'.$info_firstname.'</b> '.$t1.' '.$lang[609].'</span></div>';
            }
            
            if ($news_type==2) {
                $news_text = '<div style="height:30px;"><img src="'.$avatar.'" style="width:30px; height:30px; border-radius:4px; float:left;" /> <span style="float:left; margin-left:10px;"><b>'.$info_firstname.'</b> '.$t1.' '.$lang[610].'</span></div>';
            }
            
            if ($news_type==3) {
                $news_text = '<div style="height:30px;"><img src="'.$avatar.'" style="width:30px; height:30px; border-radius:4px; float:left;" /> <span style="float:left; margin-left:10px;"><b>'.$info_firstname.'</b> '.$t1.' '.$lang[611].'</span></div>';
            }
            
            if ($news_type==4) {
                $news_text = '<div style="height:30px;"><img src="'.$avatar.'" style="width:30px; height:30px; border-radius:4px; float:left;" /> <span style="float:left; margin-left:10px;"><b>'.$info_firstname.'</b> '.$t2.' '.$lang[612].'</span></div>';
            }
            
            if ($news_type==5) {
                $news_text = '<div style="height:30px;"><img src="'.$avatar.'" style="width:30px; height:30px; border-radius:4px; float:left;" /> <span style="float:left; margin-left:10px;"><b>'.$info_firstname.'</b> '.$t2.' '.$lang[613].'</span></div>';
            }
            
            if ($news_type==6) {
                $news_text = '<div style="height:30px;"><img src="'.$avatar.'" style="width:30px; height:30px; border-radius:4px; float:left;" /> <span style="float:left; margin-left:10px;"><b>'.$info_firstname.'</b> '.$t1.' '.$lang[614].'</span></div>';
            }
            
            if ($news_type==7) {
                $news_text = '<div style="height:30px;"><img src="'.$avatar.'" style="width:30px; height:30px; border-radius:4px; float:left;" /> <span style="float:left; margin-left:10px;"><b>'.$info_firstname.'</b> '.$t1.' '.$lang[615].'</span></div>';
            }
            
            if ($news_type==8) {
                $news_text = '<div style="height:30px;"><img src="'.$avatar.'" style="width:30px; height:30px; border-radius:4px; float:left;" /> <span style="float:left; margin-left:10px;"><b>'.$info_firstname.'</b> '.$t3.' '.$lang[616].'</span></div>';
            }
                
        }
        
        $z_count_dialogs = mysql_query("SELECT * FROM dialogs WHERE user_to='$my_id' and status='1'");
        $count_dialogs = mysql_num_rows($z_count_dialogs);
        
        mysql_close($msconnect);
        
        $arr[0] = $count_visits;
        $arr[1] = $count_news;
        $arr[2] = $count_friends;
        $arr[3] = $count_otvety;
        
        $arr[5] = $count_otvety_off;
        $arr[6] = $news_text;
        $arr[7] = $count_dialogs;
        return $arr;
    }
}
?>