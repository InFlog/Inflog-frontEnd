<?php
function add_friend($friend_id, $token) {
    include $_SERVER['DOCUMENT_ROOT'].'/inc/config.php';
    $arr = Array();
    $friend_id = addslashes($friend_id);
    $friend_id = htmlspecialchars($friend_id);
    include $_SERVER['DOCUMENT_ROOT'].'/inc/login.php';
    if ($token == md5($my_id.'_'.$friend_id.'_addfriend_'.$secret) and $my_id) {
        include $_SERVER['DOCUMENT_ROOT'].'/inc/sql_social.php';
        if ($my_id and $friend_id) {
            $z_live_friend = mysql_query("SELECT status FROM friends WHERE user_id='$my_id' and friend_id='$friend_id' and status='1'");
            $o_live_friend = mysql_fetch_array($z_live_friend);
            $live_friend = $o_live_friend['status'];
            if (!$live_friend) {
                if ($friend_id!==$my_id) {
                    $z_live_sendfriend = mysql_query("SELECT user_id FROM friends WHERE user_id='$friend_id' and friend_id='$my_id'");
                    $o_live_sendfriend = mysql_fetch_array($z_live_sendfriend);
                    $live_sendfriend = $o_live_sendfriend['user_id'];
                    if ($live_sendfriend) {
                            mysql_query("INSERT friends SET user_id='$my_id', friend_id='$friend_id', status='1', status_menu='0'");
                            mysql_query("UPDATE friends SET status='1', status_menu='0' WHERE user_id='$friend_id' and friend_id='$my_id'");                        
                            $z_user_info = mysql_query("SELECT * FROM users WHERE id='$friend_id'");
                            $o_user_info = mysql_fetch_array($z_user_info);
                            $info_firstname = $o_user_info['firstname'];
                            $info_lastname = $o_user_info['lastname'];
                            $arr[0] = 1;
                            $arr[1] = $info_firstname.' '.$info_lastname;
                            return $arr;
                    } else {
                        $z_live_addfriend = mysql_query("SELECT user_id FROM friends WHERE user_id='$my_id' and friend_id='$friend_id'");
                        $o_live_addfriend = mysql_fetch_array($z_live_addfriend);
                        $live_addfriend = $o_live_addfriend['user_id'];
                        if ($live_addfriend) {
                            $arr[0] = 2;
                            $arr[1] = '';
                            return $arr;
                        } else {
                            mysql_query("INSERT friends SET user_id='$my_id', friend_id='$friend_id', status='0', status_menu='1'");        
                            $z_user_info = mysql_query("SELECT * FROM users WHERE id='$friend_id'");
                            $o_user_info = mysql_fetch_array($z_user_info);
                            $info_firstname = $o_user_info['firstname'];
                            $info_lastname = $o_user_info['lastname'];
                            $arr[0] = 3;
                            $arr[1] = $info_firstname.' '.$info_lastname;
                            return $arr;
                        }
                    }
                } else {
                    $arr[0] = 0;
                    $arr[1] = '';
                    return $arr;
                }
            } else {
                $z_user_info = mysql_query("SELECT * FROM users WHERE id='$friend_id'");
                $o_user_info = mysql_fetch_array($z_user_info);
                $info_firstname = $o_user_info['firstname'];
                $info_lastname = $o_user_info['lastname'];
                $arr[0] = 4;
                $arr[1] = $info_firstname.' '.$info_lastname;
                return $arr;
            }
        }
        mysql_close($msconnect);
    }
}
?>