<?php
function ping($last_messages_id, $talk_id, $live_key, $token) {
    include $_SERVER['DOCUMENT_ROOT'].'/inc/config.php';
    $last_messages_id = addslashes($last_messages_id);
    $talk_id = addslashes($talk_id);
    $live_key = addslashes($live_key);
    
    $last_messages_id = htmlspecialchars($last_messages_id);
    $talk_id = htmlspecialchars($talk_id);
    $live_key = htmlspecialchars($live_key);
    $arr = Array();
    include $_SERVER['DOCUMENT_ROOT'].'/inc/login.php';
    
    if ($token == md5($my_id.'_'.$talk_id.'_pingmessages_'.$secret) and $my_id) {
        include $_SERVER['DOCUMENT_ROOT'].'/inc/sql_social.php';
        
        if ($talk_id) {
            mysql_query("UPDATE dialogs SET status='0' WHERE user_from='$talk_id' and user_to='$my_id'");
        }
        
        if ($live_key=='true') {
            $z_user_print = mysql_query("SELECT print_id FROM users_to_print WHERE user_from='$my_id' and user_to='$talk_id'");
            $o_user_print = mysql_fetch_array($z_user_print);
            $print_id = $o_user_print['print_id'];
            $this_date = date('U');
            
            if ($print_id) {
                mysql_query("UPDATE users_to_print SET user_from='$my_id', user_to='$talk_id', time='$this_date' WHERE print_id='$print_id'");
            } else {
                mysql_query("INSERT users_to_print SET user_from='$my_id', user_to='$talk_id', time='$this_date'");
            }
        }
        
        $body_messages = '';
        $result = mysql_query("SELECT * FROM messages WHERE user_from='$my_id' and user_to='$talk_id' and message_id>'$last_messages_id' OR user_from='$talk_id' and user_to='$my_id' and message_id>'$last_messages_id'");
    
        while ( $myrow = mysql_fetch_array($result) )
        {
            $uid = $myrow['user_from'];
            $z_user_info = mysql_query("SELECT * FROM users WHERE id='$uid'");
            $o_user_info = mysql_fetch_array($z_user_info);
            $info_firstname = $o_user_info['firstname'];
            $date = date("H:i", $myrow['date']);
            
            for ($ic=1; $ic<36; $ic++) {
                $myrow['message'] = str_replace('&lt;smile'.$ic.' /&gt;', '<img src=\'/img/smiles/'.$ic.'.png\' style="margin-top:15px;" />', $myrow['message']);
            }
            
            if ($myrow['photos'] and $myrow['photos']!=='') {
                $photos_body = '';
                $arr_photos = explode(',', $myrow['photos']);
                for ($ip=0; $ip<count($arr_photos); $ip++) {
                    $photos_body = $photos_body.'<div style="width:30px; height:30px; background-image: url(\'/photo/m_'.$arr_photos[$ip].'.jpg\'); background-size:cover; background-position:center top; border-radius:4px; float:left; margin-right:2px; cursor:pointer;" onClick="photo_name=\''.$arr_photos[$ip].'\'; photo_type=2; message_photo_show();"></div>';
                }
                $myrow['message'] = $myrow['message'].'<div style="padding-left:0px; height:30px; margin-top:5px;">'.$photos_body.'</div>';
            }
            
            $rand = rand(10000, 99999);
            $z_user_avatar = mysql_query("SELECT * FROM users WHERE id='$uid'");
            $o_user_avatar = mysql_fetch_array($z_user_avatar);
            $user_avatar = $o_user_avatar['avatar'];
            $user_sex = $o_user_avatar['sex'];
            if ($user_avatar==0) {
                if ($user_sex==1) { $avatar = '/img/no_photo/girl.png?r='.$rand; }
                if ($user_sex==2) { $avatar = '/img/no_photo/boy.png?r='.$rand; }
            } else {
                $avatar = '/avatar/'.$uid.'.jpg?r='.$rand;
            }
            
            if ($myrow['user_from']!==$my_id) {
                $body_messages = '
                <div style="float:left; width:40px;"><a href="/id'.$uid.'"><img src="'.$avatar.'" style="width:35px; height:35px; border-radius:40px;" /></a></div>
                <div style="float:left; min-width:0px; max-width:calc(100% - 90px);">
                    <div style="padding:10px; background:#edf0f3; margin-left:10px; border-radius:5px; font-size:12px; color:#333;"><a><b>'.$info_firstname.'</b></a> <span style="font-size:11px; color:#999;">'.$date.'</span><br>'.$myrow['message'].'</div>
                </div>
                <div style="margin-bottom:5px;"><div class="row"></div></div>
                '.$body_messages;
            } else {
                $body_messages = '
                <div style="float:right; width:40px;"><a href="/id'.$uid.'"><img src="'.$avatar.'" style="width:35px; height:35px; border-radius:40px;" /></a></div>
                <div style="float:right; min-width:0px; max-width:calc(100% - 90px);">
                    <div style="padding:10px; background:#edf0f3; margin-right:10px; border-radius:5px; font-size:12px; color:#333;"><a><b>'.$info_firstname.'</b></a> <span style="font-size:11px; color:#999;">'.$date.'</span><br>'.$myrow['message'].'</div>
                </div>
                <div style="margin-bottom:5px;"><div class="row"></div></div>
                '.$body_messages;
            }
        }
    
        $z_last_messages_id = mysql_query("SELECT message_id FROM messages WHERE user_from='$my_id' and user_to='$talk_id' OR user_from='$talk_id' and user_to='$my_id' ORDER BY message_id DESC");
        $o_last_messages_id = mysql_fetch_array($z_last_messages_id);
        $last_messages_id = $o_last_messages_id['message_id'];
        
        $z_user_online = mysql_query("SELECT time FROM users_to_online WHERE user_id='$talk_id'");
        $o_user_online = mysql_fetch_array($z_user_online);
        $user_online = $o_user_online['time'];
        $this_date = date('U');
        if ($user_online>($this_date-60)) {
            $user_online = '1';
        } else {
            $user_online = '0';
        }
        
        $z_user_print = mysql_query("SELECT time FROM users_to_print WHERE user_from='$talk_id' and user_to='$my_id'");
        $o_user_print = mysql_fetch_array($z_user_print);
        $user_print = $o_user_print['time'];
        $this_date = date('U');
        if ($user_print>($this_date-3)) {
            $user_print = '1';
        } else {
            $user_print = '0';
        }
    
        mysql_close($msconnect);
        
        $arr[0] = $body_messages;
        $arr[1] = $last_messages_id;
        $arr[2] = $user_online;
        $arr[3] = $user_print;
        return $arr;
    }
}
?>