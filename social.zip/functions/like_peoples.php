<?php
function like_peoples($object_id, $object_type, $more, $page) {
    include $_SERVER['DOCUMENT_ROOT'].'/inc/config.php';
    $object_id = addslashes($object_id);
    $object_type = addslashes($object_type);
    $more = addslashes($more);
    $page = addslashes($page);
    
    $object_id = htmlspecialchars($object_id);
    $object_type = htmlspecialchars($object_type);
    $more = htmlspecialchars($more);
    $page = htmlspecialchars($page);
    
    $arr = Array();
    include $_SERVER['DOCUMENT_ROOT'].'/inc/login.php';
    include $_SERVER['DOCUMENT_ROOT'].'/inc/sql_social.php';
    
    
    $body_likes = '';
    $page_start = $page*8-8;
    $page_next = ($page_start+8);
    $result = mysql_query("SELECT user_id FROM likes WHERE object_id='$object_id' and object_type='$object_type' ORDER BY likes_id ASC, likes_id LIMIT $page_start, 8"); 
    
    $z_live_next = mysql_query("SELECT user_id FROM likes WHERE object_id='$object_id' and object_type='$object_type' ORDER BY likes_id ASC, likes_id LIMIT $page_next, 1");
    $o_live_next = mysql_fetch_array($z_live_next);
    $live_next = $o_live_next['user_id'];
    
    $z_like_count = mysql_query("SELECT user_id FROM likes WHERE object_id='$object_id' and object_type='$object_type'");
    $like_count = mysql_num_rows($z_like_count);
    
    while ( $myrow = mysql_fetch_array($result) )
    {
        $user_id = $myrow['user_id'];
        $z_user_info = mysql_query("SELECT * FROM users WHERE id='$user_id'");
        $o_user_info = mysql_fetch_array($z_user_info);
        $info_firstname = $o_user_info['firstname'];
        $info_sex = $o_user_info['sex'];
        $info_avatar = $o_user_info['avatar'];
        
        $rand = rand(10000, 99999);
        if ($info_avatar==0) {
            if ($info_sex==1) { $avatar = '/img/no_photo/girl.png?r='.$rand; }
            if ($info_sex==2) { $avatar = '/img/no_photo/boy.png?r='.$rand; }
        } else {
            $avatar = '/avatar/'.$user_id.'.jpg?r='.$rand;
        }
        
        $body_likes = $body_likes.'
        <div style="width:25%; text-align:center; float:left; margin-bottom:10px;">
            <a href="/id'.$user_id.'"><img width="60" height="60" src="'.$avatar.'" style="border-radius:100%;" /></a>
            <p><a href="/id'.$user_id.'" style="font-size:12px;">'.$info_firstname.'</a></p>
        </div>
        ';
    }
    
    if ($live_next) {
        $body_likes = $body_likes.'
        <p id="id_likes_more_all" style="text-align:center;"><button id="but_add" type="button" class="btn btn-sm" onClick="object_id='.$object_id.'; object_type='.$object_type.'; more=true; page='.($page+1).'; like_peoples();">'.$lang[551].'</button></p>
        ';
    }
    
    $arr[0] = $body_likes;
    $arr[1] = $like_count;
    mysql_close($msconnect);
    return $arr;
}
?>