<?php
function delcomment($comment_id, $token) {
    include $_SERVER['DOCUMENT_ROOT'].'/inc/config.php';
    $comment_id = addslashes($comment_id);
    $comment_id = htmlspecialchars($comment_id);
    include $_SERVER['DOCUMENT_ROOT'].'/inc/login.php';
    if ($token == md5($my_id.'_'.$comment_id.'_delcomment_'.$secret) and $my_id) {
        include $_SERVER['DOCUMENT_ROOT'].'/inc/sql_social.php';
        
        $z_comment_author_id = mysql_query("SELECT user_id FROM comments WHERE comments_id='$comment_id'");
        $o_comment_author_id = mysql_fetch_array($z_comment_author_id);
        $comment_author_id = $o_comment_author_id['user_id'];
        if ($comment_author_id==$my_id) {
            mysql_query("DELETE FROM comments WHERE comments_id='$comment_id'");
        } else {
            $z_photo_id = mysql_query("SELECT photo_id FROM comments WHERE comments_id='$comment_id'");
            $o_photo_id = mysql_fetch_array($z_photo_id);
            $photo_id = $o_photo_id['photo_id'];
            
            $z_author_id = mysql_query("SELECT user_id FROM photo_to_users WHERE photo_id='$photo_id'");
            $o_author_id = mysql_fetch_array($z_author_id);
            $author_id = $o_author_id['user_id'];
            
            if ($author_id==$my_id) {
                mysql_query("DELETE FROM comments WHERE comments_id='$comment_id'");
            }
        }
        mysql_close($msconnect);
    }
}
?>