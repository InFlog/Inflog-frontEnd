<?php
function send_comment($comment, $photo_id, $str_photos_comment, $uid, $token) {
    include $_SERVER['DOCUMENT_ROOT'].'/inc/config.php';
    $comment = addslashes($comment);
    $photo_id = addslashes($photo_id);
    $str_photos_comment = addslashes($str_photos_comment);
    $uid = addslashes($uid);
    
    $comment = htmlspecialchars($comment);
    $photo_id = htmlspecialchars($photo_id);
    $str_photos_comment = htmlspecialchars($str_photos_comment);
    $uid = htmlspecialchars($uid);
    
    include $_SERVER['DOCUMENT_ROOT'].'/inc/login.php';
    if ($token == md5($my_id.'_'.$uid.'_sendcomment_'.$secret) and $my_id) {
        include $_SERVER['DOCUMENT_ROOT'].'/inc/sql_social.php';
        $this_date = date('U');    
        mysql_query("INSERT comments SET photo_id='$photo_id', user_id='$my_id', comment='$comment', date='$this_date', photos='$str_photos_comment'");
        
        if ($my_id) {
            $z_user_to_photo = mysql_query("SELECT * FROM photo_to_users WHERE photo_id='$photo_id'");
            $o_user_to_photo = mysql_fetch_array($z_user_to_photo);
            $user_to_photo = $o_user_to_photo['user_id'];
                
            if ($user_to_photo!==$my_id) {
                $time = date('U');
                mysql_query("INSERT news SET user_from='$my_id', user_to='$user_to_photo', object_id='$photo_id', news_type='4', status='1', time='$time'");
            }
        }
        mysql_close($msconnect);
    }
}
?>