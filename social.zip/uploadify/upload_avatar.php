<?php
include $_SERVER['DOCUMENT_ROOT'].'/inc/login.php';
include $_SERVER['DOCUMENT_ROOT'].'/inc/config.php';
$uploadDir = '/uploads/';
$fileTypes = array('jpg', 'jpeg');
$verifyToken = md5('unique_salt' . $_POST['timestamp']);

if ($_POST['token'] == md5($my_id.'_avatar_'.$secret)) {
    $tempFile   = $_FILES['Filedata']['tmp_name'];
    $uploadDir  = $_SERVER['DOCUMENT_ROOT'] . $uploadDir;
    $targetFile = $uploadDir . 'upload_' . $my_id . '.jpg';
    $fileParts = pathinfo($_FILES['Filedata']['name']);
    if (in_array(strtolower($fileParts['extension']), $fileTypes)) {
        move_uploaded_file($tempFile, $targetFile);
        $im = imagecreatefromjpeg($targetFile);
        list($w,$h) = getimagesize($targetFile);
        $koe=$w/1000;
        $new_h=ceil($h/$koe);
        $im1 = imagecreatetruecolor(1000, $new_h); 
        imagecopyresampled($im1,$im,0,0,0,0,1000,$new_h,imagesx($im),imagesy($im));  
        imagejpeg($im1, $targetFile, 100);
        imagedestroy($im); 
        imagedestroy($im1);
        echo 1;
    } else {
        echo 'Invalid file type.';
    }
} else {
    echo 0;
}
?>