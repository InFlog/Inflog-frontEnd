<?php
include $_SERVER['DOCUMENT_ROOT'].'/inc/config.php';
include $_SERVER['DOCUMENT_ROOT'].'/inc/login.php';
if (isset($_GET['id'])) { $uid = $_GET['id']; } else { $uid = $my_id; }
$uid = addslashes($uid);
$uid = htmlspecialchars($uid);

if ($my_id) {
    include $_SERVER['DOCUMENT_ROOT'].'/inc/sql_social.php';

    $z_count_all = mysql_query("SELECT * FROM friends WHERE user_id='$uid' and status='1'");
    $count_all = mysql_num_rows($z_count_all);
    if ($count_all==0) { $count_all = ''; }

    $z_count_in = mysql_query("SELECT * FROM friends WHERE friend_id='$my_id' and status='0'");
    $count_in = mysql_num_rows($z_count_in);
    if ($count_in==0) { $count_in = ''; }

    $z_count_out = mysql_query("SELECT * FROM friends WHERE user_id='$my_id' and status='0'");
    $count_out = mysql_num_rows($z_count_out);
    if ($count_out==0) { $count_out = ''; }

    if ($my_id) {
        $z_live_friends = mysql_query("SELECT user_id FROM friends WHERE friend_id='$my_id' and status_menu='1'");
        $o_live_friends = mysql_fetch_array($z_live_friends);
        $live_friends = $o_live_friends['user_id'];
        
        if ($live_friends) {
            mysql_query("UPDATE friends SET status_menu='0' WHERE friend_id='$my_id'");
        }
    }
    
    $z_count_otvety = mysql_query("SELECT * FROM news WHERE user_to='$my_id'");
    $count_otvety = mysql_num_rows($z_count_otvety);
    
    mysql_close($msconnect);
    
    $global_rand = rand(100000, 999999);
    $title = $lang[416];
} else {
    
    if (isset($_GET['id'])) {
        include $_SERVER['DOCUMENT_ROOT'].'/inc/sql_social.php';
        $z_count_all = mysql_query("SELECT * FROM friends WHERE user_id='$uid' and status='1'");
        $count_all = mysql_num_rows($z_count_all);
        if ($count_all==0) { $count_all = ''; }
        mysql_close($msconnect);
    } else {
        header('Location: /'.$link[3]);
    }
}
?>
<?php
include $_SERVER['DOCUMENT_ROOT'].'/functions/top_search.php';
include $_SERVER['DOCUMENT_ROOT'].'/functions/all_friends.php';
include $_SERVER['DOCUMENT_ROOT'].'/functions/in_friends.php';
include $_SERVER['DOCUMENT_ROOT'].'/functions/out_friends.php';
include $_SERVER['DOCUMENT_ROOT'].'/functions/delete_allfriends.php';
include $_SERVER['DOCUMENT_ROOT'].'/functions/delete_onfriends.php';
include $_SERVER['DOCUMENT_ROOT'].'/functions/delete_outfriends.php';
include $_SERVER['DOCUMENT_ROOT'].'/functions/add_onfriends.php';
include $_SERVER['DOCUMENT_ROOT'].'/functions/ping_online.php';
include $_SERVER['DOCUMENT_ROOT'].'/functions/visits.php';
include $_SERVER['DOCUMENT_ROOT'].'/functions/otvety.php';


include $_SERVER['DOCUMENT_ROOT']."/inc/agent.php";
$agent->init();
?>
<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta name="description" content="">
        <meta name="author" content="">
        <title><?php echo $title; ?></title>
        <link href="/img/favicon.png" rel="shortcut icon" type="image/x-icon" />        
        <link rel="stylesheet" type="text/css" href="/css/bootstrap.css" />
        <link rel="stylesheet" type="text/css" href="/icon/style.css" />
        <?php if ($my_id):?>
        <script>
            var uid = <?php echo $uid; ?>;
            onload = function() {
                more=false; page=1; start_all_friends();
                ping_online();
            }
        </script>
        <?php endif;?>
        <?php if (!$my_id):?>
        <script>
            var uid = <?php echo $uid; ?>;
            onload = function() {
                more=false; page=1; start_all_friends();
            }
        </script>
        <?php endif;?>
    </head>
    <body role="document">
        <?php include $_SERVER['DOCUMENT_ROOT'].'/templates/header_user.tpl'; ?>
        <div class="container" style="margin-top:70px; margin-bottom:20px;">
            <div class="row" class="bs-example bs-example-tabs">
                <div class="col-md-2" style="padding-bottom:15px;">
                    <?php include $_SERVER['DOCUMENT_ROOT'].'/templates/user_left_menu.tpl'; ?>
                </div>                            
                <div class="col-md-3">                    
                    <div style="padding-top:5px; padding-bottom:5px; background-color:#ffffff; border:1px solid #e1e1e8; border-radius:4px; margin-bottom:20px;">
                        <ul id="myTab" class="list-group" style="margin:0px;">
                            <li class="list-group-item active list-group-edit" style="padding:10px; padding-left:20px; border-radius:0px;" onClick="$('#myTab a[href=\'#all_friends\']').tab('show'); more=false; page=1; start_all_friends();"><a href="#all_friends" data-toggle="tab"><?php echo $lang[410]; ?> <span style="float:right; padding-right:5px; color:#777; font-size:11px; padding-top:1px;"><b><?php echo $count_all; ?></b></span></a></li>
                            <?php if ($uid==$my_id):?>
                            <li class="list-group-item list-group-edit" style="padding:10px; padding-left:20px; border-radius:0px; margin-top:5px;" onClick="$('#myTab a[href=\'#in_friends\']').tab('show'); more=false; page=1; start_in_friends();"><a href="#in_friends" data-toggle="tab"><?php echo $lang[411]; ?> <span style="float:right; padding-right:5px; color:#777; font-size:11px; padding-top:1px;"><b><?php echo $count_in; ?></b></span></a></li>
                            <li class="list-group-item list-group-edit" style="padding:10px; padding-left:20px; border-radius:0px; margin-top:5px;" onClick="$('#myTab a[href=\'#out_friends\']').tab('show'); more=false; page=1; start_out_friends();""><a href="#out_friends" data-toggle="tab"><?php echo $lang[412]; ?> <span style="float:right; padding-right:5px; color:#777; font-size:11px; padding-top:1px;"><b><?php echo $count_out; ?></b></span></a></li>
                            <?php endif;?>
                        </ul>
                    </div>    
                </div>
                <div class="col-md-7">
                    <div style="padding:20px; background-color:#ffffff; border:1px solid #e1e1e8; border-radius:4px; margin-bottom:20px;">    
                        <div id="myTabContent" class="tab-content active">
                            <div class="tab-pane active" id="all_friends">
                                <div class="header-title-bg">
                                    <?php echo $lang[413]; ?> <b><?php echo $count_all; ?></b>
                                </div>
                                <br><br><br>
                                <div id="id_all_friends"></div>
                            </div>
                            <div class="tab-pane" id="in_friends">
                                <div class="header-title-bg">
                                    <?php echo $lang[414]; ?> <b><?php echo $count_in; ?></b>
                                </div>
                                    <br><br><br>
                                <div id="id_in_friends"></div>
                            </div>    
                            <div class="tab-pane" id="out_friends">
                                <div class="header-title-bg">
                                    <?php echo $lang[415]; ?> <b><?php echo $count_out; ?></b>
                                </div>
                                <br><br><br>
                                <div id="id_out_friends"></div>
                            </div>
                        </div>
                    </div>                        
                </div>                        
            </div>
        </div>                
        
        <?php include $_SERVER['DOCUMENT_ROOT'].'/modal/visits.php'; ?>
        <?php include $_SERVER['DOCUMENT_ROOT'].'/modal/otvety.php'; ?>
        
        <div class="talker">
        <div class="talker_message"></div>
        </div>            
        <?php include $_SERVER['DOCUMENT_ROOT'].'/templates/footer.tpl'; ?>    
        <script>
            <?php if ($my_id):?>var otvety_count = <?php echo $count_otvety; ?>;<?php endif;?>
            var page = 1;
            var more = false;
        </script>
        <script src="/js/system/<?php echo $js_lang; ?>/friends.js?r=<?php echo $global_rand; ?>" type="text/javascript"></script>
    </body>
</html>