<?php
include $_SERVER['DOCUMENT_ROOT'].'/inc/config.php';
$global_rand = rand(100000, 999999);
$title = $lang[440];
?>
<?php
include $_SERVER['DOCUMENT_ROOT'].'/functions/top_search.php';
include $_SERVER['DOCUMENT_ROOT'].'/functions/login.php';
include $_SERVER['DOCUMENT_ROOT'].'/functions/recovery.php';    


include $_SERVER['DOCUMENT_ROOT']."/inc/agent.php";
$agent->init();
?>
<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta name="description" content="">
        <meta name="author" content="">
        <title><?php echo $title; ?></title>
        <link href="/img/favicon.png" rel="shortcut icon" type="image/x-icon" />        
        <link rel="stylesheet" type="text/css" href="/css/bootstrap.css?r=<?php echo $global_rand; ?>" />
        <link rel="stylesheet" type="text/css" href="/icon/style.css?r=<?php echo $global_rand; ?>" />
    </head>
    <body role="document">
        <?php include $_SERVER['DOCUMENT_ROOT'].'/templates/header_user.tpl'; ?>
        <div class="container" style="margin-top:70px; margin-bottom:20px;">
            <div class="row" class="bs-example bs-example-tabs">
                <div class="col-md-2" style="padding-bottom:15px;">
                    <?php include $_SERVER['DOCUMENT_ROOT'].'/templates/user_left_menu.tpl'; ?>
                </div>        
                <div class="col-md-2"></div>
                <div class="col-md-6">
                <p style="text-align:center;"><?php echo $lang[441]; ?></p>
                    <div id="id_form" style="padding:20px; background-color:#ffffff; border:1px solid #e1e1e8; border-radius:4px; margin-bottom:20px;">    
                        <div class="header-title-bg">
                            <?php echo $lang[442]; ?>
                        </div>
                        <div class="form-group" style="margin-top:40px;">
                            <label><?php echo $lang[443]; ?></label>
                            <input id="id_email" placeholder="<?php echo $lang[443]; ?>" class="form-control" value="">
                        </div>
                        <div class="row" style="margin-top:5px;">
                            <div class="col-md-12">
                                <div class="form-group" style="text-align:right;">
                                    <button type="button" class="btn btn-primary" onClick="start_recovery();"><?php echo $lang[444]; ?></button>
                                </div>
                            </div>
                        </div>
                    </div>                        
                </div>    
                <div class="col-md-2"></div>
            </div>
        </div>                
        
        <div class="talker">
        <div class="talker_message"></div>
        </div>            
        <?php include $_SERVER['DOCUMENT_ROOT'].'/templates/footer.tpl'; ?>    
        <script src="/js/system/<?php echo $js_lang; ?>/recovery.js?r=<?php echo $global_rand; ?>" type="text/javascript"></script>                
    </body>
</html>