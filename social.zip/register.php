<?php
include $_SERVER['DOCUMENT_ROOT'].'/inc/config.php';
$global_rand = rand(100000, 999999);
$title = $lang[30];
?>
<?php
include $_SERVER['DOCUMENT_ROOT'].'/functions/change_captcha.php';
include $_SERVER['DOCUMENT_ROOT'].'/functions/top_search.php';
include $_SERVER['DOCUMENT_ROOT'].'/functions/live_captcha.php';
include $_SERVER['DOCUMENT_ROOT'].'/functions/live_email.php';
include $_SERVER['DOCUMENT_ROOT'].'/functions/register.php';


include $_SERVER['DOCUMENT_ROOT']."/inc/agent.php";
$agent->init();
?>
<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta name="description" content="">
        <meta name="author" content="">
        <title><?php echo $title; ?></title>
        <link href="/img/favicon.png" rel="shortcut icon" type="image/x-icon" />    
        <link href="/css/bootstrap.css" rel="stylesheet">
        <link rel="stylesheet" type="text/css" href="//fonts.googleapis.com/css?family=Lobster" />
    </head>
        <body role="document">
        <?php
        include $_SERVER['DOCUMENT_ROOT'].'/templates/header_user.tpl';
        ?>

        <div class="container" style="margin-top:70px; margin-bottom:20px;">
            <div class="row">
                <div class="col-md-3"></div>
                    <div class="col-md-6">
                    <p><h4 style="text-align:center;"><?php echo $lang[31]; ?></h4></p>
                    <p style="text-align:center;"><?php echo $lang[32]; ?></p>
                        <div style="padding:20px; background-color:#ffffff; border:1px solid #e1e1e8; border-radius:4px; margin-bottom:20px;">
                            <div class="header-title-bg">
                                <?php echo $lang[33]; ?>
                            </div>
                            <br><br><br>
                            <div class="form-group">
                                <label><?php echo $lang[34]; ?></label>
                                <input id="id_firstname" placeholder="<?php echo $lang[35]; ?>" class="form-control" data-toggle="tooltip" data-placement="top" title="" onKeyDown="$('#id_firstname').tooltip('destroy'); if(event.keyCode==13){start_register();}">
                            </div>
                            <div class="form-group">
                                <label><?php echo $lang[36]; ?></label>
                                <input id="id_lastname" placeholder="<?php echo $lang[37]; ?>" class="form-control"  data-toggle="tooltip" data-placement="top" title="" onKeyDown="$('#id_lastname').tooltip('destroy'); if(event.keyCode==13){start_register();}">
                            </div>
                            <div class="form-group" style="margin:0px;">
                                <label><?php echo $lang[38]; ?></label>
                                <div  id="id_pol" class="row" data-toggle="tooltip" data-placement="top" title="">
                                    <div class="col-md-12" style="padding-bottom:15px;">
                                    <b class="caret" style="position:absolute; margin-top:15px; margin-left:calc(100% - 50px); z-index:1000; cursor:pointer;"></b><div id="id_sex" placeholder="<?php echo $lang[39]; ?>" class="form-control" class="dropdown-toggle" data-toggle="dropdown" aria-expanded="true" onKeyDown="$('#id_firstdate').tooltip('destroy'); if(event.keyCode==13){start_register();}" style="height:34px; padding-top:8px; border:1px solid #ccc; cursor:pointer;"><?php echo $lang[40]; ?></div>
                                    <ul class="dropdown-menu" style="min-width:calc(100% - 30px); width:calc(100% - 30px); margin-left:15px; margin-top:-16px; border-color:#CCC;">
                                        <li><a onClick="document.getElementById('id_sex').innerHTML=this.innerHTML; $('#id_pol').tooltip('destroy');"><?php echo $lang[41]; ?></a></li>
                                        <li><a onClick="document.getElementById('id_sex').innerHTML=this.innerHTML; $('#id_pol').tooltip('destroy');"><?php echo $lang[42]; ?></a></li>
                                    </ul>
                                    </div>
                                </div>
                            </div>      
                            <div class="form-group">
                                <label for="exampleInputPassword1"><?php echo $lang[43]; ?></label>     
                                <div id="id_firstdate" class="row"  data-toggle="tooltip" data-placement="top" title="">
                                    <div class="col-md-4" style="padding-bottom:15px;">
                                        <b class="caret" style="position:absolute; margin-top:15px; margin-left:calc(100% - 50px); z-index:1000; cursor:pointer;"></b><div id="id_day" placeholder="<?php echo $lang[44]; ?>" class="form-control" class="dropdown-toggle" data-toggle="dropdown" aria-expanded="true" onKeyDown="$('#id_firstdate').tooltip('destroy'); if(event.keyCode==13){start_register();}" style="height:34px; padding-top:8px; border:1px solid #ccc; cursor:pointer;"><?php echo $lang[45]; ?></div>
                                        <ul class="dropdown-menu" style="min-width:calc(100% - 30px); width:calc(100% - 30px); height:115px; margin-left:15px; margin-top:-16px; overflow-y:scroll; overflow-x:hidden; border-color:#CCC;">
                                        <?php
                                        for ($i=1; $i<32; $i++) {
                                        echo '<li><a onClick="document.getElementById(\'id_day\').innerHTML=this.innerHTML; $(\'#id_firstdate\').tooltip(\'destroy\');">'.$i.'</a></li>
                                        ';    
                                        }
                                        ?>
                                        </ul>
                                    </div>    
                                    <div class="col-md-4" style="padding-bottom:15px;">
                                        <b class="caret" style="position:absolute; margin-top:15px; margin-left:calc(100% - 50px); z-index:1000; cursor:pointer;"></b><div id="id_month" placeholder="<?php echo $lang[46]; ?>" class="form-control" class="dropdown-toggle" data-toggle="dropdown" aria-expanded="true" onKeyDown="$('#id_firstdate').tooltip('destroy'); if(event.keyCode==13){start_register();}" style="height:34px; padding-top:8px; border:1px solid #ccc; cursor:pointer;"><?php echo $lang[47]; ?></div>
                                        <ul class="dropdown-menu" style="min-width:calc(100% - 30px); width:calc(100% - 30px); height:115px; margin-left:15px; margin-top:-16px; overflow-y:scroll; overflow-x:hidden;">
                                        <?php
                                        $months = $lang[48];
                                        $arr_months = explode(', ', $months);
                                        for ($i=0; $i<count($arr_months); $i++) {
                                        echo '<li><a onClick="document.getElementById(\'id_month\').innerHTML=this.innerHTML; $(\'#id_firstdate\').tooltip(\'destroy\');">'.$arr_months[$i].'</a></li>
                                        ';    
                                        }
                                        ?>
                                        </ul>
                                    </div>
                                    <div class="col-md-4" style="padding-bottom:15px;">
                                        <b class="caret" style="position:absolute; margin-top:15px; margin-left:calc(100% - 50px); z-index:1000; cursor:pointer;"></b><div id="id_year" placeholder="<?php echo $lang[49]; ?>" class="form-control" class="dropdown-toggle" data-toggle="dropdown" aria-expanded="true" onKeyDown="$('#id_firstdate').tooltip('destroy'); if(event.keyCode==13){start_register();}" style="height:34px; padding-top:8px; border:1px solid #ccc; cursor:pointer;"><?php echo $lang[50]; ?></div>
                                        <ul class="dropdown-menu" style="min-width:calc(100% - 30px); width:calc(100% - 30px); height:115px; margin-left:15px; margin-top:-16px; overflow-y:scroll; overflow-x:hidden; border-color:#CCC;">
                                        <?php
                                        for ($i=1955; $i<2006; $i++) {
                                        echo '<li><a onClick="document.getElementById(\'id_year\').innerHTML=this.innerHTML; $(\'#id_firstdate\').tooltip(\'destroy\');">'.$i.'</a></li>
                                        ';    
                                        }
                                        ?>
                                        </ul>
                                    </div>
                                </div>                
                            </div>
                            <hr style="border-color:#CCCCCC;">      
                            <div class="form-group">
                                <label><?php echo $lang[51]; ?></label>
                                <input id="id_email" placeholder="<?php echo $lang[52]; ?>" class="form-control" class="dropdown-toggle" data-toggle="dropdown" aria-expanded="true" onKeyDown="$('#id_email').tooltip('destroy'); if(event.keyCode==13){start_register();}" style="height:34px; border:1px solid #ccc;" />
                            </div>
                            <div class="form-group">
                                <label><?php echo $lang[53]; ?></label>
                                <input id="id_password_1" type="password" placeholder="<?php echo $lang[54]; ?>" class="form-control" class="dropdown-toggle" data-toggle="dropdown" aria-expanded="true" onKeyDown="$('#id_password_1').tooltip('destroy'); $('#id_password_2').tooltip('destroy'); if(event.keyCode==13){start_register();}" style="height:34px; border:1px solid #ccc;" />
                            </div>
                            <div class="form-group">
                                <label><?php echo $lang[55]; ?></label>
                                <input id="id_password_2" type="password" placeholder="<?php echo $lang[56]; ?>" class="form-control" class="dropdown-toggle" data-toggle="dropdown" aria-expanded="true" onKeyDown="$('#id_password_1').tooltip('destroy'); $('#id_password_2').tooltip('destroy'); if(event.keyCode==13){start_register();}" style="height:34px; border:1px solid #ccc;" />
                            </div>      
                            <label><?php echo $lang[57]; ?></label>
                            <div class="row" id="id_cap" data-toggle="tooltip" data-placement="top" title="">
                                <div class="col-md-3" style="text-align:center;">
                                    <div class="form-group">
                                        <img id="id_captcha" src="" onClick="change_captcha();" style="cursor:pointer;" />
                                    </div>
                                </div>
                                <div class="col-md-9">
                                    <div class="form-group">
                                        <input id="id_code" placeholder="<?php echo $lang[58]; ?>" class="form-control" class="dropdown-toggle" data-toggle="dropdown" aria-expanded="true" onKeyDown="$('#id_cap').tooltip('destroy'); if(event.keyCode==13){start_register();}" style="height:34px; border:1px solid #ccc;" />
                                    </div>
                                </div>
                            </div> 
                            <div class="row" id="id_cap" data-toggle="tooltip" data-placement="top" title="">
                                <div id="id_error" class="col-md-9"></div>
                                <div class="col-md-3">
                                    <div class="form-group" style="text-align:right;">
                                        <button type="button" class="btn btn-primary" onClick="start_register();"><?php echo $lang[59]; ?></button>
                                    </div>
                                </div>
                            </div>        
                        </div>
                    </div>
                <div class="col-md-3"></div>
            </div> 
        </div>
        
        <div class="talker">
            <div class="talker_message"></div>
        </div>
        
        <?php
        include $_SERVER['DOCUMENT_ROOT'].'/templates/footer.tpl';
        ?>
        <script src="/js/system/<?php echo $js_lang; ?>/register.js?r=<?php echo $global_rand; ?>" type="text/javascript"></script>
    </body>
</html>