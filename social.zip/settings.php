<?php
include $_SERVER['DOCUMENT_ROOT'].'/inc/config.php';
include $_SERVER['DOCUMENT_ROOT'].'/inc/login.php';
if ($my_id) {
    include $_SERVER['DOCUMENT_ROOT'].'/inc/sql_social.php';
    $z_count_otvety = mysql_query("SELECT * FROM news WHERE user_to='$my_id'");
    $count_otvety = mysql_num_rows($z_count_otvety);

    mysql_close($msconnect);
    $global_rand = rand(100000, 999999);
    $title = $lang[473];
} else {
    header('Location: /'.$link[3]);
}
?>
<?php
include $_SERVER['DOCUMENT_ROOT'].'/functions/top_search.php';
include $_SERVER['DOCUMENT_ROOT'].'/functions/change_email.php';
include $_SERVER['DOCUMENT_ROOT'].'/functions/change_password.php';
include $_SERVER['DOCUMENT_ROOT'].'/functions/ping_online.php';
include $_SERVER['DOCUMENT_ROOT'].'/functions/visits.php';
include $_SERVER['DOCUMENT_ROOT'].'/functions/otvety.php';
        

include $_SERVER['DOCUMENT_ROOT']."/inc/agent.php";
$agent->init();
?>
<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta name="description" content="">
        <meta name="author" content="">
        <title><?php echo $title; ?></title>
        <link href="/img/favicon.png" rel="shortcut icon" type="image/x-icon" />    
        <link rel="stylesheet" type="text/css" href="/css/bootstrap.css?r=<?php echo $global_rand; ?>" />
        <link rel="stylesheet" type="text/css" href="/icon/style.css?r=<?php echo $global_rand; ?>" />
        <script>
        <?php if ($my_id):?>
            token_email = '<?php echo md5($my_id.'_editemail_'.$secret); ?>';
            token_password = '<?php echo md5($my_id.'_editpassword_'.$secret); ?>';
            onload = function() {
                ping_online();
            }
        <?php endif;?>
        </script>
    </head>
    <body role="document">
        <?php include $_SERVER['DOCUMENT_ROOT'].'/templates/header_user.tpl'; ?>
        <div class="container" style="margin-top:70px; margin-bottom:20px;">
            <div class="row" class="bs-example bs-example-tabs">
                <div class="col-md-2" style="padding-bottom:15px;">
                    <?php include $_SERVER['DOCUMENT_ROOT'].'/templates/user_left_menu.tpl'; ?>
                </div>                            
                <div class="col-md-3">                    
                    <div style="padding-top:5px; padding-bottom:5px; background-color:#ffffff; border:1px solid #e1e1e8; border-radius:4px; margin-bottom:20px;">
                        <ul id="myTab" class="list-group" style="margin:0px;">
                            <li class="list-group-item active list-group-edit" style="padding:10px; padding-left:20px; border-radius:0px;" onClick="$('#myTab a[href=\'#email\']').tab('show');"><a href="#email" data-toggle="tab"><?php echo $lang[474]; ?></a></li>
                            <li class="list-group-item list-group-edit" style="padding:10px; padding-left:20px; border-radius:0px; margin-top:5px;" onClick="$('#myTab a[href=\'#password\']').tab('show');"><a href="#password" data-toggle="tab"><?php echo $lang[475]; ?></a></li>
                        </ul>
                    </div>    
                </div>
                <div class="col-md-7">
                    <div style="padding:20px; background-color:#ffffff; border:1px solid #e1e1e8; border-radius:4px; margin-bottom:20px;">    
                        <div id="myTabContent" class="tab-content active">
                            <div class="tab-pane active" id="email">
                                <div class="header-title-bg">
                                    <?php echo $lang[476]; ?>
                                </div>
                                <br><br><br>
                                <div class="form-group">
                                    <label><?php echo $lang[477]; ?></label>
                                    <input id="id_last_email" placeholder="<?php echo $lang[478]; ?>" class="form-control" data-toggle="tooltip" data-placement="top" title="" value="" onKeyDown="$('#id_last_email').tooltip('destroy');">
                                </div>
                                <div class="form-group">
                                    <label><?php echo $lang[479]; ?></label>
                                    <input id="id_next_email" placeholder="<?php echo $lang[480]; ?>" class="form-control" data-toggle="tooltip" data-placement="top" title="" value="" onKeyDown="$('#id_next_email').tooltip('destroy');">
                                </div>
                                <div class="row" style="margin-top:5px;">
                                    <div class="col-md-12">
                                        <div class="form-group" style="text-align:right;">
                                            <button type="button" class="btn btn-primary" onClick="start_edit_email();"><?php echo $lang[481]; ?></button>
                                        </div>
                                    </div>
                                </div>    
                            </div>
                            <div class="tab-pane" id="password">
                                <div class="header-title-bg">
                                    <?php echo $lang[482]; ?>
                                </div>
                                <br><br><br>
                                <div class="form-group">
                                    <label><?php echo $lang[483]; ?></label>
                                    <input id="id_last_password" type="password" placeholder="<?php echo $lang[484]; ?>" class="form-control" data-toggle="tooltip" data-placement="top" title="" value="" onKeyDown="$('#id_last_password').tooltip('destroy');">
                                </div>
                                <div class="form-group">
                                    <label><?php echo $lang[485]; ?></label>
                                    <input id="id_next_password" type="password" placeholder="<?php echo $lang[486]; ?>" class="form-control" data-toggle="tooltip" data-placement="top" title="" value="" onKeyDown="$('#id_next_password').tooltip('destroy');">
                                </div>
                                <div class="row" style="margin-top:5px;">
                                    <div class="col-md-12">
                                        <div class="form-group" style="text-align:right;">
                                            <button type="button" class="btn btn-primary" onClick="start_edit_password();"><?php echo $lang[487]; ?></button>
                                        </div>
                                    </div>
                                </div>    
                            </div>
                        </div>
                    </div>                            
                </div>                        
            </div>
        </div>                

        <?php include $_SERVER['DOCUMENT_ROOT'].'/modal/visits.php'; ?>
        <?php include $_SERVER['DOCUMENT_ROOT'].'/modal/otvety.php'; ?>
        
        <div class="talker">
        <div class="talker_message"></div>
        </div>            
        <?php include $_SERVER['DOCUMENT_ROOT'].'/templates/footer.tpl'; ?>    
        <script>
            <?php if ($my_id):?>var otvety_count = <?php echo $count_otvety; ?>;<?php endif;?>
            var page = 1;
            var more = false;
        </script>
        <script src="/js/system/<?php echo $js_lang; ?>/settings.js?r=<?php echo $global_rand; ?>" type="text/javascript"></script>

    </body>
</html>