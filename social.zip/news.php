<?php
include $_SERVER['DOCUMENT_ROOT'].'/inc/config.php';
include $_SERVER['DOCUMENT_ROOT'].'/inc/login.php';
include $_SERVER['DOCUMENT_ROOT'].'/inc/sql_social.php';

$z_last_chat_id = mysql_query("SELECT * FROM chat WHERE talk_id='0' OR talk_id='-1' OR user_id='$my_id' OR talk_id='$my_id' ORDER BY chat_id DESC");
$o_last_chat_id = mysql_fetch_array($z_last_chat_id);
$last_chat_id = $o_last_chat_id['chat_id'];
if (!$last_chat_id) {
    $last_chat_id = 0;
}

$rand = rand(10000, 99999);
$z_user_avatar = mysql_query("SELECT * FROM users WHERE id='$my_id'");
$o_user_avatar = mysql_fetch_array($z_user_avatar);
$user_avatar = $o_user_avatar['avatar'];
$user_sex = $o_user_avatar['sex'];
if ($user_avatar==0) {
    if ($user_sex==1) { $avatar = '/img/no_photo/girl.png?r='.$rand; }
    if ($user_sex==2) { $avatar = '/img/no_photo/boy.png?r='.$rand; }
} else {
    $avatar = '/avatar/'.$my_id.'.jpg?r='.$rand;
}

if ($my_id) {
    $z_count_news = mysql_query("SELECT id FROM wall_to_users WHERE user_id='$my_id'");
    $count_news = mysql_num_rows($z_count_news);
} else {
    $z_count_news = mysql_query("SELECT DISTINCT (wall_id) FROM wall_to_users");
    $count_news = mysql_num_rows($z_count_news);
}

if ($my_id) {
    $z_live_news = mysql_query("SELECT id FROM wall_to_users WHERE user_id='$my_id' and status='1'");
    $o_live_news = mysql_fetch_array($z_live_news);
    $live_news = $o_live_news['id'];
    
    if ($live_news) {
        mysql_query("UPDATE wall_to_users SET status='0' WHERE user_id='$my_id'");
    }
}

$z_count_otvety = mysql_query("SELECT * FROM news WHERE user_to='$my_id'");
$count_otvety = mysql_num_rows($z_count_otvety);

mysql_close($msconnect);
$global_rand = rand(100000, 999999);
$title = $lang[427];
?>
<?php
include $_SERVER['DOCUMENT_ROOT'].'/functions/top_search.php';
include $_SERVER['DOCUMENT_ROOT'].'/functions/login.php';
include $_SERVER['DOCUMENT_ROOT'].'/functions/like_news.php';
include $_SERVER['DOCUMENT_ROOT'].'/functions/like_peoples.php';
include $_SERVER['DOCUMENT_ROOT'].'/functions/load_photo.php';
include $_SERVER['DOCUMENT_ROOT'].'/functions/send_chat.php';
include $_SERVER['DOCUMENT_ROOT'].'/functions/load_chat.php';
include $_SERVER['DOCUMENT_ROOT'].'/functions/del_chat.php';
include $_SERVER['DOCUMENT_ROOT'].'/functions/ping.php';
include $_SERVER['DOCUMENT_ROOT'].'/functions/ping_online.php';
include $_SERVER['DOCUMENT_ROOT'].'/functions/load_wall_news.php';
include $_SERVER['DOCUMENT_ROOT'].'/functions/del_wall_news.php';
include $_SERVER['DOCUMENT_ROOT'].'/functions/visits.php';
include $_SERVER['DOCUMENT_ROOT'].'/functions/otvety.php';


include $_SERVER['DOCUMENT_ROOT']."/inc/agent.php";
$agent->init();
?>
<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta name="description" content="">
        <meta name="author" content="">
        <title><?php echo $title; ?></title>
        <meta name="description" content="<?php echo $description; ?>" />
        <meta name="keywords" content="<?php echo $keywords; ?>" />
        <link href="/img/favicon.png" rel="shortcut icon" type="image/x-icon" />        
        <link rel="stylesheet" type="text/css" href="/css/bootstrap.css?r=<?php echo $global_rand; ?>" />
        <link rel="stylesheet" type="text/css" href="/css/jcrop.css?r=<?php echo $global_rand; ?>" />
        <link rel="stylesheet" type="text/css" href="/slick/slick.css?r=<?php echo $global_rand; ?>">
        <link rel="stylesheet" type="text/css" href="/slick/slick-theme.css?r=<?php echo $global_rand; ?>">
        <link rel="stylesheet" type="text/css" href="//fonts.googleapis.com/css?family=Lobster" />
        <link rel="stylesheet" type="text/css" href="/icon/style.css?r=<?php echo $global_rand; ?>" />
        <script>
        var my_id = <?php if ($my_id) { echo $my_id; } else { echo 0; } ?>;
        <?php if ($my_id):?>var tokens = ['<?php echo md5($my_id.'_chat_'.$secret);?>', '<?php echo md5($my_id.'_sendchat_'.$secret); ?>'];<?php endif;?>
        </script>
    </head>
    <body role="document">
        <?php
        include $_SERVER['DOCUMENT_ROOT'].'/templates/header_user.tpl';
        ?>
        <div class="container" style="margin-top:70px; margin-bottom:20px;">
            <div class="row">
                <div class="col-md-2" style="padding-bottom:15px;">
                    <?php include $_SERVER['DOCUMENT_ROOT'].'/templates/user_left_menu.tpl'; ?>
                </div>
                <div class="col-md-3">                
                    <div style="padding-top:5px; padding-bottom:5px; background-color:#ffffff; border:1px solid #e1e1e8; border-radius:4px; margin-bottom:20px;">
                        <ul id="myTab" class="list-group" style="margin:0px;">
                            <li class="list-group-item active list-group-edit" style="padding:10px; padding-left:20px; border-radius:0px;" onClick="$('#myTab a[href=\'#news\']').tab('show');"><a href="#news" data-toggle="tab"><?php echo $lang[428]; ?> <span style="float:right; padding-right:5px; color:#777; font-size:11px; padding-top:1px;"><b><?php echo $count_news; ?></b></span></a></li>
                            <li class="list-group-item list-group-edit" style="padding:10px; padding-left:20px; border-radius:0px; margin-top:5px;" onClick="$('#myTab a[href=\'#chat\']').tab('show');"><a href="#chat" data-toggle="tab"><?php echo $lang[429]; ?> <span style="float:right; padding-right:5px; color:#777; font-size:11px; padding-top:1px;"><b id="id_count_chat"></b></span></a></li>
                        </ul>
                    </div>    
                    <div style="padding:15px; padding-bottom:0px; padding-top:7px; background-color:#ffffff; border:1px solid #e1e1e8; border-radius:4px; margin-bottom:20px;">    
                        <div class="header-title-bg" style="margin-top:-7px; margin-left:-15px;">
                            <?php echo $lang[430]; ?> <b id="count_chat_people"></b>
                        </div>
                        <div id="id_users_online" class="row" style="padding:0px 15px 15px 15px; margin-top:40px; min-height:100px; max-height:250px;">     
                        </div>
                    </div>
                </div>
                <div class="col-md-7">
                        <div id="myTabContent" class="tab-content active">
                            <div id="news" class="tab-pane active" style="padding:15px; padding-top:7px; background-color:#ffffff; border:1px solid #e1e1e8; border-radius:4px; margin-bottom:20px;">
                                <div class="header-title-bg" style="margin-top:-7px; margin-left:-15px;">
                                    <?php echo $lang[431]; ?> <b><?php echo $count_news; ?></b>
                                </div>
                                <div id="id_wall_body" style="padding:0px; padding-top:55px;"></div>
                            </div>    
                            <div id="chat" class="tab-pane" style="padding:15px; padding-top:7px; background-color:#ffffff; border:1px solid #e1e1e8; border-radius:4px; margin-bottom:20px;">    
                                <div id="id_title_chat" class="header-title-bg" style="margin-top:-7px; margin-left:-15px;">
                                    <?php echo $lang[432]; ?><?php if (!$my_id):?>, <?php echo $lang[433]; ?><?php endif;?>
                                </div>
                                <div class="row" style="padding:0px; padding-top:40px;">
                                    <?php if ($my_id):?>
                                    <div style="padding:15px; background:#f5f5f5;">
                                        <div style="float:left;">
                                            <a href="/id<?php echo $my_id ?>"><img width="30" height="30" src="<?php echo $avatar ?>" style="border-radius:100px;"></a>
                                        </div>
                                        <div style="width:calc(100% - 30px); float:left; padding-left:10px;">
                                            <textarea id="id_chat" placeholder="<?php echo $lang[434]; ?>" style="height:33px; width:100%; padding:7px; resize:none; border:1px solid #e1e1e8;" onClick="this.style.height='70px';" onKeyDown="if(event.keyCode==13){token='<?php echo md5($my_id.'_sendchat_'.$secret); ?>'; send_chat();}"></textarea>
                                            <div id="upload_chat_results"></div>
                                            <div id="id_upload_chat_status" style="width:30%; float:left; padding-top:15px;"></div>
                                            <div style="width:70%; float:left; padding-top:10px;">
                                                <button id="id_button_send" type="button" class="btn btn-primary" onclick="token='<?php echo md5($my_id.'_sendchat_'.$secret); ?>'; send_chat();" style="float:right;"><?php echo $lang[435]; ?></button>
                                                <span id="id_open_smiles_chat" data-toggle="popover" data-html="true" data-placement="top" data-content="<div><img width='20' height='20' src='/img/smiles/m_1.png' style='margin:2px; cursor:pointer;' onClick='smile_id=1; add_smile_chat();' /><img  width='20' height='20' src='/img/smiles/m_2.png' style='margin:2px; cursor:pointer;' onClick='smile_id=2; add_smile_chat();' /><img  width='20' height='20' src='/img/smiles/m_3.png' style='margin:2px; cursor:pointer;' onClick='smile_id=3; add_smile_chat();' /><img  width='20' height='20' src='/img/smiles/m_4.png' style='margin:2px; cursor:pointer;' onClick='smile_id=4; add_smile_chat();' /><img  width='20' height='20' src='/img/smiles/m_5.png' style='margin:2px; cursor:pointer;' onClick='smile_id=5; add_smile_chat();' /><img  width='20' height='20' src='/img/smiles/m_6.png' style='margin:2px; cursor:pointer;' onClick='smile_id=6; add_smile_chat();' /><img  width='20' height='20' src='/img/smiles/m_7.png' style='margin:2px; cursor:pointer;' onClick='smile_id=7; add_smile_chat();' /></div><div><img width='20' height='20' src='/img/smiles/m_8.png' style='margin:2px; cursor:pointer;' onClick='smile_id=8; add_smile_chat();' /><img  width='20' height='20' src='/img/smiles/m_9.png' style='margin:2px; cursor:pointer;' onClick='smile_id=9; add_smile_chat();' /><img  width='20' height='20' src='/img/smiles/m_10.png' style='margin:2px; cursor:pointer;' onClick='smile_id=10; add_smile_chat();' /><img  width='20' height='20' src='/img/smiles/m_11.png' style='margin:2px; cursor:pointer;' onClick='smile_id=11; add_smile_chat();' /><img  width='20' height='20' src='/img/smiles/m_12.png' style='margin:2px; cursor:pointer;' onClick='smile_id=12; add_smile_chat();' /><img  width='20' height='20' src='/img/smiles/m_13.png' style='margin:2px; cursor:pointer;' onClick='smile_id=13; add_smile_chat();' /><img  width='20' height='20' src='/img/smiles/m_14.png' style='margin:2px; cursor:pointer;' onClick='smile_id=14; add_smile_chat();' /></div><div><img width='20' height='20' src='/img/smiles/m_15.png' style='margin:2px; cursor:pointer;' onClick='smile_id=15; add_smile_chat();' /><img  width='20' height='20' src='/img/smiles/m_16.png' style='margin:2px; cursor:pointer;' onClick='smile_id=16; add_smile_chat();' /><img  width='20' height='20' src='/img/smiles/m_17.png' style='margin:2px; cursor:pointer;' onClick='smile_id=17; add_smile_chat();' /><img  width='20' height='20' src='/img/smiles/m_18.png' style='margin:2px; cursor:pointer;' onClick='smile_id=18; add_smile_chat();' /><img  width='20' height='20' src='/img/smiles/m_19.png' style='margin:2px; cursor:pointer;' onClick='smile_id=19; add_smile_chat();' /><img  width='20' height='20' src='/img/smiles/m_20.png' style='margin:2px; cursor:pointer;' onClick='smile_id=20; add_smile_chat();' /><img  width='20' height='20' src='/img/smiles/m_21.png' style='margin:2px; cursor:pointer;' onClick='smile_id=21; add_smile_chat();' /></div><div><img width='20' height='20' src='/img/smiles/m_22.png' style='margin:2px; cursor:pointer;' onClick='smile_id=22; add_smile_chat();' /><img  width='20' height='20' src='/img/smiles/m_23.png' style='margin:2px; cursor:pointer;' onClick='smile_id=23; add_smile_chat();' /><img  width='20' height='20' src='/img/smiles/m_24.png' style='margin:2px; cursor:pointer;' onClick='smile_id=24; add_smile_chat();' /><img  width='20' height='20' src='/img/smiles/m_25.png' style='margin:2px; cursor:pointer;' onClick='smile_id=25; add_smile_chat();' /><img  width='20' height='20' src='/img/smiles/m_26.png' style='margin:2px; cursor:pointer;' onClick='smile_id=26; add_smile_chat();' /><img  width='20' height='20' src='/img/smiles/m_27.png' style='margin:2px; cursor:pointer;' onClick='smile_id=27; add_smile_chat();' /><img  width='20' height='20' src='/img/smiles/m_28.png' style='margin:2px; cursor:pointer;' onClick='smile_id=28; add_smile_chat();' /></div><div><img width='20' height='20' src='/img/smiles/m_29.png' style='margin:2px; cursor:pointer;' onClick='smile_id=29; add_smile_chat();' /><img  width='20' height='20' src='/img/smiles/m_30.png' style='margin:2px; cursor:pointer;' onClick='smile_id=30; add_smile_chat();' /><img  width='20' height='20' src='/img/smiles/m_31.png' style='margin:2px; cursor:pointer;' onClick='smile_id=31; add_smile_chat();' /><img  width='20' height='20' src='/img/smiles/m_32.png' style='margin:2px; cursor:pointer;' onClick='smile_id=32; add_smile_chat();' /><img  width='20' height='20' src='/img/smiles/m_33.png' style='margin:2px; cursor:pointer;' onClick='smile_id=33; add_smile_chat();' /><img  width='20' height='20' src='/img/smiles/m_34.png' style='margin:2px; cursor:pointer;' onClick='smile_id=34; add_smile_chat();' /><img  width='20' height='20' src='/img/smiles/m_35.png' style='margin:2px; cursor:pointer;' onClick='smile_id=35; add_smile_chat();' /></div>" class="icon-bird" style="color:#999; font-size:20px; float:right; margin-top:7px; margin-right:15px; cursor:pointer;" onmouseover="$('#id_open_smiles_chat').popover();" data-original-title="" title=""></span>
                                            </div>
                                        </div>
                                    </div>
                                    <div style="padding:15px; background:#f5f5f5; border-bottom:1px solid #e1e1e8;"><div class="row"></div></div>
                                    <?php endif;?>
                                    <div id="id_chat_body" style="padding:15px; padding-bottom:0px;"></div>
                                </div>
                            </div>
                        </div>
                </div>    
            </div>
        </div>
        <?php include $_SERVER['DOCUMENT_ROOT'].'/modal/photo.php'; ?>
        <?php include $_SERVER['DOCUMENT_ROOT'].'/modal/likes.php'; ?>
        <?php include $_SERVER['DOCUMENT_ROOT'].'/modal/load_photo.php'; ?>
        <?php include $_SERVER['DOCUMENT_ROOT'].'/modal/visits.php'; ?>
        <?php include $_SERVER['DOCUMENT_ROOT'].'/modal/otvety.php'; ?>


        <div class="talker">
        <div class="talker_message"></div>
        </div>            
        <?php include $_SERVER['DOCUMENT_ROOT'].'/templates/footer.tpl'; ?>    
        <?php if ($my_id):?><script src="/uploadify/jquery.uploadifive.min.js?r=<?php echo $global_rand; ?>" type="text/javascript"></script><?php endif;?>
        <script src="/js/jcrop.js?r=<?php echo $global_rand; ?>"></script>
        <script src="/slick/slick.js?r=<?php echo $global_rand; ?>" type="text/javascript" charset="utf-8"></script>
        <script type="text/javascript">
        <?php if ($my_id):?>otvety_count = <?php echo $count_otvety; ?>;<?php endif;?>
        live_send = true;
        talk_name = '';
        talk_id = 0;
        page = 1000000000;
        more = false;
        live_ping = true;
        live_load = true;
        page_wall = 1;
        more = false;
        
        onload = function() {
            <?php if ($my_id):?>
            init_upload_chat();
            ping_online();
            <?php endif;?>
            loadwall();
            loadchat();
        }
        </script>
        <script src="/js/system/<?php echo $js_lang; ?>/news.js?r=<?php echo $global_rand; ?>" type="text/javascript"></script>
    </body>
</html