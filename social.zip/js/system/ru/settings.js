function exit() {
document.cookie = "l=";
document.cookie = "p=";
location = '/';
}

function talker() {
if (document.getElementsByClassName('talker')[0].style.display!=='block') {
document.getElementsByClassName('talker_message')[0].innerHTML = str_talker;
document.getElementsByClassName('talker')[0].style.display = 'block';
setTimeout(talker_close, 5000);
}
}

function talker_close() {
document.getElementsByClassName('talker')[0].style.display = 'none';
}

function start_edit_email() {
eme = new RegExp("^[0-9a-zA-Z\-_\.]+@[0-9a-zA-Z\-_\.]+\.[a-zA-Z]{2,4}$");
live_email_last = true;
live_email_next = true;
email_last = document.getElementById('id_last_email').value;
email_next = document.getElementById('id_next_email').value;
p_email();
}

function p_email() {
if (email_last.length==0) {
live_email_last = false;
error_email_last = 'E-mail не должен быть пустым';
} else {
if (!eme.test(email_last)) {
live_email_last = false;
error_email_last = 'Не верно заполнен E-mail';
}
}

if (email_next.length==0) {
live_email_next = false;
error_email_next = 'E-mail не должен быть пустым';
} else {
if (!eme.test(email_next)) {
live_email_next = false;
error_email_next = 'Не верно заполнен E-mail';
}
}

if (!live_email_last) {
document.getElementById("id_last_email").title = error_email_last;
$('#id_last_email').tooltip('show');
}

if (!live_email_next) {
document.getElementById("id_next_email").title = error_email_next;
$('#id_next_email').tooltip('show');
}

if (live_email_last && live_email_next) {
agent.call('' ,'change_email', 'otvet_change_email', email_last, email_next, token_email);
} else {
str_talker = 'Некоторые поля заполнены не правильно. Пожалуйста, вернитесь назад и заполните поля правильно.'; talker();
}
}

function otvet_change_email(str) {
if (str=='0') { str_talker = 'Произошла ошибка.'; talker(); }
if (str=='1') { str_talker = 'Такой E-mail существует в системе.'; talker(); }
if (str=='2') { str_talker = 'Существующий E-mail указан не правильно.'; talker(); }
if (str=='3') { str_talker = 'Ваш E-mail успешно изменен. Теперь используйте новый E-mail для входа.'; talker(); }
}


function start_edit_password() {
live_password_last = true;
live_password_next = true;
password_last = document.getElementById('id_last_password').value;
password_next = document.getElementById('id_next_password').value;
p_password();
}

function p_password() {
if (password_last.length==0) {
live_password_last = false;
error_password_last = 'Пароль не должен быть пустым';
} else {
if (password_last.length<6) {
live_password_last = false;
error_password_last = 'Слишком короткий пароль';
}}

if (!live_password_last) {
document.getElementById("id_last_password").title = error_password_last;
$('#id_last_password').tooltip('show');
}

if (password_next.length==0) {
live_password_next = false;
error_password_next = 'Пароль не должен быть пустым';
} else {
if (password_next.length<6) {
live_password_next = false;
error_password_next = 'Слишком короткий пароль';
}}

if (!live_password_next) {
document.getElementById("id_next_password").title = error_password_next;
$('#id_next_password').tooltip('show');
}

if (live_password_last && live_password_next) {
agent.call('' ,'change_password', 'otvet_change_password', password_last, password_next, token_password);
} else {
str_talker = 'Некоторые поля заполнены не правильно. Пожалуйста, вернитесь назад и заполните поля правильно.'; talker();
}
}

function otvet_change_password(str) {
if (str=='0') { str_talker = 'Произошла ошибка.'; talker(); }
if (str=='2') { str_talker = 'Существующий пароль указан не правильно.'; talker(); }
if (str=='3') { str_talker = 'Ваш пароль успешно изменен. Теперь используйте новый пароль для входа.'; talker(); }
}

function closesearch() {
document.getElementById('topsearch').style.display='none';
}

function top_search() {
top_query = document.getElementById('id_top_query').value;
if (top_query!=='') {
agent.call('' ,'topsearch', 'otvet_topsearch', top_query);
} else {
document.getElementById('top_result').innerHTML = '';
document.getElementById('topsearch').style.display='none';
}
}

function otvet_topsearch(str) {
if (str!=='') {
document.getElementById('topsearch').style.display='block';
document.getElementById('top_result').innerHTML = str;
} else {
document.getElementById('topsearch').style.display='none';
}
}

function otvety() {
if (!more) {
document.getElementById('id_body_otvety').innerHTML = '<div style="text-align:center; padding:20px;"><img src="/img/preloader.gif" /></div>';
}
$('#id_modal_otvety').modal('show');
if (document.getElementById('id_otvety_more_all')) {
document.getElementById('id_otvety_more_all').innerHTML = '<img src="/img/preloader.gif" />';
}
agent.call('' ,'otvety', 'otvet_otvety', more, page, token);
}

function otvet_otvety(str) {
if (document.getElementById('id_otvety_more_all')) {
document.getElementById('id_otvety_more_all').parentNode.removeChild(document.getElementById('id_otvety_more_all'));
}
if (str[0]!=='') {
if (more) {
document.getElementById('id_body_otvety').innerHTML = document.getElementById('id_body_otvety').innerHTML + str[0];
} else {
document.getElementById('id_body_otvety').innerHTML = str[0];
}
} else {
document.getElementById('id_body_otvety').innerHTML = '<p style="padding:15px; margin-bottom:0px; background:#f5f5f5; border-radius:4px; text-align:center;">Ответы отсутствуют.</p>';
}
document.getElementById('id_otvety_count').innerHTML = str[1];
}

function ping_online() {
agent.call('' ,'ping_online', 'otvet_ping_online', otvety_count);
}

function otvet_ping_online(str) {
if (str[0]!==0) {
document.getElementById('id_u_visits').innerHTML = '+'+str[0];
document.getElementById('id_u_visits').style.display = 'block';
} else {
document.getElementById('id_u_visits').innerHTML = '';
document.getElementById('id_u_visits').style.display = 'none';
}

if (str[1]!==0) {
document.getElementById('id_u_news').innerHTML = '+'+str[1];
document.getElementById('id_u_news').style.display = 'block';
} else {
document.getElementById('id_u_news').innerHTML = '';
document.getElementById('id_u_news').style.display = 'none';
}

if (str[2]!==0) {
document.getElementById('id_u_friends').innerHTML = '+'+str[2];
document.getElementById('id_u_friends').style.display = 'block';
} else {
document.getElementById('id_u_friends').innerHTML = '';
document.getElementById('id_u_friends').style.display = 'none';
}

if (str[3]!==0) {
document.getElementById('id_u_otvety').innerHTML = '+'+str[3];
document.getElementById('id_u_otvety').style.display = 'block';
} else {
document.getElementById('id_u_otvety').innerHTML = '';
document.getElementById('id_u_otvety').style.display = 'none';
}

if (otvety_count!==str[5]) {
otvety_count = str[5];
str_talker = str[6]; talker();
}

if (str[7]!==0) {
document.getElementById('id_u_dialogs').innerHTML = '+'+str[7];
document.getElementById('id_u_dialogs').style.display = 'block';
} else {
document.getElementById('id_u_dialogs').innerHTML = '';
document.getElementById('id_u_dialogs').style.display = 'none';
}

setTimeout(ping_online, 3000);
}

function visits() {
$('#id_modal_visits').modal('show');
if (document.getElementById('id_visits_more_all')) {
document.getElementById('id_visits_more_all').innerHTML = '<img src="/img/preloader.gif" />';
}
agent.call('' ,'visits', 'otvet_visits', more, page, token);
}

function otvet_visits(str) {
if (document.getElementById('id_visits_more_all')) {
document.getElementById('id_visits_more_all').parentNode.removeChild(document.getElementById('id_visits_more_all'));
}
if (str[0]!=='') {
if (more) {
document.getElementById('id_visits_peoples').innerHTML = document.getElementById('id_visits_peoples').innerHTML + str[0];
} else {
document.getElementById('id_visits_peoples').innerHTML = str[0];
}
} else {
document.getElementById('id_visits_peoples').innerHTML = '<p style="padding:15px; margin-bottom:0px; background:#f5f5f5; border-radius:4px; text-align:center;">К Вам еще никто не заходил.</p>';
}
document.getElementById('id_visits_count').innerHTML = str[1];
}