function ping() {
if (live_load) {
agent.call('' ,'ping', 'otvet_ping', first_chat_id);
} else {
setTimeout(ping, 1000)
}
}

function otvet_ping(str) {
if (live_load) {
if (str[0].length>0) {
users_online = '';
document.getElementById('id_users_online').style.overflowY = 'scroll';
document.getElementById('count_chat_people').innerHTML = str[0].length;
document.getElementById('id_count_chat').innerHTML = str[0].length;
for (i=0; i<str[0].length; i++) {
if (my_id!==0) {
if (talk_id!==parseInt(str[0][i][0])) { chat_but = '<span class="icon-chat" style="color:#46af48; font-size:19px; cursor:pointer;" onClick="if(talk_id!==0){close_talk();} talk_id='+str[0][i][0]+'; talk_name=\''+str[0][i][1]+'\'; talk();">'; } else { chat_but = '<span class="glyphicon glyphicon-remove" style="font-size:12px; color:#999; cursor:pointer;" onClick="talk_id='+talk_id+'; talk_name=\''+talk_name+'\'; close_talk();"></span>'; }
users_online = users_online + '<div style="margin-top:5px;"><div style="width:75%; float:left;"><div style="float:left;"><a href="/id'+str[0][i][0]+'"><img id="id_top_avatar" width="27" height="27" src="'+str[0][i][3]+'" style="border-radius:100px;"></a></div><div style="font-size:11px; float:left; padding-left:10px;"><a href="/id'+str[0][i][0]+'">'+str[0][i][1]+'</a><br><span style="font-size:10px; color:#777;">'+str[0][i][2]+'</span></div></div><div style="width:25%; float:right;"><div id="id_chatstatus_'+str[0][i][0]+'" style="float:right;">'+chat_but+'</span></div></div><br><br><hr style="margin-top:0px; margin-bottom:0px;"></div>';
} else {
users_online = users_online + '<div style="margin-top:5px;"><div style="width:75%; float:left;"><div style="float:left;"><a href="/id'+str[0][i][0]+'"><img id="id_top_avatar" width="27" height="27" src="'+str[0][i][3]+'" style="border-radius:100px;"></a></div><div style="font-size:11px; float:left; padding-left:10px;"><a href="/id'+str[0][i][0]+'">'+str[0][i][1]+'</a><br><span style="font-size:10px; color:#777;">'+str[0][i][2]+'</span></div></div><br><br><hr style="margin-top:0px; margin-bottom:0px;"></div>';
}
}
document.getElementById('id_users_online').innerHTML = users_online;
} else {
document.getElementById('id_users_online').style.overflowY = '';
document.getElementById('count_chat_people').innerHTML = '';
document.getElementById('id_users_online').innerHTML = '<p style="padding:15px; border-radius:4px; text-align:center;">Сейчас в чате пусто.</p>';
}
if (str[1]!=='') {
document.getElementById('id_chat_body').innerHTML = str[1] + document.getElementById('id_chat_body').innerHTML;
first_chat_id = str[2];
}
live_send = true;
setTimeout(ping, 3000);
} else {
live_send = true;
setTimeout(ping, 3000);
}
}

function otvet_ping_read(str) {
if (str[0].length>0) {
users_online = '';
document.getElementById('id_users_online').style.overflowY = 'scroll';
document.getElementById('count_chat_people').innerHTML = str[0].length;
document.getElementById('id_count_chat').innerHTML = str[0].length;
for (i=0; i<str[0].length; i++) {
if (my_id!==0) {
if (talk_id!==parseInt(str[0][i][0])) { chat_but = '<span class="icon-chat" style="color:#46af48; font-size:19px; cursor:pointer;" onClick="if(talk_id!==0){close_talk();} talk_id='+str[0][i][0]+'; talk_name=\''+str[0][i][1]+'\'; talk();">'; } else { chat_but = '<span class="glyphicon glyphicon-remove" style="font-size:12px; color:#999; cursor:pointer;" onClick="talk_id='+talk_id+'; talk_name=\''+talk_name+'\'; close_talk();"></span>'; }
users_online = users_online + '<div style="margin-top:5px;"><div style="width:75%; float:left;"><div style="float:left;"><a href="/id'+str[0][i][0]+'"><img id="id_top_avatar" width="27" height="27" src="'+str[0][i][3]+'" style="border-radius:100px;"></a></div><div style="font-size:11px; float:left; padding-left:10px;"><a href="/id'+str[0][i][0]+'">'+str[0][i][1]+'</a><br><span style="font-size:10px; color:#777;">'+str[0][i][2]+'</span></div></div><div style="width:25%; float:right;"><div id="id_chatstatus_'+str[0][i][0]+'" style="float:right;">'+chat_but+'</span></div></div><br><br><hr style="margin-top:0px; margin-bottom:0px;"></div>';
} else {
users_online = users_online + '<div style="margin-top:5px;"><div style="width:75%; float:left;"><div style="float:left;"><a href="/id'+str[0][i][0]+'"><img id="id_top_avatar" width="27" height="27" src="'+str[0][i][3]+'" style="border-radius:100px;"></a></div><div style="font-size:11px; float:left; padding-left:10px;"><a href="/id'+str[0][i][0]+'">'+str[0][i][1]+'</a><br><span style="font-size:10px; color:#777;">'+str[0][i][2]+'</span></div></div><br><br><hr style="margin-top:0px; margin-bottom:0px;"></div>';
}
}
document.getElementById('id_users_online').innerHTML = users_online;
} else {
document.getElementById('id_users_online').style.overflowY = '';
document.getElementById('count_chat_people').innerHTML = '';
document.getElementById('id_users_online').innerHTML = '<p style="padding:15px; border-radius:4px; text-align:center;">Сейчас в чате пусто.</p>';
}
if (document.getElementById('id_chat_preloader')) { document.getElementById('id_chat_preloader').parentNode.removeChild(document.getElementById('id_chat_preloader')); }
if (str[1]!=='') {
document.getElementById('id_chat_body').innerHTML = str[1] + document.getElementById('id_chat_body').innerHTML;
first_chat_id = str[2];
}
live_load = true;
live_send = true;
}

function log_in() {
l = document.getElementById('id_login').value;
p = document.getElementById('id_password').value;
if (l=='' || p=='') {
str_talker = 'Поля E-mail и пароль не должны быть пустыми.'; talker();
} else {
agent.call('' ,'login', 'otvet_login', l, p);
}
}

function otvet_login(str) {
if (str=='false') {
document.getElementById('id_login').value = '';
document.getElementById('id_password').value= '';
str_talker = 'Неверный E-mail или пароль, попробуйте авторизоваться снова, или воспользуйтесь ссылкой восстановления пароля.'; talker();
} else {
location = '/';
}
}

function talker() {
if (document.getElementsByClassName('talker')[0].style.display!=='block') {
document.getElementsByClassName('talker_message')[0].innerHTML = str_talker;
document.getElementsByClassName('talker')[0].style.display = 'block';
setTimeout(talker_close, 5000);
}
}

function talker_close() {
document.getElementsByClassName('talker')[0].style.display = 'none';
}

function exit() {
document.cookie = "l=";
document.cookie = "p=";
location = '/';
}

function closesearch() {
document.getElementById('topsearch').style.display='none';
}

function top_search() {
top_query = document.getElementById('id_top_query').value;
if (top_query!=='') {
agent.call('' ,'topsearch', 'otvet_topsearch', top_query);
} else {
document.getElementById('top_result').innerHTML = '';
document.getElementById('topsearch').style.display='none';
}
}

function otvet_topsearch(str) {
if (str!=='') {
document.getElementById('topsearch').style.display='block';
document.getElementById('top_result').innerHTML = str;
} else {
document.getElementById('topsearch').style.display='none';
}
}

function loadchat() {
if (document.getElementById('id_search_more_chat')) { 
document.getElementById('id_search_more_chat').innerHTML = '<img src="/img/preloader.gif" />'; 
} else {
document.getElementById('id_chat_body').innerHTML = '<div style="text-align:center; padding:20px;"><img src="/img/preloader.gif" /></div>';
}
agent.call('' ,'load_chat', 'otvet_loadchat', page);
}

function otvet_loadchat(str) {
if (document.getElementById('id_search_more_chat')) { document.getElementById('id_search_more_chat').parentNode.removeChild(document.getElementById('id_search_more_chat')); }
if (str[0]=='') {
document.getElementById('id_chat_body').innerHTML = '<p style="padding:15px; background:#f5f5f5; border-radius:4px; text-align:center; margin-bottom:0px;">Сообщения отсутствуют. Будьте первым!</p>';
} else {
if (more) {
document.getElementById('id_chat_body').innerHTML = document.getElementById('id_chat_body').innerHTML + str[0];
} else {
document.getElementById('id_chat_body').innerHTML = str[0];
}
}
if (live_ping) {
first_chat_id = str[1];
ping();
live_ping = false;
}
}

function like_peoples() {
$('#id_modal_photos').modal('hide');
$('#id_modal_likes').modal('show');
document.getElementById('id_like_peoples').innerHTML = '<div style="text-align:center; padding:20px;"><img src="/img/preloader.gif" /></div>';
if (document.getElementById('id_likes_more_all')) {
document.getElementById('id_likes_more_all').innerHTML = '<img src="/img/preloader.gif" />';
}
agent.call('' ,'like_peoples', 'otvet_like_peoples', object_id, object_type, more, page);
}

function otvet_like_peoples(str) {
if (document.getElementById('id_likes_more_all')) {
document.getElementById('id_likes_more_all').parentNode.removeChild(document.getElementById('id_likes_more_all'));
}
if (more) {
document.getElementById('id_like_peoples').innerHTML = document.getElementById('id_like_peoples').innerHTML + str[0];
} else {
document.getElementById('id_like_peoples').innerHTML = str[0];
}
document.getElementById('id_like_count').innerHTML = str[1];
}

function comment_photo_show() {
$('#id_comment_photo').modal('show');
document.getElementById('id_comment_photo_body').innerHTML = '<div style="text-align:center; padding:20px;"><img src="/img/preloader.gif" /></div>';
agent.call('' ,'load_photo', 'otvet_load_photo', photo_name);
}

function otvet_load_photo(str) {
document.getElementById('id_comment_photo_body').innerHTML = '<div style="text-align:center; padding:20px;"><img src="/img/preloader.gif" /></div>';
document.getElementById('id_comment_photo_body').innerHTML = str;
}

function loadwall() {
if (document.getElementById('id_search_more_wall')) { 
document.getElementById('id_search_more_wall').innerHTML = '<img src="/img/preloader.gif" />'; 
} else {
document.getElementById('id_wall_body').innerHTML = '<div style="text-align:center; padding:20px;"><img src="/img/preloader.gif" /></div>';
}
agent.call('' ,'load_wall', 'otvet_loadwall', page_wall);
}

function otvet_loadwall(str) {
if (document.getElementById('id_search_more_wall')) { document.getElementById('id_search_more_wall').parentNode.removeChild(document.getElementById('id_search_more_wall')); }
if (str=='') {
document.getElementById('id_wall_body').innerHTML = '<p style="padding:15px; margin-bottom:0px; background:#f5f5f5; border-radius:4px; text-align:center;">Новости отсутствуют.</p>';
} else {
if (more) {
document.getElementById('id_wall_body').innerHTML = document.getElementById('id_wall_body').innerHTML + str;
} else {
document.getElementById('id_wall_body').innerHTML = str;
}
}
}

function del_wall() {
agent.call('' ,'delwall', 'otvet_delwall', wall_id, token);
}

function otvet_delwall() {
if (document.getElementById('wall_'+wall_id)) { document.getElementById('wall_'+wall_id).parentNode.removeChild(document.getElementById('wall_'+wall_id)); }
str_talker = 'Сообщение удалено.'; talker();
}

function talk() {
document.getElementById('id_title_chat').innerHTML = 'Чат с пользователем <b>'+talk_name+'</b> <span class="glyphicon glyphicon-remove" style="font-size:12px; color:#999; cursor:pointer;" onClick="talk_id='+talk_id+'; talk_name=\''+talk_name+'\'; close_talk();"></span>';
document.getElementById('id_chatstatus_'+talk_id).innerHTML = '<span class="glyphicon glyphicon-remove" style="font-size:12px; color:#999;" onClick="talk_id='+talk_id+'; talk_name=\''+talk_name+'\'; close_talk();"></span>';
str_talker = 'Вы начали приватный чат, с пользователем '+talk_name+'.'; talker();
}

function close_talk() {
document.getElementById('id_title_chat').innerHTML = 'Общий чат';
document.getElementById('id_chatstatus_'+talk_id).innerHTML = '<span class="icon-chat" style="color:#46af48; font-size:19px; cursor:pointer;" onClick="if(talk_id!==0){close_talk();} talk_id='+talk_id+'; talk_name=\''+talk_name+'\'; talk();">';
talk_id = 0;
}

function init_upload_chat() {
arr_photos_chat = new Array();
document.getElementById('id_upload_chat_status').innerHTML = '<form style="text-align:left;"><input id="file_chat" name="file_chat" type="file" multiple="true" style="display:none;" onChange="$(\'#file_chat\').uploadifive(\'upload\');"></form>';
upload_chat_id = 0;
$('#file_chat').uploadifive({
'buttonText'    : '',
'buttonClass'   : 'glyphicon icon-attachment',
'fileSizeLimit' : '10240KB',
'uploadLimit'   : 5,
'fileDesc'      : 'jpg',
'fileExt'       : '*.jpg',
'auto'             : true,
'checkScript'      : '/uploadify/check-exists.php',
'formData'         : {'token':tokens[0]},
'uploadScript'     : '/uploadify/upload_chat.php',
'onUploadComplete' : function(file, data) {
if (data) {
if (data!=='0') {
document.getElementById('upload_chat_results').style.height = '50px';
document.getElementById('upload_chat_results').innerHTML = document.getElementById('upload_chat_results').innerHTML + '<div style="position:absolute; margin-left:'+(upload_chat_id*40)+'px; margin-top:10px; width:30px; height:30px; background-image: url(\'/photo/m_'+data+'.jpg\'); background-size:cover; background-position:center top; border-radius:50px; float:left;"></div>';
arr_photos_chat[upload_chat_id] = data;
} else {
global_error();
arr_photos_chat = new Array();
init_upload_chat();
}
}
document.getElementById('uploadifive-file_chat-file-'+upload_chat_id).parentNode.removeChild(document.getElementById('uploadifive-file_chat-file-'+upload_chat_id)); 
upload_chat_id++;
},
'onUpload' : function() {
document.getElementById('uploadifive-file_chat').parentNode.removeChild(document.getElementById('uploadifive-file_chat'));
}
});
}

function upload_photo_error() {
if (document.getElementById('uploadifive-file_chat-queue')) {
document.getElementById('uploadifive-file_chat-queue').parentNode.removeChild(document.getElementById('uploadifive-file_chat-queue'));
}
str_talker = 'Превышен лимит количества загружаемых изображений. Можно загружать по 5 картинок за один раз.'; talker();
}

function del_chat() {
agent.call('' ,'delchat', 'otvet_delchat', chat_id, token);
}

function otvet_delchat() {
if (document.getElementById('chat_'+chat_id)) { document.getElementById('chat_'+chat_id).parentNode.removeChild(document.getElementById('chat_'+chat_id)); }
str_talker = 'Сообщение удалено.'; talker();
}

function like() {
agent.call('' ,'like', 'otvet_like', object_id, object_type, token);
}

function otvet_like(str) {
if (str[0]=='1') {
document.getElementById('like_heart_'+object_type+'_'+object_id).style.color = '#5085ad';
if (document.getElementById('like_count_'+object_type+'_'+object_id).innerHTML=='') {
document.getElementById('like_count_'+object_type+'_'+object_id).innerHTML = 1;
} else {
document.getElementById('like_count_'+object_type+'_'+object_id).innerHTML = parseInt(document.getElementById('like_count_'+object_type+'_'+object_id).innerHTML)+1;
}
document.getElementById('popover_'+object_type+'_'+object_id).style.display = 'block';
}
if (str[0]=='0') {
document.getElementById('like_heart_'+object_type+'_'+object_id).style.color = '#b4cee2';
if (document.getElementById('like_count_'+object_type+'_'+object_id).innerHTML=='1') {
document.getElementById('like_count_'+object_type+'_'+object_id).innerHTML = '';
document.getElementById('popover_'+object_type+'_'+object_id).style.display = 'none';
} else {
document.getElementById('like_count_'+object_type+'_'+object_id).innerHTML = parseInt(document.getElementById('like_count_'+object_type+'_'+object_id).innerHTML)-1;
}
}
document.getElementById('popover_'+object_type+'_'+object_id).title = str[1];
$('#popover_'+object_type+'_'+object_id).tooltip('destroy');
}

function send_chat() {
if (live_send) {
if (document.getElementById('id_chat').value!=='' || arr_photos_chat.length>0) {
comment_chat = document.getElementById('id_chat').value;
document.getElementById('id_chat').value = '';
str_chat_photos = '';
if (arr_photos_chat.length>0) {
for (i=0; i<arr_photos_chat.length; i++) {
if (i==0) { str_chat_photos = str_chat_photos+arr_photos_chat[i]; } else { str_chat_photos = str_chat_photos+','+arr_photos_chat[i]; };
}
}
live_load = false;
agent.call('' ,'send_chat', 'otvet_send_chat', comment_chat, str_chat_photos, talk_id, token);
live_send = false;
} else {
str_talker = 'Материал не должен быть пустым.'; talker();
}
}
}

function otvet_send_chat(str) {
document.getElementById('id_chat').value = '';
document.getElementById('id_chat_body').innerHTML = '<div id="id_chat_preloader" style="text-align:center; padding:5px;"><img src="/img/preloader.gif" /></div>' + document.getElementById('id_chat_body').innerHTML;
document.getElementById('upload_chat_results').style.height = '0px';
document.getElementById('upload_chat_results').innerHTML = '';
init_upload_chat();
agent.call('' ,'ping', 'otvet_ping_read', first_chat_id);
}

function add_smile_chat() {
comment_chat = '<smile'+smile_id+' />';
str_chat_photos = '';
token = tokens[1];
agent.call('' ,'send_chat', 'otvet_send_chat', comment_chat, str_chat_photos, talk_id, token);
$('#id_open_smiles_chat').popover('destroy');
}

function global_error() {
str_talker = 'Произошла ошибка.'; talker();
}

function otvety() {
if (!more) {
document.getElementById('id_body_otvety').innerHTML = '<div style="text-align:center; padding:20px;"><img src="/img/preloader.gif" /></div>';
}
$('#id_modal_otvety').modal('show');
if (document.getElementById('id_otvety_more_all')) {
document.getElementById('id_otvety_more_all').innerHTML = '<img src="/img/preloader.gif" />';
}
agent.call('' ,'otvety', 'otvet_otvety', more, page, token);
}

function otvet_otvety(str) {
if (document.getElementById('id_otvety_more_all')) {
document.getElementById('id_otvety_more_all').parentNode.removeChild(document.getElementById('id_otvety_more_all'));
}
if (str[0]!=='') {
if (more) {
document.getElementById('id_body_otvety').innerHTML = document.getElementById('id_body_otvety').innerHTML + str[0];
} else {
document.getElementById('id_body_otvety').innerHTML = str[0];
}
} else {
document.getElementById('id_body_otvety').innerHTML = '<p style="padding:15px; margin-bottom:0px; background:#f5f5f5; border-radius:4px; text-align:center;">Ответы отсутствуют.</p>';
}
document.getElementById('id_otvety_count').innerHTML = str[1];
}

function ping_online() {
agent.call('' ,'ping_online', 'otvet_ping_online', otvety_count);
}

function otvet_ping_online(str) {
if (str[0]!==0) {
document.getElementById('id_u_visits').innerHTML = '+'+str[0];
document.getElementById('id_u_visits').style.display = 'block';
} else {
document.getElementById('id_u_visits').innerHTML = '';
document.getElementById('id_u_visits').style.display = 'none';
}

if (str[1]!==0) {
document.getElementById('id_u_news').innerHTML = '+'+str[1];
document.getElementById('id_u_news').style.display = 'block';
} else {
document.getElementById('id_u_news').innerHTML = '';
document.getElementById('id_u_news').style.display = 'none';
}

if (str[2]!==0) {
document.getElementById('id_u_friends').innerHTML = '+'+str[2];
document.getElementById('id_u_friends').style.display = 'block';
} else {
document.getElementById('id_u_friends').innerHTML = '';
document.getElementById('id_u_friends').style.display = 'none';
}

if (str[3]!==0) {
document.getElementById('id_u_otvety').innerHTML = '+'+str[3];
document.getElementById('id_u_otvety').style.display = 'block';
} else {
document.getElementById('id_u_otvety').innerHTML = '';
document.getElementById('id_u_otvety').style.display = 'none';
}

if (otvety_count!==str[5]) {
otvety_count = str[5];
str_talker = str[6]; talker();
}

if (str[7]!==0) {
document.getElementById('id_u_dialogs').innerHTML = '+'+str[7];
document.getElementById('id_u_dialogs').style.display = 'block';
} else {
document.getElementById('id_u_dialogs').innerHTML = '';
document.getElementById('id_u_dialogs').style.display = 'none';
}

setTimeout(ping_online, 3000);
}

function visits() {
$('#id_modal_visits').modal('show');
if (document.getElementById('id_visits_more_all')) {
document.getElementById('id_visits_more_all').innerHTML = '<img src="/img/preloader.gif" />';
}
agent.call('' ,'visits', 'otvet_visits', more, page, token);
}

function otvet_visits(str) {
if (document.getElementById('id_visits_more_all')) {
document.getElementById('id_visits_more_all').parentNode.removeChild(document.getElementById('id_visits_more_all'));
}
if (str[0]!=='') {
if (more) {
document.getElementById('id_visits_peoples').innerHTML = document.getElementById('id_visits_peoples').innerHTML + str[0];
} else {
document.getElementById('id_visits_peoples').innerHTML = str[0];
}
} else {
document.getElementById('id_visits_peoples').innerHTML = '<p style="padding:15px; margin-bottom:0px; background:#f5f5f5; border-radius:4px; text-align:center;">К Вам еще никто не заходил.</p>';
}
document.getElementById('id_visits_count').innerHTML = str[1];
}