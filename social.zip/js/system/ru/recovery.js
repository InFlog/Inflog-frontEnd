uid = 0;
function log_in() {
l = document.getElementById('id_login').value;
p = document.getElementById('id_password').value;
if (l=='' || p=='') {
str_talker = 'Поля E-mail и пароль не должны быть пустыми.'; talker();
} else {
agent.call('' ,'login', 'otvet_login', l, p);
}
}

function otvet_login(str) {
if (str=='false') {
document.getElementById('id_login').value = '';
document.getElementById('id_password').value= '';
str_talker = 'Неверный E-mail или пароль, попробуйте авторизоваться снова, или воспользуйтесь ссылкой восстановления пароля.'; talker();
} else {
location = '/';
}
}

function talker() {
if (document.getElementsByClassName('talker')[0].style.display!=='block') {
document.getElementsByClassName('talker_message')[0].innerHTML = str_talker;
document.getElementsByClassName('talker')[0].style.display = 'block';
setTimeout(talker_close, 5000);
}
}

function talker_close() {
document.getElementsByClassName('talker')[0].style.display = 'none';
}

function exit() {
document.cookie = "l=";
document.cookie = "p=";
location = '/';
}

function closesearch() {
document.getElementById('topsearch').style.display='none';
}

function top_search() {
top_query = document.getElementById('id_top_query').value;
if (top_query!=='') {
agent.call('' ,'topsearch', 'otvet_topsearch', top_query);
} else {
document.getElementById('top_result').innerHTML = '';
document.getElementById('topsearch').style.display='none';
}
}

function otvet_topsearch(str) {
if (str!=='') {
document.getElementById('topsearch').style.display='block';
document.getElementById('top_result').innerHTML = str;
} else {
document.getElementById('topsearch').style.display='none';
}
}

function start_recovery() {
email = document.getElementById('id_email').value;
if (email=='') {
str_talker = 'Поле E-mail не должно быть пустым.'; talker();
} else {
agent.call('' ,'recovery', 'otvet_recovery', email);
}
}

function otvet_recovery(str) {
if (str=='0') {
document.getElementById('id_email').value = '';
str_talker = 'Такой E-mail не зарегистрирован на сайте.'; talker();
} else {
uid = str;
document.getElementById('id_form').innerHTML = '<div class="header-title-bg">Восстановление пароля</div><div class="form-group" style="margin-top:40px;"><label>Код из письма</label><input id="id_password_recovery" placeholder="Код из письма" class="form-control" value=""></div><div class="row" style="margin-top:5px;"><div class="col-md-12"><div class="form-group" style="text-align:right;"><button type="button" class="btn btn-primary" onClick="start_recovery_login();">Войти</button></div></div></div>';
str_talker = 'На указанный E-mail было отправлено письмо с кодом. Вставьте код в поле.'; talker();
}
}

function start_recovery_login() {
recovery_password = document.getElementById('id_password_recovery').value;
if (recovery_password=='') {
str_talker = 'Поле с кодом не должно быть пустым.'; talker();
} else {
agent.call('' ,'recovery_login', 'otvet_recovery_login', uid, recovery_password);
}
}

function otvet_recovery_login(str) {
if (str=='0') {
str_talker = 'Не правильный код из письма.'; talker();
} else {
location = '/id'+str;
}
}