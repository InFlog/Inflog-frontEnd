function talker() {
if (document.getElementsByClassName('talker')[0].style.display!=='block') {
document.getElementsByClassName('talker_message')[0].innerHTML = str_talker;
document.getElementsByClassName('talker')[0].style.display = 'block';
setTimeout(talker_close, 5000);
}
}

function talker_close() {
document.getElementsByClassName('talker')[0].style.display = 'none';
}

function exit() {
document.cookie = "l=";
document.cookie = "p=";
location = '/';
}

function start_city_list() {
agent.call('' ,'city_list', 'otvet_city_list', country_id);
}

function otvet_city_list(str) {
document.getElementById('id_city_list').innerHTML = str;
document.getElementById('city_block').style.display = 'block';
}

function start_edit_main() {
live_firstname = true;
live_lastname = true;
live_sex = true;
live_day = true;
live_month = true;
live_year = true;
live_marital_status = true;
live_date = true;
live_country = true;
live_city = true;
firstname = document.getElementById('id_firstname').value;
lastname = document.getElementById('id_lastname').value;
sex = document.getElementById('id_sex').innerHTML;
day = document.getElementById('id_day').innerHTML;
month = document.getElementById('id_month').innerHTML;
year = document.getElementById('id_year').innerHTML;
marital_status = document.getElementById('id_marital_status').innerHTML;
country = document.getElementById('id_country').innerHTML;
city = document.getElementById('id_city').innerHTML;
sim = new RegExp("^[а-яА-ЯёЁa-zA-Z]+$"); 
eme = new RegExp("^[0-9a-zA-Z\-_\.]+@[0-9a-zA-Z\-_\.]+\.[a-zA-Z]{2,4}$");
p_firstname();
}

function p_firstname() {
if (firstname.length==0) {
live_firstname = false;
error_firstname = 'Имя не должно быть пустым';
} else {
if (firstname.length<2) {
live_firstname = false;
error_firstname = 'Слишком короткое имя';
} else {
if (!sim.test(firstname)) {
live_firstname = false;
error_firstname = 'Не верно заполнено имя';
}}}
if (!live_firstname) {
document.getElementById("id_firstname").title = error_firstname;
$('#id_firstname').tooltip('show');
}
p_lastname();
}

function p_lastname() {
if (lastname.length==0) {
live_lastname = false;
error_lastname = 'Фамилия не должна быть пустой';
} else {
if (lastname.length<2) {
live_lastname = false;
error_lastname = 'Слишком короткая фамилия';
} else {
if (!sim.test(lastname)) {
live_lastname = false;
error_lastname = 'Не верно заполнена фамилия';
}}}
if (!live_lastname) {
document.getElementById("id_lastname").title = error_lastname;
$('#id_lastname').tooltip('show');
}
p_sex();
}

function p_sex() {
if (sex.length==0) {
live_sex = false;
error_sex = 'Пол не выбран';
}
if (!live_sex) {
document.getElementById("id_pol").title = error_sex;
$('#id_pol').tooltip('show');
}
p_date();
}

function p_date() {
if (day.length==0) {
live_date = false;
error_date = 'Дата рождения не выбрана';
}
if (month.length==0) {
live_date = false;
error_date = 'Дата рождения не выбрана';
}
if (year.length==0) {
live_date = false;
error_date = 'Дата рождения не выбрана';
}
if (!live_date) {
document.getElementById("id_firstdate").title = error_date;
$('#id_firstdate').tooltip('show');
}
p_marital_status();
}

function p_marital_status() {
if (marital_status=='Не выбрано') { marital_status = 0; }
if (marital_status=='Не женат, не замужем') { marital_status = 1; }
if (marital_status=='Встречаюсь') { marital_status = 2; }
if (marital_status=='Помолвлен, помолвлена') { marital_status = 3; }
if (marital_status=='Женат, замужем') { marital_status = 4; }
if (marital_status=='Влюблен, влюблена') { marital_status = 5; }
if (marital_status=='Все сложно') { marital_status = 6; }
if (marital_status=='В активном поиске') { marital_status = 7; }
if (marital_status!==0) {
if (marital_status>0 || marital_status<8) { } else {
live_marital_status = false;
error_marital_status = 'Не верное значение';
document.getElementById("id_marital_status").title = error_marital_status;
$('#id_marital_status').tooltip('show');
}
}
p_country();
}

function p_country() {
if (country.length==0) {
live_country = false;
error_country = 'Страна не выбрана';
}
if (!live_country) {
document.getElementById("id_toolcountry").title = error_country;
$('#id_toolcountry').tooltip('show');
}
p_city();
}

function p_city() {
if (city.length==0) {
live_city = false;
error_city = 'Город не выбран';
}
if (!live_city) {
document.getElementById("id_toolcity").title = error_city;
$('#id_toolcity').tooltip('show');
}
finish_main();
}

function finish_main() {
if (live_firstname && live_lastname && live_sex && live_date && live_marital_status && live_country && live_city) {
token = tokens[0];
agent.call('' ,'edit_main', 'otvet_edit_main', firstname, lastname, sex, day, month, year, marital_status, country, city, token);
} else {
if (document.getElementsByClassName('talker')[0].style.display!=='block') {
str_talker = 'Некоторые поля заполнены не правильно. Пожалуйста, вернитесь назад и заполните поля правильно.'; talker();
}
}
}

function otvet_edit_main(str) {
if (str==true) {
str_talker = 'Личные данные успешно изменены.'; talker();
} else {
str_talker = 'Во время изменения данных произошла ошибка.'; talker();
}
}

function start_edit_contacts() {
live_phone = true;
live_mail = true;
live_skype = true;
live_site = true;
phone = document.getElementById('id_phone').value;
mail = document.getElementById('id_mail').value;
skype = document.getElementById('id_skype').value;
site = document.getElementById('id_site').value;
sim = new RegExp("^[a-z0-9._-]{3,16}$"); 
eme = new RegExp("^[0-9a-zA-Z\-_\.]+@[0-9a-zA-Z\-_\.]+\.[a-zA-Z]{2,4}$");
pho = new RegExp("^[0-9]{5,11}$");
sit = new RegExp("^(https?:\/\/)?([\da-z\.-]+)\.([a-z\.]{2,6})([\/\w \.-]*)*\/?$");
p_phone();
}

function p_phone() {
if (phone.length!==0 && !pho.test(phone)) {
live_phone = false;
error_phone = 'Не верно заполнен телефон';
document.getElementById("id_phone").title = error_phone;
$('#id_phone').tooltip('show');
}
p_mail();
}

function p_mail() {
if (mail.length!==0 && !eme.test(mail)) {
live_mail = false;
error_mail = 'Не верно заполнен E-mail';
document.getElementById("id_mail").title = error_mail;
$('#id_mail').tooltip('show');
}
p_skype();
}

function p_skype() {
if (skype.length!==0 && !sim.test(skype)) {
live_skype = false;
error_skype = 'Не верно заполнен skype';
document.getElementById("id_skype").title = error_skype;
$('#id_skype').tooltip('show');
}
p_site();
}

function p_site() {
if (site.length!==0 && !sit.test(site)) {
live_site = false;
error_site = 'Не верно заполнен сайт';
document.getElementById("id_site").title = error_site;
$('#id_site').tooltip('show');
}
finish_contacts();
}

function finish_contacts() {
if (live_phone && live_mail && live_skype && live_site) {
token = tokens[1];
agent.call('' ,'edit_contacts', 'otvet_edit_contacts', phone, mail, skype, site, token);
} else {
if (document.getElementsByClassName('talker')[0].style.display!=='block') {
str_talker = 'Некоторые поля заполнены не правильно. Пожалуйста, вернитесь назад и заполните поля правильно.'; talker();
}
}
}

function otvet_edit_contacts(str) {
if (str==true) {
str_talker = 'Контактные данные успешно изменены.'; talker();
} else {
str_talker = 'Во время изменения данных произошла ошибка.'; talker();
}
}

function start_edit_interests() {
live_activity = true;
live_interests = true;
live_music = true;
live_movies = true;
live_tv = true;
live_books = true;
live_games = true;
live_quotations = true;
live_about = true;
activity = document.getElementById('id_activity').value;
interests = document.getElementById('id_interests').value;
music = document.getElementById('id_music').value;
movies = document.getElementById('id_movies').value;
tv = document.getElementById('id_tv').value;
books = document.getElementById('id_books').value;
games = document.getElementById('id_games').value;
quotations = document.getElementById('id_quotations').value;
about = document.getElementById('id_about').value;
p_activity();
}

function p_activity() {
if (activity.length>10000) {
live_activity = false;
error_activity = 'Слишком большой текст';
document.getElementById("id_activity").title = error_activity;
$('#id_activity').tooltip('show');
}
p_interests();
}

function p_interests() {
if (interests.length>10000) {
live_interests = false;
error_interests = 'Слишком большой текст';
document.getElementById("id_interests").title = error_interests;
$('#id_interests').tooltip('show');
}
p_music();
}

function p_music() {
if (music.length>10000) {
live_music = false;
error_music = 'Слишком большой текст';
document.getElementById("id_music").title = error_music;
$('#id_music').tooltip('show');
}
p_movies();
}

function p_movies() {
if (movies.length>10000) {
live_movies = false;
error_movies = 'Слишком большой текст';
document.getElementById("id_movies").title = error_movies;
$('#id_movies').tooltip('show');
}
p_tv();
}

function p_tv() {
if (tv.length>10000) {
live_tv = false;
error_tv = 'Слишком большой текст';
document.getElementById("id_tv").title = error_tv;
$('#id_tv').tooltip('show');
}
p_books();
}

function p_books() {
if (books.length>10000) {
live_books = false;
error_books = 'Слишком большой текст';
document.getElementById("id_books").title = error_books;
$('#id_books').tooltip('show');
}
p_games();
}

function p_games() {
if (games.length>10000) {
live_games = false;
error_games = 'Слишком большой текст';
document.getElementById("id_games").title = error_games;
$('#id_games').tooltip('show');
}
p_quotations();
}

function p_quotations() {
if (quotations.length>10000) {
live_quotations = false;
error_quotations = 'Слишком большой текст';
document.getElementById("id_quotations").title = error_quotations;
$('#id_quotations').tooltip('show');
}
p_about();
}

function p_about() {
if (about.length>10000) {
live_about = false;
error_about = 'Слишком большой текст';
document.getElementById("id_about").title = error_about;
$('#id_about').tooltip('show');
}
finish_interests();
}

function finish_interests() {
if (live_activity && live_interests && live_music && live_movies && live_tv && live_books && live_games && live_quotations && live_about) {
token = tokens[2];
agent.call('' ,'edit_interests', 'otvet_edit_interests', activity, interests, music, movies, tv, books, games, quotations, about, token);
} else {
if (document.getElementsByClassName('talker')[0].style.display!=='block') {
str_talker = 'Некоторые поля заполнены не правильно. Пожалуйста, вернитесь назад и заполните поля правильно.'; talker();
}
}
}

function otvet_edit_interests(str) {
if (str==true) {
str_talker = 'Интересы успешно изменены.'; talker();
} else {
str_talker = 'Во время изменения данных произошла ошибка.'; talker();
}
}

function start_edit_education() {
live_institut = true;
live_department = true;
live_training = true;
live_education_info = true;
institut = document.getElementById('id_institut').value;
department = document.getElementById('id_department').value;
start_training = document.getElementById('id_start_training').innerHTML;
if (start_training=='Не выбрано') { start_training = 0; }
finish_training = document.getElementById('id_finish_training').innerHTML;
if (finish_training=='Не выбрано') { finish_training = 0; }
education_info = document.getElementById('id_education_info').value;
p_institut();
}

function p_institut() {
if (institut.length>300) {
live_institut = false;
error_institut = 'Слишком большой текст';
document.getElementById("id_institut").title = error_institut;
$('#id_institut').tooltip('show');
}
p_department();
}

function p_department() {
if (department.length>300) {
live_department = false;
error_department = 'Слишком большой текст';
document.getElementById("id_department").title = error_department;
$('#id_department').tooltip('show');
}
p_traning();
}

function p_traning() {
if (start_training) {
if (start_training!==0) {
if (start_training<1955 || start_training>2016) {
live_training = false;
error_training = 'Не правильный период';
}
}
}
if (finish_training) {
if (finish_training!==0) {
if (finish_training<1955 || finish_training>2016) {
live_training = false;
error_training = 'Не правильный период';
}
}
}
if (!live_training) {
document.getElementById("id_err_training").title = error_training;
$('#id_err_training').tooltip('show');
}
p_education_info();
}

function p_education_info() {
if (education_info.length>10000) {
live_education_info = false;
error_education_info = 'Слишком большой текст';
document.getElementById("id_education_info").title = error_education_info;
$('#id_education_info').tooltip('show');
}
finish_education();
}

function finish_education() {
if (live_institut && live_department && live_training && live_education_info) {
token = tokens[3];
agent.call('' ,'edit_education', 'otvet_edit_education', institut, department, start_training, finish_training, education_info, token);
} else {
if (document.getElementsByClassName('talker')[0].style.display!=='block') {
str_talker = 'Некоторые поля заполнены не правильно. Пожалуйста, вернитесь назад и заполните поля правильно.'; talker();
}
}
}

function otvet_edit_education(str) {
if (str==true) {
str_talker = 'Образование успешно изменено.'; talker();
} else {
str_talker = 'Во время изменения данных произошла ошибка.'; talker();
}
}

function start_edit_work() {
live_place_work = true;
live_position = true;
live_work_info = true;
place_work = document.getElementById('id_place_work').value;
position = document.getElementById('id_position').value;
work_info = document.getElementById('id_work_info').value;
p_place_work();
}

function p_place_work() {
if (place_work.length>300) {
live_place_work = false;
error_place_work = 'Слишком большой текст';
document.getElementById("id_place_work").title = error_place_work;
$('#id_place_work').tooltip('show');
}
p_position();
}

function p_position() {
if (position.length>300) {
live_position = false;
error_position = 'Слишком большой текст';
document.getElementById("id_position").title = error_position;
$('#id_position').tooltip('show');
}
p_work_info();
}

function p_work_info() {
if (work_info.length>10000) {
live_work_info = false;
error_work_info = 'Слишком большой текст';
document.getElementById("id_work_info").title = error_work_info;
$('#id_work_info').tooltip('show');
}
finish_work();
}

function finish_work() {
if (live_place_work && live_position && live_work_info) {
token = tokens[4];
agent.call('' ,'edit_work', 'otvet_edit_work', place_work, position, work_info, token);
} else {
if (document.getElementsByClassName('talker')[0].style.display!=='block') {
str_talker = 'Некоторые поля заполнены не правильно. Пожалуйста, вернитесь назад и заполните поля правильно.'; talker();
}
}
}

function otvet_edit_work(str) {
if (str==true) {
str_talker = 'Работа успешно изменена.'; talker();
} else {
str_talker = 'Во время изменения данных произошла ошибка.'; talker();
}
}

function start_edit_position() {
live_policy = true;
live_world_view = true;
live_important_live = true;
live_important_peoples = true;
live_smoking = true;
live_alcohol = true;
live_inspirations = true;
policy = document.getElementById('id_policy').innerHTML;
world_view = document.getElementById('id_world_view').innerHTML;
important_live = document.getElementById('id_important_live').innerHTML;
important_peoples = document.getElementById('id_important_peoples').innerHTML;
smoking = document.getElementById('id_smoking').innerHTML;
alcohol = document.getElementById('id_alcohol').innerHTML;
inspirations = document.getElementById('id_inspirations').value;
p_policy();
}

function p_policy() {
if (policy=='Не выбрано') { policy = 0; }
if (policy=='Индифферентные') { policy = 1; }
if (policy=='Коммунистические') { policy = 2; }
if (policy=='Социалистические') { policy = 3; }
if (policy=='Умеренные') { policy = 4; }
if (policy=='Либеральные') { policy = 5; }
if (policy=='Консервативные') { policy = 6; }
if (policy=='Монархические') { policy = 7; }
if (policy=='Ультраконсервативные') { policy = 8; }
if (policy!==0) {
if (policy>0 || policy<9) { } else {
live_policy = false;
error_policy = 'Не верное значение';
document.getElementById("id_policy").title = error_policy;
$('#id_policy').tooltip('show');
}
}
p_world_view();
}

function p_world_view() {
if (world_view=='Не выбрано') { world_view = 0; }
if (world_view=='Иудаизм') { world_view = 1; }
if (world_view=='Православие') { world_view = 2; }
if (world_view=='Католицизм') { world_view = 3; }
if (world_view=='Протестантизм') { world_view = 4; }
if (world_view=='Ислам') { world_view = 5; }
if (world_view=='Буддизм') { world_view = 6; }
if (world_view=='Конфуцианство') { world_view = 7; }
if (world_view=='Советский гуманизм') { world_view = 8; }
if (world_view=='Пастафарианство') { world_view = 9; }
if (world_view!==0) {
if (world_view>0 || world_view<10) { } else {
live_world_view = false;
error_world_view = 'Не верное значение';
document.getElementById("id_world_view").title = error_world_view;
$('#id_world_view').tooltip('show');
}
}
p_important_live();
}

function p_important_live() {
if (important_live=='Не выбрано') { important_live = 0; }
if (important_live=='Семья и дети') { important_live = 1; }
if (important_live=='Карьера и деньги') { important_live = 2; }
if (important_live=='Развлечения и отдых') { important_live = 3; }
if (important_live=='Наука и исследования') { important_live = 4; }
if (important_live=='Совершенствование мира') { important_live = 5; }
if (important_live=='Саморазвитие') { important_live = 6; }
if (important_live=='Красота и искусство') { important_live = 7; }
if (important_live=='Слава и влияние') { important_live = 8; }
if (important_live!==0) {
if (important_live>0 || important_live<9) { } else {
live_important_live = false;
error_important_live = 'Не верное значение';
document.getElementById("id_important_live").title = error_important_live;
$('#id_important_live').tooltip('show');
}
}
p_important_peoples();
}

function p_important_peoples() {
if (important_peoples=='Не выбрано') { important_peoples = 0; }
if (important_peoples=='Ум и креативность') { important_peoples = 1; }
if (important_peoples=='Доброта и честность') { important_peoples = 2; }
if (important_peoples=='Красота и здоровье') { important_peoples = 3; }
if (important_peoples=='Власть и богатство') { important_peoples = 4; }
if (important_peoples=='Смелость и упорство') { important_peoples = 5; }
if (important_peoples=='Юмор и жизнелюбие') { important_peoples = 6; }
if (important_peoples!==0) {
if (important_peoples>0 || important_peoples<7) { } else {
live_important_peoples = false;
error_important_peoples = 'Не верное значение';
document.getElementById("id_important_peoples").title = error_important_peoples;
$('#id_important_peoples').tooltip('show');
}
}
p_smoking();
}

function p_smoking() {
if (smoking=='Не выбрано') { smoking = 0; }
if (smoking=='Резко негативное') { smoking = 1; }
if (smoking=='Негативное') { smoking = 2; }
if (smoking=='Компромиссное') { smoking = 3; }
if (smoking=='Нейтральное') { smoking = 4; }
if (smoking=='Положительное') { smoking = 5; }
if (smoking!==0) {
if (smoking>0 || smoking<6) { } else {
live_smoking = false;
error_smoking = 'Не верное значение';
document.getElementById("id_smoking").title = error_smoking;
$('#id_smoking').tooltip('show');
}
}
p_alcohol();
}

function p_alcohol() {
if (alcohol=='Не выбрано') { alcohol = 0; }
if (alcohol=='Резко негативное') { alcohol = 1; }
if (alcohol=='Негативное') { alcohol = 2; }
if (alcohol=='Компромиссное') { alcohol = 3; }
if (alcohol=='Нейтральное') { alcohol = 4; }
if (alcohol=='Положительное') { alcohol = 5; }
if (alcohol!==0) {
if (alcohol>0 || alcohol<6) { } else {
live_alcohol = false;
error_alcohol = 'Не верное значение';
document.getElementById("id_alcohol").title = error_alcohol;
$('#id_alcohol').tooltip('show');
}
}
p_inspirations();
}

function p_inspirations() {
if (inspirations.length>1000) {
live_inspirations = false;
error_inspirations = 'Слишком большой текст';
document.getElementById("id_inspirations").title = error_inspirations;
$('#id_inspirations').tooltip('show');
}
finish_position();
}

function finish_position() {
if (live_policy && live_world_view && live_important_live && live_important_peoples && live_smoking && live_alcohol && live_inspirations) {
token = tokens[5];
agent.call('' ,'edit_position', 'otvet_edit_position', policy, world_view, important_live, important_peoples, smoking, alcohol, inspirations, token);
} else {
if (document.getElementsByClassName('talker')[0].style.display!=='block') {
str_talker = 'Некоторые поля заполнены не правильно. Пожалуйста, вернитесь назад и заполните поля правильно.'; talker();
}
}
}

function otvet_edit_position(str) {
if (str==true) {
str_talker = 'Жизненная позиция успешно изменена.'; talker();
} else {
str_talker = 'Во время изменения данных произошла ошибка.'; talker();
}
}

function closesearch() {
document.getElementById('topsearch').style.display='none';
}

function top_search() {
top_query = document.getElementById('id_top_query').value;
if (top_query!=='') {
agent.call('' ,'topsearch', 'otvet_topsearch', top_query);
} else {
document.getElementById('top_result').innerHTML = '';
document.getElementById('topsearch').style.display='none';
}
}

function otvet_topsearch(str) {
if (str!=='') {
document.getElementById('topsearch').style.display='block';
document.getElementById('top_result').innerHTML = str;
} else {
document.getElementById('topsearch').style.display='none';
}
}

function otvety() {
if (!more) {
document.getElementById('id_body_otvety').innerHTML = '<div style="text-align:center; padding:20px;"><img src="/img/preloader.gif" /></div>';
}
$('#id_modal_otvety').modal('show');
if (document.getElementById('id_otvety_more_all')) {
document.getElementById('id_otvety_more_all').innerHTML = '<img src="/img/preloader.gif" />';
}
agent.call('' ,'otvety', 'otvet_otvety', more, page, token);
}

function otvet_otvety(str) {
if (document.getElementById('id_otvety_more_all')) {
document.getElementById('id_otvety_more_all').parentNode.removeChild(document.getElementById('id_otvety_more_all'));
}
if (str[0]!=='') {
if (more) {
document.getElementById('id_body_otvety').innerHTML = document.getElementById('id_body_otvety').innerHTML + str[0];
} else {
document.getElementById('id_body_otvety').innerHTML = str[0];
}
} else {
document.getElementById('id_body_otvety').innerHTML = '<p style="padding:15px; margin-bottom:0px; background:#f5f5f5; border-radius:4px; text-align:center;">Ответы отсутствуют.</p>';
}
document.getElementById('id_otvety_count').innerHTML = str[1];
}

function ping_online() {
agent.call('' ,'ping_online', 'otvet_ping_online', otvety_count);
}

function otvet_ping_online(str) {
if (str[0]!==0) {
document.getElementById('id_u_visits').innerHTML = '+'+str[0];
document.getElementById('id_u_visits').style.display = 'block';
} else {
document.getElementById('id_u_visits').innerHTML = '';
document.getElementById('id_u_visits').style.display = 'none';
}

if (str[1]!==0) {
document.getElementById('id_u_news').innerHTML = '+'+str[1];
document.getElementById('id_u_news').style.display = 'block';
} else {
document.getElementById('id_u_news').innerHTML = '';
document.getElementById('id_u_news').style.display = 'none';
}

if (str[2]!==0) {
document.getElementById('id_u_friends').innerHTML = '+'+str[2];
document.getElementById('id_u_friends').style.display = 'block';
} else {
document.getElementById('id_u_friends').innerHTML = '';
document.getElementById('id_u_friends').style.display = 'none';
}

if (str[3]!==0) {
document.getElementById('id_u_otvety').innerHTML = '+'+str[3];
document.getElementById('id_u_otvety').style.display = 'block';
} else {
document.getElementById('id_u_otvety').innerHTML = '';
document.getElementById('id_u_otvety').style.display = 'none';
}

if (otvety_count!==str[5]) {
otvety_count = str[5];
str_talker = str[6]; talker();
}

if (str[7]!==0) {
document.getElementById('id_u_dialogs').innerHTML = '+'+str[7];
document.getElementById('id_u_dialogs').style.display = 'block';
} else {
document.getElementById('id_u_dialogs').innerHTML = '';
document.getElementById('id_u_dialogs').style.display = 'none';
}

setTimeout(ping_online, 3000);
}

function visits() {
$('#id_modal_visits').modal('show');
if (document.getElementById('id_visits_more_all')) {
document.getElementById('id_visits_more_all').innerHTML = '<img src="/img/preloader.gif" />';
}
agent.call('' ,'visits', 'otvet_visits', more, page, token);
}

function otvet_visits(str) {
if (document.getElementById('id_visits_more_all')) {
document.getElementById('id_visits_more_all').parentNode.removeChild(document.getElementById('id_visits_more_all'));
}
if (str[0]!=='') {
if (more) {
document.getElementById('id_visits_peoples').innerHTML = document.getElementById('id_visits_peoples').innerHTML + str[0];
} else {
document.getElementById('id_visits_peoples').innerHTML = str[0];
}
} else {
document.getElementById('id_visits_peoples').innerHTML = '<p style="padding:15px; margin-bottom:0px; background:#f5f5f5; border-radius:4px; text-align:center;">К Вам еще никто не заходил.</p>';
}
document.getElementById('id_visits_count').innerHTML = str[1];
}