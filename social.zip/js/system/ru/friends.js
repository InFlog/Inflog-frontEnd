function talker() {
if (document.getElementsByClassName('talker')[0].style.display!=='block') {
document.getElementsByClassName('talker_message')[0].innerHTML = str_talker;
document.getElementsByClassName('talker')[0].style.display = 'block';
setTimeout(talker_close, 5000);
}
}

function talker_close() {
document.getElementsByClassName('talker')[0].style.display = 'none';
}

function exit() {
document.cookie = "l=";
document.cookie = "p=";
location = '/';
}

function start_all_friends() {
if (!more) {
document.getElementById('id_all_friends').innerHTML = '<div style="text-align:center; padding:20px;"><img src="/img/preloader.gif" /></div>';
} else {
document.getElementById('id_friends_more_all').innerHTML = '<img src="/img/preloader.gif" />';
}
agent.call('' ,'all_friends', 'otvet_all_friends', uid, page); 
}

function otvet_all_friends(str) {
if (str=='') {
str = '<p style="padding:15px; background:#f5f5f5; border-radius:4px; margin-bottom:0px; text-align:center;">Друзья отсутствуют.</p>';
}
if (document.getElementById('id_friends_more_all')) { document.getElementById('id_friends_more_all').parentNode.removeChild(document.getElementById('id_friends_more_all')); }
if (more) {
document.getElementById('id_all_friends').innerHTML = document.getElementById('id_all_friends').innerHTML + str;
more = false;
} else {
document.getElementById('id_all_friends').innerHTML = str;
}
}

function start_in_friends() {
if (!more) {
document.getElementById('id_in_friends').innerHTML = '<div style="text-align:center; padding:20px;"><img src="/img/preloader.gif" /></div>';
} else {
document.getElementById('id_friends_more_in').innerHTML = '<img src="/img/preloader.gif" />';
}
agent.call('' ,'in_friends', 'otvet_in_friends', page);
}

function otvet_in_friends(str) {
if (str=='') {
str = '<p style="padding:15px; background:#f5f5f5; border-radius:4px; margin-bottom:0px; text-align:center;">Входящие заявки отсутствуют.</p>';
}
if (document.getElementById('id_friends_more_in')) { document.getElementById('id_friends_more_in').parentNode.removeChild(document.getElementById('id_friends_more_in')); }
if (more) {
document.getElementById('id_in_friends').innerHTML = document.getElementById('id_in_friends').innerHTML + str;
more = false;
} else {
document.getElementById('id_in_friends').innerHTML = str;
}
}

function start_out_friends() {
if (!more) {
document.getElementById('id_out_friends').innerHTML = '<div style="text-align:center; padding:20px;"><img src="/img/preloader.gif" /></div>';
} else {
document.getElementById('id_friends_more_out').innerHTML = '<img src="/img/preloader.gif" />';
}
agent.call('' ,'out_friends', 'otvet_out_friends', page);
}

function otvet_out_friends(str) {
if (str=='') {
str = '<p style="padding:15px; background:#f5f5f5; border-radius:4px; margin-bottom:0px; text-align:center;">Исходящие заявки отсутствуют.</p>';
}
if (document.getElementById('id_friends_more_out')) {
document.getElementById('id_friends_more_out').parentNode.removeChild(document.getElementById('id_friends_more_out')); 
}
if (more) {
document.getElementById('id_out_friends').innerHTML = document.getElementById('id_out_friends').innerHTML + str;
more = false;
} else {
document.getElementById('id_out_friends').innerHTML = str;
}
}

function delete_all_friends() {
agent.call('' ,'delete_allfriends', 'otvet_delete_allfriends', friend_id, token);
}

function otvet_delete_allfriends(str) {
str_talker = str+' удален из списка друзей.'; talker();
document.getElementById('friend_all_'+friend_id).parentNode.removeChild(document.getElementById('friend_all_'+friend_id));
}

function delete_on_friends() {
agent.call('' ,'delete_onfriends', 'otvet_delete_onfriends', friend_id, token);
}

function otvet_delete_onfriends(str) {
str_talker = str+' удален из списка входящих заявок.'; talker();
document.getElementById('friend_on_'+friend_id).parentNode.removeChild(document.getElementById('friend_on_'+friend_id));
}

function delete_out_friends() {
agent.call('' ,'delete_outfriends', 'otvet_delete_outfriends', friend_id, token);
}

function otvet_delete_outfriends(str) {
str_talker = str+' удален из списка исходящих заявок.'; talker();
document.getElementById('friend_out_'+friend_id).parentNode.removeChild(document.getElementById('friend_out_'+friend_id));
}

function add_on_friends() {
agent.call('' ,'add_onfriends', 'otvet_add_onfriends', friend_id, token);
}

function otvet_add_onfriends(str) {
str_talker = str+' добавлен в друзья.'; talker();
document.getElementById('friend_on_'+friend_id).parentNode.removeChild(document.getElementById('friend_on_'+friend_id));
}

function closesearch() {
document.getElementById('topsearch').style.display='none';
}

function top_search() {
top_query = document.getElementById('id_top_query').value;
if (top_query!=='') {
agent.call('' ,'topsearch', 'otvet_topsearch', top_query);
} else {
document.getElementById('top_result').innerHTML = '';
document.getElementById('topsearch').style.display='none';
}
}

function otvet_topsearch(str) {
if (str!=='') {
document.getElementById('topsearch').style.display='block';
document.getElementById('top_result').innerHTML = str;
} else {
document.getElementById('topsearch').style.display='none';
}
}

function otvety() {
if (!more) {
document.getElementById('id_body_otvety').innerHTML = '<div style="text-align:center; padding:20px;"><img src="/img/preloader.gif" /></div>';
}
$('#id_modal_otvety').modal('show');
if (document.getElementById('id_otvety_more_all')) {
document.getElementById('id_otvety_more_all').innerHTML = '<img src="/img/preloader.gif" />';
}
agent.call('' ,'otvety', 'otvet_otvety', more, page, token);
}

function otvet_otvety(str) {
if (document.getElementById('id_otvety_more_all')) {
document.getElementById('id_otvety_more_all').parentNode.removeChild(document.getElementById('id_otvety_more_all'));
}
if (str[0]!=='') {
if (more) {
document.getElementById('id_body_otvety').innerHTML = document.getElementById('id_body_otvety').innerHTML + str[0];
} else {
document.getElementById('id_body_otvety').innerHTML = str[0];
}
} else {
document.getElementById('id_body_otvety').innerHTML = '<p style="padding:15px; margin-bottom:0px; background:#f5f5f5; border-radius:4px; text-align:center;">Ответы отсутствуют.</p>';
}
document.getElementById('id_otvety_count').innerHTML = str[1];
}

function ping_online() {
agent.call('' ,'ping_online', 'otvet_ping_online', otvety_count);
}

function otvet_ping_online(str) {
if (str[0]!==0) {
document.getElementById('id_u_visits').innerHTML = '+'+str[0];
document.getElementById('id_u_visits').style.display = 'block';
} else {
document.getElementById('id_u_visits').innerHTML = '';
document.getElementById('id_u_visits').style.display = 'none';
}

if (str[1]!==0) {
document.getElementById('id_u_news').innerHTML = '+'+str[1];
document.getElementById('id_u_news').style.display = 'block';
} else {
document.getElementById('id_u_news').innerHTML = '';
document.getElementById('id_u_news').style.display = 'none';
}

if (str[2]!==0) {
document.getElementById('id_u_friends').innerHTML = '+'+str[2];
document.getElementById('id_u_friends').style.display = 'block';
} else {
document.getElementById('id_u_friends').innerHTML = '';
document.getElementById('id_u_friends').style.display = 'none';
}

if (str[3]!==0) {
document.getElementById('id_u_otvety').innerHTML = '+'+str[3];
document.getElementById('id_u_otvety').style.display = 'block';
} else {
document.getElementById('id_u_otvety').innerHTML = '';
document.getElementById('id_u_otvety').style.display = 'none';
}

if (otvety_count!==str[5]) {
otvety_count = str[5];
str_talker = str[6]; talker();
}

if (str[7]!==0) {
document.getElementById('id_u_dialogs').innerHTML = '+'+str[7];
document.getElementById('id_u_dialogs').style.display = 'block';
} else {
document.getElementById('id_u_dialogs').innerHTML = '';
document.getElementById('id_u_dialogs').style.display = 'none';
}

setTimeout(ping_online, 3000);
}

function visits() {
$('#id_modal_visits').modal('show');
if (document.getElementById('id_visits_more_all')) {
document.getElementById('id_visits_more_all').innerHTML = '<img src="/img/preloader.gif" />';
}
agent.call('' ,'visits', 'otvet_visits', more, page, token);
}

function otvet_visits(str) {
if (document.getElementById('id_visits_more_all')) {
document.getElementById('id_visits_more_all').parentNode.removeChild(document.getElementById('id_visits_more_all'));
}
if (str[0]!=='') {
if (more) {
document.getElementById('id_visits_peoples').innerHTML = document.getElementById('id_visits_peoples').innerHTML + str[0];
} else {
document.getElementById('id_visits_peoples').innerHTML = str[0];
}
} else {
document.getElementById('id_visits_peoples').innerHTML = '<p style="padding:15px; margin-bottom:0px; background:#f5f5f5; border-radius:4px; text-align:center;">К Вам еще никто не заходил.</p>';
}
document.getElementById('id_visits_count').innerHTML = str[1];
}