function log_in() {
l = document.getElementById('id_login').value;
p = document.getElementById('id_password').value;
if (l=='' || p=='') {
str_talker = 'Поля E-mail и пароль не должны быть пустыми.'; talker();
} else {
agent.call('' ,'login', 'otvet_login', l, p);
}
}

function otvet_login(str) {
if (str=='false') {
document.getElementById('id_login').value = '';
document.getElementById('id_password').value= '';
str_talker = 'Неверный E-mail или пароль, попробуйте авторизоваться снова, или воспользуйтесь ссылкой восстановления пароля.'; talker();
} else {
location = '/';
}
}

function talker() {
if (document.getElementsByClassName('talker')[0].style.display!=='block') {
document.getElementsByClassName('talker_message')[0].innerHTML = str_talker;
document.getElementsByClassName('talker')[0].style.display = 'block';
setTimeout(talker_close, 5000);
}
}

function talker_close() {
document.getElementsByClassName('talker')[0].style.display = 'none';
}

function closesearch() {
document.getElementById('topsearch').style.display='none';
}

function top_search() {
top_query = document.getElementById('id_top_query').value;
if (top_query!=='') {
agent.call('' ,'topsearch', 'otvet_topsearch', top_query);
} else {
document.getElementById('top_result').innerHTML = '';
document.getElementById('topsearch').style.display='none';
}
}

function otvet_topsearch(str) {
if (str!=='') {
document.getElementById('topsearch').style.display='block';
document.getElementById('top_result').innerHTML = str;
} else {
document.getElementById('topsearch').style.display='none';
}
}