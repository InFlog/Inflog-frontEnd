hash = '';
function start_register() {
live_firstname = true;
live_lastname = true;
live_sex = true;
live_day = true;
live_month = true;
live_year = true;
live_date = true;
live_email = true;
live_password_1 = true;
live_password_2 = true;
live_code = true;
firstname = document.getElementById('id_firstname').value;
lastname = document.getElementById('id_lastname').value;
sex = document.getElementById('id_sex').innerHTML;
day = document.getElementById('id_day').innerHTML;
month = document.getElementById('id_month').innerHTML;
year = document.getElementById('id_year').innerHTML;
email = document.getElementById('id_email').value;
password_1 = document.getElementById('id_password_1').value;
password_2 = document.getElementById('id_password_2').value;
code = document.getElementById('id_code').value;
sim = new RegExp("^[а-яА-ЯёЁa-zA-Z]+$"); 
eme = new RegExp("^[0-9a-zA-Z\-_\.]+@[0-9a-zA-Z\-_\.]+\.[a-zA-Z]{2,4}$");
if (sex=='Not selected') { sex = ''; }
if (day=='Not selected') { day = ''; }
if (month=='Not selected') { month = ''; }
if (year=='Not selected') { year = ''; }
p_firstname();
}

function p_firstname() {
if (firstname.length==0) {
live_firstname = false;
error_firstname = 'The name must not be empty';
} else {
if (firstname.length<2) {
live_firstname = false;
error_firstname = 'Too short a name';
} else {
if (!sim.test(firstname)) {
live_firstname = false;
error_firstname = 'Not filled in correctly the name';
}}}
if (!live_firstname) {
document.getElementById("id_firstname").title = error_firstname;
$('#id_firstname').tooltip('show');
}
p_lastname();
}

function p_lastname() {
if (lastname.length==0) {
live_lastname = false;
error_lastname = 'The name must not be empty';
} else {
if (lastname.length<2) {
live_lastname = false;
error_lastname = 'Too short name';
} else {
if (!sim.test(lastname)) {
live_lastname = false;
error_lastname = 'Not filled in correctly the name';
}}}
if (!live_lastname) {
document.getElementById("id_lastname").title = error_lastname;
$('#id_lastname').tooltip('show');
}
p_sex();
}

function p_sex() {
if (sex.length==0) {
live_sex = false;
error_sex = 'Sex not selected';
}
if (!live_sex) {
document.getElementById("id_pol").title = error_sex;
$('#id_pol').tooltip('show');
}
p_date();
}

function p_date() {
if (day.length==0) {
live_date = false;
error_date = 'Date of birth not selected';
}
if (month.length==0) {
live_date = false;
error_date = 'Date of birth not selected';
}
if (year.length==0) {
live_date = false;
error_date = 'Date of birth not selected';
}
if (!live_date) {
document.getElementById("id_firstdate").title = error_date;
$('#id_firstdate').tooltip('show');
}
p_email();
}

function p_email() {
if (email.length==0) {
live_email = false;
error_email = 'E-mail must not be empty';
} else {
if (!eme.test(email)) {
live_email = false;
error_email = 'Not true-filled E-mail';
}
}

if (!live_email) {
document.getElementById("id_email").title = error_email;
$('#id_email').tooltip('show');
p_password_1();
} else {
agent.call('' ,'live_email', 'otvet_live_email', email);
}
}

function otvet_live_email(str) {
if (str==1) {
live_email = false;
document.getElementById("id_email").title = 'This E-mail is already registered';
$('#id_email').tooltip('show');
}
p_password_1();
}

function p_password_1() {
if (password_1.length==0) {
live_password_1 = false;
error_password_1 = 'The password should not be empty';
} else {
if (password_1.length<6) {
live_password_1 = false;
error_password_1 = 'The password is too short';
} else {
if (password_1!==password_2) {
live_password_1 = false;
error_password_1 = 'The password is too short';
}}}
if (!live_password_1) {
document.getElementById("id_password_1").title = error_password_1;
$('#id_password_1').tooltip('show');
}
p_password_2();
}

function p_password_2() {
if (password_2.length==0) {
live_password_2 = false;
error_password_2 = 'The password should not be empty';
} else {
if (password_2.length<6) {
live_password_2 = false;
error_password_2 = 'The password is too short';
} else {
if (password_1!==password_2) {
live_password_2 = false;
error_password_2 = 'Passwords do not match';
}}}
if (!live_password_2) {
document.getElementById("id_password_2").title = error_password_2;
$('#id_password_2').tooltip('show');
}
p_code();
}

function p_code() {
if (code.length==0) {
live_code = false;
error_code = "You don't enter code from the image";
}
if (!live_code) {
document.getElementById("id_cap").title = error_code;
$('#id_cap').tooltip('show');
finish();
} else {
captcha = document.getElementById('id_code').value;
agent.call('' ,'live_captcha', 'otvet_live_captcha', captcha, hash);
}
}

function otvet_live_captcha(str) {
if (str==0) {
live_code = false;
document.getElementById("id_cap").title = 'Code does not match';
$('#id_cap').tooltip('show');
change_captcha();
}
finish();
}

function finish() {
if (live_firstname && live_lastname && live_sex && live_date && live_email && live_password_1 && live_password_2 && live_code) {
agent.call('' ,'register', 'otvet_register', firstname, lastname, sex, day, month, year, email, password_1, password_2, code, hash);
} else {
str_talker = 'Some fields are not filled correctly. Please go back and fill in the fields correctly.'; talker();
}
}

function change_captcha() {
agent.call('' ,'change_captcha', 'otvet_change_captcha');
}

function otvet_change_captcha(str) {
document.getElementById('id_captcha').src = '/code/captcha.png?id='+str;
hash = str;
}

change_captcha();

function otvet_register(str) {
if (str==true) {
location = '/';
} else {
str_talker = 'At the time of registration problems. Please re-register again.'; talker();
}
}

function closesearch() {
document.getElementById('topsearch').style.display='none';
}

function top_search() {
top_query = document.getElementById('id_top_query').value;
if (top_query!=='') {
agent.call('' ,'topsearch', 'otvet_topsearch', top_query);
} else {
document.getElementById('top_result').innerHTML = '';
document.getElementById('topsearch').style.display='none';
}
}

function otvet_topsearch(str) {
if (str!=='') {
document.getElementById('topsearch').style.display='block';
document.getElementById('top_result').innerHTML = str;
} else {
document.getElementById('topsearch').style.display='none';
}
}

function talker() {
if (document.getElementsByClassName('talker')[0].style.display!=='block') {
document.getElementsByClassName('talker_message')[0].innerHTML = str_talker;
document.getElementsByClassName('talker')[0].style.display = 'block';
setTimeout(talker_close, 5000);
}
}

function talker_close() {
document.getElementsByClassName('talker')[0].style.display = 'none';
}