function log_in() {
l = document.getElementById('id_login').value;
p = document.getElementById('id_password').value;
if (l=='' || p=='') {
str_talker = 'Field E-mail and password should not be empty.'; talker();
} else {
agent.call('' ,'login', 'otvet_login', l, p);
}
}

function otvet_login(str) {
if (str=='false') {
document.getElementById('id_login').value = '';
document.getElementById('id_password').value= '';
str_talker = 'Invalid E-mail or password, try to log in again or use the password recovery link.'; talker();
} else {
location = '/';
}
}

function talker() {
if (document.getElementsByClassName('talker')[0].style.display!=='block') {
document.getElementsByClassName('talker_message')[0].innerHTML = str_talker;
document.getElementsByClassName('talker')[0].style.display = 'block';
setTimeout(talker_close, 5000);
}
}

function talker_close() {
document.getElementsByClassName('talker')[0].style.display = 'none';
}

function start_city_list() {
agent.call('' ,'city_list', 'otvet_city_list', country_id);
}

function otvet_city_list(str) {
document.getElementById('id_city_list').innerHTML = str;
document.getElementById('city_block').style.display = 'block';
}

function start_search() {
if (document.getElementById('id_search_more')) { document.getElementById('id_search_more').innerHTML = '<img src="/img/preloader.gif" />'; }
query = document.getElementById('id_query').value;
country = document.getElementById('id_country').innerHTML;
if (document.getElementById('id_city')) { city = document.getElementById('id_city').innerHTML; } else { city = 'Не выбрано'; }
sex = document.getElementById('id_sex').innerHTML;
age_from = document.getElementById('id_age_from').innerHTML;
age_to = document.getElementById('id_age_to').innerHTML;
marital_status = document.getElementById('id_marital_status').innerHTML;
online_id = document.getElementById('id_online').innerHTML;
if (!more) {
document.getElementById('id_query_body').innerHTML = '<div style="text-align:center; padding:20px;"><img src="/img/preloader.gif" /></div>';
}
agent.call('' ,'search', 'otvet_search', query, country, city, sex, age_from, age_to, marital_status, online_id, page);
}

function otvet_search(str) {
if (str[0]!=='') {
if (document.getElementById('id_search_more')) { document.getElementById('id_search_more').parentNode.removeChild(document.getElementById('id_search_more')); }
if (more) {
document.getElementById('id_query_body').innerHTML = document.getElementById('id_query_body').innerHTML + str[0];
more = false;
} else {
document.getElementById('id_query_body').innerHTML = str[0];
}
} else {
document.getElementById('id_query_body').innerHTML = '<p style="padding:15px; background:#f5f5f5; border-radius:4px; text-align:center;">The search results do not exist.</p>';
}
document.getElementById('id_search_count').innerHTML = str[1];
}

function add_friend() {
agent.call('' ,'add_friend', 'otvet_add_friend', friend_id, token);
}

function otvet_add_friend(str) {
if (str[0]=='0') {
str_talker = "You can't send a request yourself."; talker();
}	
if (str[0]=='1') {
str_talker = 'User '+str[1]+' added to friends.'; talker();
}	
if (str[0]=='2') {
str_talker = 'You have already submitted a request to add to friends.'; talker();
}
if (str[0]=='3') {
str_talker = str[1]+' receive the request for adding friends.'; talker();
}
if (str[0]=='4') {
str_talker = str[1]+' is already in the list of your friends.'; talker();
}
}

function talker() {
if (document.getElementsByClassName('talker')[0].style.display!=='block') {
document.getElementsByClassName('talker_message')[0].innerHTML = str_talker;
document.getElementsByClassName('talker')[0].style.display = 'block';
setTimeout(talker_close, 5000);
}
}

function talker_close() {
document.getElementsByClassName('talker')[0].style.display = 'none';
}

function exit() {
document.cookie = "l=";
document.cookie = "p=";
location = '/';
}

function closesearch() {
document.getElementById('topsearch').style.display='none';
}

function top_search() {
top_query = document.getElementById('id_top_query').value;
if (top_query!=='') {
agent.call('' ,'topsearch', 'otvet_topsearch', top_query);
} else {
document.getElementById('top_result').innerHTML = '';
document.getElementById('topsearch').style.display='none';
}
}

function otvet_topsearch(str) {
if (str!=='') {
document.getElementById('topsearch').style.display='block';
document.getElementById('top_result').innerHTML = str;
} else {
document.getElementById('topsearch').style.display='none';
}
}

function otvety() {
if (!more) {
document.getElementById('id_body_otvety').innerHTML = '<div style="text-align:center; padding:20px;"><img src="/img/preloader.gif" /></div>';
}
$('#id_modal_otvety').modal('show');
if (document.getElementById('id_otvety_more_all')) {
document.getElementById('id_otvety_more_all').innerHTML = '<img src="/img/preloader.gif" />';
}
agent.call('' ,'otvety', 'otvet_otvety', more, page, token);
}

function otvet_otvety(str) {
if (document.getElementById('id_otvety_more_all')) {
document.getElementById('id_otvety_more_all').parentNode.removeChild(document.getElementById('id_otvety_more_all'));
}
if (str[0]!=='') {
if (more) {
document.getElementById('id_body_otvety').innerHTML = document.getElementById('id_body_otvety').innerHTML + str[0];
} else {
document.getElementById('id_body_otvety').innerHTML = str[0];
}
} else {
document.getElementById('id_body_otvety').innerHTML = '<p style="padding:15px; margin-bottom:0px; background:#f5f5f5; border-radius:4px; text-align:center;">The answers are no.</p>';
}
document.getElementById('id_otvety_count').innerHTML = str[1];
}

function ping_online() {
agent.call('' ,'ping_online', 'otvet_ping_online', otvety_count);
}

function otvet_ping_online(str) {
if (str[0]!==0) {
document.getElementById('id_u_visits').innerHTML = '+'+str[0];
document.getElementById('id_u_visits').style.display = 'block';
} else {
document.getElementById('id_u_visits').innerHTML = '';
document.getElementById('id_u_visits').style.display = 'none';
}

if (str[1]!==0) {
document.getElementById('id_u_news').innerHTML = '+'+str[1];
document.getElementById('id_u_news').style.display = 'block';
} else {
document.getElementById('id_u_news').innerHTML = '';
document.getElementById('id_u_news').style.display = 'none';
}

if (str[2]!==0) {
document.getElementById('id_u_friends').innerHTML = '+'+str[2];
document.getElementById('id_u_friends').style.display = 'block';
} else {
document.getElementById('id_u_friends').innerHTML = '';
document.getElementById('id_u_friends').style.display = 'none';
}

if (str[3]!==0) {
document.getElementById('id_u_otvety').innerHTML = '+'+str[3];
document.getElementById('id_u_otvety').style.display = 'block';
} else {
document.getElementById('id_u_otvety').innerHTML = '';
document.getElementById('id_u_otvety').style.display = 'none';
}

if (otvety_count!==str[5]) {
otvety_count = str[5];
str_talker = str[6]; talker();
}

if (str[7]!==0) {
document.getElementById('id_u_dialogs').innerHTML = '+'+str[7];
document.getElementById('id_u_dialogs').style.display = 'block';
} else {
document.getElementById('id_u_dialogs').innerHTML = '';
document.getElementById('id_u_dialogs').style.display = 'none';
}

setTimeout(ping_online, 3000);
}

function visits() {
$('#id_modal_visits').modal('show');
if (document.getElementById('id_visits_more_all')) {
document.getElementById('id_visits_more_all').innerHTML = '<img src="/img/preloader.gif" />';
}
agent.call('' ,'visits', 'otvet_visits', more, page, token);
}

function otvet_visits(str) {
if (document.getElementById('id_visits_more_all')) {
document.getElementById('id_visits_more_all').parentNode.removeChild(document.getElementById('id_visits_more_all'));
}
if (str[0]!=='') {
if (more) {
document.getElementById('id_visits_peoples').innerHTML = document.getElementById('id_visits_peoples').innerHTML + str[0];
} else {
document.getElementById('id_visits_peoples').innerHTML = str[0];
}
} else {
document.getElementById('id_visits_peoples').innerHTML = '<p style="padding:15px; margin-bottom:0px; background:#f5f5f5; border-radius:4px; text-align:center;">To You nobody came.</p>';
}
document.getElementById('id_visits_count').innerHTML = str[1];
}