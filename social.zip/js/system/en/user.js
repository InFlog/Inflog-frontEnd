function init_upload_wall() {
document.getElementById('id_upload_wall_status').innerHTML = '<form style="text-align:left;"><input id="file_wall" name="file_wall" type="file" multiple="true" style="display:none;" onChange="$(\'#file_wall\').uploadifive(\'upload\');"></form>';
arr_photos_wall = new Array();
upload_wall_id = 0;
$('#file_wall').uploadifive({
'buttonText'    : '',
'buttonClass'   : 'glyphicon icon-attachment',
'fileSizeLimit' : '10240KB',
'uploadLimit'   : 5,
'fileDesc'      : 'jpg',
'fileExt'       : '*.jpg',
'auto'             : true,
'checkScript'      : '/uploadify/check-exists.php',
'formData'         : {'token':tokens[0]},
'uploadScript'     : '/uploadify/upload_wall.php',
'onUploadComplete' : function(file, data) {
if (data) {
if (data!=='0') {
document.getElementById('upload_wall_results').style.height = '50px';
document.getElementById('upload_wall_results').innerHTML = document.getElementById('upload_wall_results').innerHTML + '<div style="position:absolute; margin-left:'+(upload_wall_id*40)+'px; margin-top:10px; width:30px; height:30px; background-image: url(\'/photo/m_'+data+'.jpg\'); background-size:cover; background-position:center top; border-radius:50px; float:left;"></div>';
arr_photos_wall[upload_wall_id] = data;
} else {
global_error();
arr_photos_wall = new Array();
init_upload_wall();
}
}
document.getElementById('uploadifive-file_wall-file-'+upload_wall_id).parentNode.removeChild(document.getElementById('uploadifive-file_wall-file-'+upload_wall_id)); 
upload_wall_id++;
},
'onUpload' : function() {
document.getElementById('uploadifive-file_wall').parentNode.removeChild(document.getElementById('uploadifive-file_wall'));
}
});
}

function send_wall() {
if (document.getElementById('id_wall').value!=='' || arr_photos_wall.length>0) {
comment_wall = document.getElementById('id_wall').value;
str_wall_photos = '';
if (arr_photos_wall.length>0) {
for (i=0; i<arr_photos_wall.length; i++) {
if (i==0) { str_wall_photos = str_wall_photos+arr_photos_wall[i]; } else { str_wall_photos = str_wall_photos+','+arr_photos_wall[i]; };
}
}
page_id = uid;
agent.call('' ,'send_wall', 'otvet_send_wall', comment_wall, page_id, str_wall_photos, token);
} else {
str_talker = 'Material must not be empty.'; talker();
}
}

function otvet_send_wall(str) {
document.getElementById('upload_wall_results').style.height = '0px';
document.getElementById('upload_wall_results').innerHTML = '';
document.getElementById('id_wall').value = '';
str_talker = 'The message sent to the wall.'; talker(); 
init_upload_wall();
page = 1;
more = false;
loadwall();
}

function loadwall() {
if (document.getElementById('id_search_more_wall')) { 
document.getElementById('id_search_more_wall').innerHTML = '<img src="/img/preloader.gif" />'; 
} else {
document.getElementById('id_wall_body').innerHTML = '<div style="text-align:center; padding:20px;"><img src="/img/preloader.gif" /></div>';
}
page_id = uid;
agent.call('' ,'load_wall', 'otvet_loadwall', page_id, page);
}

function otvet_loadwall(str) {
if (document.getElementById('id_search_more_wall')) { document.getElementById('id_search_more_wall').parentNode.removeChild(document.getElementById('id_search_more_wall')); }
if (str=='') {
document.getElementById('id_wall_body').innerHTML = '<p style="padding:15px; margin-bottom:0px; background:#f5f5f5; border-radius:4px; text-align:center;">Messages do not exist. Be the first!</p>';
} else {
if (more) {
document.getElementById('id_wall_body').innerHTML = document.getElementById('id_wall_body').innerHTML + str;
} else {
document.getElementById('id_wall_body').innerHTML = str;
}
}
}

function log_in() {
l = document.getElementById('id_login').value;
p = document.getElementById('id_password').value;
if (l=='' || p=='') {
str_talker = 'Field E-mail and password must not be empty.'; talker();
} else {
agent.call('' ,'login', 'otvet_login', l, p);
}
}

function otvet_login(str) {
if (str=='false') {
document.getElementById('id_login').value = '';
document.getElementById('id_password').value= '';
str_talker = 'Invalid E-mail or password, try to log in again or use the password recovery link.'; talker();
} else {
location = '/';
}
}


function talker() {
if (document.getElementsByClassName('talker')[0].style.display!=='block') {
document.getElementsByClassName('talker_message')[0].innerHTML = str_talker;
document.getElementsByClassName('talker')[0].style.display = 'block';
setTimeout(talker_close, 5000);
}
}

function talker_close() {
document.getElementsByClassName('talker')[0].style.display = 'none';
}

function exit() {
document.cookie = "l=";
document.cookie = "p=";
location = '/';
}


function upload_avatar() {
document.getElementById('id_upload_ava').innerHTML = '<div class="row"><div class="col-md-12" style="padding-bottom:20px;">Select an area for small photos. The selected thumbnail will be used in the news, private messages and comments.</div><div class="col-md-6"><form style="text-align:left;"><span style="position:absolute; margin-top:2px; margin-left:30px;">Add a photo</span><input id="upload_avatar" name="upload_avatar" type="file" multiple="true" onChange="$(\'#upload_avatar\').uploadifive(\'upload\');"></form></div></div>';
$(function() {
$('#upload_avatar').uploadifive({
'buttonClass'   : 'glyphicon icon-attachment',
'fileSizeLimit' : '10240KB',
'multi'         : false,
'uploadLimit'   : 1,
'fileDesc'      : 'jpg',
'fileExt'       : '*.jpg',
'auto'             : true,
'formData'         : {'token':tokens[1]},
'uploadScript'     : '/uploadify/upload_avatar.php',
'onUploadComplete' : function(file, data) {
if (data!=='0') {
finish_upload_avatar(); 
} else {
global_error();
upload_avatar();
}
}
});
});
rand = Math.floor(Math.random() * (99999 - 0 + 1)) + 0;
document.getElementById('id_preload_ava').innerHTML = '<img id="id_load_ava" width="100" height="100" src="" style="border-radius:100px;">';
document.getElementById('id_load_ava').src = document.getElementById('id_avatar').src;
$('#id_modal_avatar').modal('show');

}

function upload_error() {
str_talker = 'Wrong file format or too big size.'; talker();
init_upload_comment();
}

function finish_upload_avatar() {
rand = Math.floor(Math.random() * (99999 - 0 + 1)) + 0;
document.getElementById('id_preload_ava').innerHTML = '<div style="width:100px; height:100px; overflow:hidden; margin-left:5px; border-radius:100px; margin-left: -webkit-calc(50% - 50px); margin-left: -moz-calc(50% - 50px); margin-left: calc(50% - 50px);"><img src="/uploads/upload_'+my_id+'.jpg?'+rand+'" id="preview" /></div>';
document.getElementById('id_upload_ava').innerHTML = '<p>Select an area for small photos. The selected thumbnail will be used in the news, private messages and comments.</p><br><div id="id_size_ava"><img width="100%" src="/uploads/upload_'+my_id+'.jpg?'+rand+'" id="jcrop_target" /><br><button type="button" class="btn btn-primary" onClick="resize_avatar();" style="float:right;">Save</button></div>';
$('#jcrop_target').Jcrop({
onChange    : showPreview,
onSelect    : showPreview,
onRelease   : hidePreview,
setSelect: [20, 20, 120, 120],
minSize:[100,100],
aspectRatio: 1
});
$preview = $('#preview'); 
}


function showPreview(coords) {
if (parseInt(coords.w) > 0)
{
rx = 100 / coords.w;
ry = 100 / coords.h;  
ava_x = coords.x;
ava_y = coords.y;
ava_x2 = coords.x2;
ava_y2 = coords.y2;
ava_w = coords.w;
ava_h = coords.h;
$preview.css({
width: Math.round(rx * parseInt(document.getElementById('id_size_ava').offsetWidth)) + 'px',
height: Math.round(ry * parseInt(document.getElementById('id_size_ava').offsetHeight)) + 'px',
marginLeft: '-' + Math.round(rx * coords.x) + 'px',
marginTop: '-' + Math.round(ry * coords.y) + 'px'
}).show();
}
}

function hidePreview()
{
$preview.stop().fadeOut('fast');
}

function resize_avatar() {
img_w = parseInt(document.getElementById('id_size_ava').offsetWidth);
img_h = parseInt(document.getElementById('id_size_ava').offsetHeight);
token = tokens[8];
agent.call('' ,'resize_avatar', 'otvet_resize_avatar', ava_x, ava_y, ava_x2, ava_y2, ava_w, ava_h, img_w, img_h, token);
}

function otvet_resize_avatar() {
rand = Math.floor(Math.random() * (99999 - 0 + 1)) + 0;
document.getElementById('id_top_avatar').src = '/avatar/'+my_id+'.jpg?r='+rand;
document.getElementById('id_avatar').src = '/avatar/'+my_id+'.jpg?r='+rand;
$('#id_modal_avatar').modal('hide');
}


function status_edit() {
document.getElementById('status_body').innerHTML = '<div style="position:absolute; width:calc(100% + 12px); margin-top:-8px; margin-left:-21px; text-align:right; padding:9px; background:#eeeeee; z-index:1000; border:1px solid #dcdcdc; border-radius:3px;"><textarea id="id_status_form" maxlength="40" class="form-control input-sm" placeholder="Your status" onKeyDown="$(\'#id_cap\').tooltip(\'destroy\'); if(event.keyCode==13){start_status_edit();}" style="height:50px; margin-top:2px; border:1px solid #ccc; text-align:center; font-size:13px; line-height:1.3; resize:none;">'+document.getElementById('id_status_text').innerHTML+'</textarea><button type="button" class="btn btn-primary btn-sm" style="margin-top:10px;" onClick="start_status_edit();">Save</button></div>';
}

function start_status_edit() {
my_status = document.getElementById('id_status_form').value;
token = tokens[7];
agent.call('' ,'edit_status', 'otvet_edit_status', my_status, token);
}

function otvet_edit_status(str) {
document.getElementById('id_status_text').innerHTML = str;
document.getElementById('status_body').innerHTML = '';
}

$(document).on('ready', function() {
document.getElementById('slider_block').style.display = 'block';
$(".regular").slick({
infinite: true,
slidesToShow: 5,
slidesToScroll: 5,
});

$(function() {
if (live_uploads) {
init_upload_photo();
}
});
});

function photo_show() {
$('#id_modal_photos').modal('show');
if (count_photos<2) {
photo_id = photo_ids[photo_id];
start_photo = false;
page = 1;
more = false;
document.getElementById('id_p1').innerHTML = 1;
document.getElementById('id_p2').innerHTML = 1;
loadcomments();
$('#id_open_smiles').popover('destroy');
arr_photos_wall = new Array();
}
if (count_photos>1) {
if (show_photo) { $('#photo_slider').slick({initialSlide:1, adaptiveHeight:true, speed:0}); show_photo = false; }
$('#photo_slider').slick('slickGoTo', photo_id);
}
}

$('#photo_slider').on('beforeChange', function(event, slick, currentSlide, nextSlide){
if (count_photos>1) {
if (currentSlide!==nextSlide || start_photo) {
start_photo = false;
photo_id = photo_ids[nextSlide];
page = 1;
more = false;
loadcomments();
$('#id_open_smiles').popover('destroy');
arr_photos_wall = new Array();
document.getElementById('id_p1').innerHTML = nextSlide+1;
document.getElementById('id_p2').innerHTML = photo_ids.length;
}
}
});

function loadcomments() {
if (document.getElementById('id_search_more_comments')) { 
document.getElementById('id_search_more_comments').innerHTML = '<img src="/img/preloader.gif" />'; 
} else {
document.getElementById('id_photo_comments').innerHTML = '<div style="text-align:center; padding:20px;"><img src="/img/preloader.gif" /></div>';
}
agent.call('' ,'load_comments', 'otvet_load_comments', photo_id, page);
}

function upload_photo_error() {
if (document.getElementById('uploadifive-file_photos-queue')) {
document.getElementById('uploadifive-file_photos-queue').parentNode.removeChild(document.getElementById('uploadifive-file_photos-queue'));
init_upload_photo();
}
if (document.getElementById('uploadifive-file_comment-queue')) {
document.getElementById('uploadifive-file_comment-queue').parentNode.removeChild(document.getElementById('uploadifive-file_comment-queue'));
}
if (document.getElementById('uploadifive-file_wall-queue')) {
document.getElementById('uploadifive-file_wall-queue').parentNode.removeChild(document.getElementById('uploadifive-file_wall-queue'));
}
str_talker = 'The maximum number of uploaded images. You can upload 5 pictures at a time.'; talker();
}

function init_upload_photo() {
document.getElementById('id_upload_foto_status').innerHTML = '<form style="text-align:left;"><span style="position:absolute; margin-top:2px; margin-left:30px;">Add a photo</span><input id="file_photos" name="file_photos" type="file" multiple="true" style="display:none;" onChange="$(\'#file_photos\').uploadifive(\'upload\');"></form>';
upload_photo_id = 0;
$('#file_photos').uploadifive({
'buttonText'    : '',
'buttonClass'   : 'glyphicon icon-attachment',
'fileSizeLimit' : '10240KB',
'uploadLimit'   : 5,
'fileDesc'      : 'jpg',
'fileExt'       : '*.jpg',
'auto'             : true,
'checkScript'      : '/uploadify/check-exists.php',
'formData'         : {'token':tokens[2]},
'uploadScript'     : '/uploadify/upload_photos.php',
'onUploadComplete' : function(file, data) {
if (data!=='0') {
document.getElementById('uploadifive-file_photos-file-'+upload_photo_id).parentNode.removeChild(document.getElementById('uploadifive-file_photos-file-'+upload_photo_id)); 
arr_photos_wall[upload_photo_id] = data;
upload_photo_id++; 
if (document.getElementById('uploadifive-file_photos-queue').innerHTML=='') {
str_wall_photos = '';
if (arr_photos_wall.length>0) {
for (i=0; i<arr_photos_wall.length; i++) {
if (i==0) { str_wall_photos = str_wall_photos+arr_photos_wall[i]; } else { str_wall_photos = str_wall_photos+','+arr_photos_wall[i]; };
}
}
token = tokens[4];
send_wall();
str_talker = 'Photos uploaded.'; talker(); init_upload_photo(); 
}
} else {
global_error();
arr_photos_wall = new Array();
init_upload_photo();
}
}
});
document.getElementById('upload_photoslide').style.display = 'block';
}

function add_friend() {
agent.call('' ,'add_friend', 'otvet_add_friend', friend_id, token);
}

function otvet_add_friend(str) {
if (str[0]=='0') {
str_talker = "You can't send a request yourself."; talker();
}	
if (str[0]=='1') {
str_talker = 'User '+str[1]+' added to friends.'; talker();
}	
if (str[0]=='2') {
str_talker = 'You have already submitted a request to add to friends.'; talker();
}
if (str[0]=='3') {
str_talker = str[1]+' receive the request for adding friends.'; talker();
}
if (str[0]=='4') {
str_talker = str[1]+' is already in your friends list.'; talker();
}
}

function del_friend() {
agent.call('' ,'del_friend', 'otvet_del_friend', friend_id, token);
}

function otvet_del_friend(str) {
str_talker = str+' removed from friends.'; talker();
}

function closesearch() {
document.getElementById('topsearch').style.display='none';
}

function top_search() {
top_query = document.getElementById('id_top_query').value;
if (top_query!=='') {
agent.call('' ,'topsearch', 'otvet_topsearch', top_query);
} else {
document.getElementById('top_result').innerHTML = '';
document.getElementById('topsearch').style.display='none';
}
}

function otvet_topsearch(str) {
if (str!=='') {
document.getElementById('topsearch').style.display='block';
document.getElementById('top_result').innerHTML = str;
} else {
document.getElementById('topsearch').style.display='none';
}
}

function otvet_load_comments(str) {
if (document.getElementById('id_search_more_comments')) { document.getElementById('id_search_more_comments').parentNode.removeChild(document.getElementById('id_search_more_comments')); }
if (str=='') {
document.getElementById('id_photo_comments').innerHTML = '<p style="padding:15px; background:#f5f5f5; border-radius:4px; text-align:center;">No comment. Be the first!</p>';
} else {
if (more) {
document.getElementById('id_photo_comments').innerHTML = document.getElementById('id_photo_comments').innerHTML + str;
} else {
document.getElementById('id_photo_comments').innerHTML = str;
}
}
$('#id_open_smiles').popover();
init_upload_comment();
arr_photos_comment = new Array();
}

function send_comment() {
if (document.getElementById('id_comment').value!=='' || arr_photos_comment.length>0) {
comment = document.getElementById('id_comment').value;
str_photos_comment = '';
if (arr_photos_comment.length>0) {
for (i=0; i<arr_photos_comment.length; i++) {
if (i==0) { str_photos_comment = str_photos_comment+arr_photos_comment[i]; } else { str_photos_comment = str_photos_comment+','+arr_photos_comment[i]; };
}
}
agent.call('' ,'send_comment', 'otvet_send_comment', comment, photo_id, str_photos_comment, uid, token);
} else {
str_talker = 'Comment must not be empty.'; talker();
}
}

function otvet_send_comment() {
str_talker = 'The comment attached to the photo.'; talker(); 
document.getElementById('id_comment').value = '';
document.getElementById('id_photo_comments').innerHTML = '<div style="text-align:center; padding:20px;"><img src="/img/preloader.gif" /></div>';
page = 1;
more = false;
loadcomments();
init_upload_comment();
document.getElementById('upload_comment_results').style.height = '0px';
document.getElementById('upload_comment_results').innerHTML = '';
}

function del_comment() {
agent.call('' ,'delcomment', 'otvet_delcomment', comment_id, token);
}

function otvet_delcomment() {
if (document.getElementById('comment_'+comment_id)) { document.getElementById('comment_'+comment_id).parentNode.removeChild(document.getElementById('comment_'+comment_id)); }
str_talker = 'Comment has been deleted.'; talker();
}

function del_wall() {
agent.call('' ,'delwall', 'otvet_delwall', wall_id, token);
}

function otvet_delwall() {
if (document.getElementById('wall_'+wall_id)) { document.getElementById('wall_'+wall_id).parentNode.removeChild(document.getElementById('wall_'+wall_id)); }
str_talker = 'Message deleted.'; talker();
}

function like() {
agent.call('' ,'like', 'otvet_like', object_id, object_type, token);
}

function otvet_like(str) {
if (str[0]=='1') {
document.getElementById('like_heart_'+object_type+'_'+object_id).style.color = '#5085ad';
if (document.getElementById('like_count_'+object_type+'_'+object_id).innerHTML=='') {
document.getElementById('like_count_'+object_type+'_'+object_id).innerHTML = 1;
} else {
document.getElementById('like_count_'+object_type+'_'+object_id).innerHTML = parseInt(document.getElementById('like_count_'+object_type+'_'+object_id).innerHTML)+1;
}
document.getElementById('popover_'+object_type+'_'+object_id).style.display = 'block';
}
if (str[0]=='0') {
document.getElementById('like_heart_'+object_type+'_'+object_id).style.color = '#b4cee2';
if (document.getElementById('like_count_'+object_type+'_'+object_id).innerHTML=='1') {
document.getElementById('like_count_'+object_type+'_'+object_id).innerHTML = '';
document.getElementById('popover_'+object_type+'_'+object_id).style.display = 'none';
} else {
document.getElementById('like_count_'+object_type+'_'+object_id).innerHTML = parseInt(document.getElementById('like_count_'+object_type+'_'+object_id).innerHTML)-1;
}
}
document.getElementById('popover_'+object_type+'_'+object_id).title = str[1];
$('#popover_'+object_type+'_'+object_id).tooltip('destroy');
}

function like_peoples() {
$('#id_modal_photos').modal('hide');
$('#id_modal_likes').modal('show');
if (document.getElementById('id_likes_more_all')) {
document.getElementById('id_likes_more_all').innerHTML = '<img src="/img/preloader.gif" />';
}
agent.call('' ,'like_peoples', 'otvet_like_peoples', object_id, object_type, more, page);
}

function otvet_like_peoples(str) {
if (document.getElementById('id_likes_more_all')) {
document.getElementById('id_likes_more_all').parentNode.removeChild(document.getElementById('id_likes_more_all'));
}
if (more) {
document.getElementById('id_like_peoples').innerHTML = document.getElementById('id_like_peoples').innerHTML + str[0];
} else {
document.getElementById('id_like_peoples').innerHTML = str[0];
}
document.getElementById('id_like_count').innerHTML = str[1];
}

function visits() {
$('#id_modal_visits').modal('show');
if (document.getElementById('id_visits_more_all')) {
document.getElementById('id_visits_more_all').innerHTML = '<img src="/img/preloader.gif" />';
}
agent.call('' ,'visits', 'otvet_visits', more, page, token);
}

function otvet_visits(str) {
if (document.getElementById('id_visits_more_all')) {
document.getElementById('id_visits_more_all').parentNode.removeChild(document.getElementById('id_visits_more_all'));
}
if (str[0]!=='') {
if (more) {
document.getElementById('id_visits_peoples').innerHTML = document.getElementById('id_visits_peoples').innerHTML + str[0];
} else {
document.getElementById('id_visits_peoples').innerHTML = str[0];
}
} else {
document.getElementById('id_visits_peoples').innerHTML = '<p style="padding:15px; margin-bottom:0px; background:#f5f5f5; border-radius:4px; text-align:center;">To You still no one came.</p>';
}
document.getElementById('id_visits_count').innerHTML = str[1];
}

function add_smile() {
comment = '<smile'+smile_id+' />';
token = tokens[3];
str_photos_comment = '';
agent.call('' ,'send_comment', 'otvet_send_comment', comment, photo_id, str_photos_comment, uid, token);
$('#id_open_smiles').popover('destroy');
}

function add_smile_wall() {
comment_wall = '<smile'+smile_id+' />';
str_wall_photos = '';
page_id = uid;
token = tokens[4];
agent.call('' ,'send_wall', 'otvet_send_wall', comment_wall, page_id, str_wall_photos, token);
$('#id_open_smiles_wall').popover('destroy');
}

function init_upload_comment() {
arr_photos_comment = new Array();
document.getElementById('upload_comment_results').style.height = '0px';
document.getElementById('upload_comment_results').innerHTML = '';
document.getElementById('id_upload_comment_status').innerHTML = '<form style="text-align:left;"><input id="file_comment" name="file_comment" type="file" multiple="true" style="display:none;" onChange="$(\'#file_comment\').uploadifive(\'upload\');"></form>';
upload_photo_id = 0;
$('#file_comment').uploadifive({
'buttonText'    : '',
'buttonClass'   : 'glyphicon icon-attachment',
'fileSizeLimit' : '10240KB',
'uploadLimit'   : 5,
'fileDesc'      : 'jpg',
'fileExt'       : '*.jpg',
'auto'             : true,
'checkScript'      : '/uploadify/check-exists.php',
'formData'         : {'token':tokens[5]},
'uploadScript'     : '/uploadify/upload_comments.php',
'onUploadComplete' : function(file, data) {
if (data) {
if (data!=='0') {
document.getElementById('upload_comment_results').style.height = '50px';
document.getElementById('upload_comment_results').innerHTML = document.getElementById('upload_comment_results').innerHTML + '<div style="position:absolute; margin-left:'+(upload_photo_id*40)+'px; margin-top:10px; width:30px; height:30px; background-image: url(\'/photo/m_'+data+'.jpg\'); background-size:cover; background-position:center top; border-radius:50px; float:left;"></div>';
arr_photos_comment[upload_photo_id] = data;
} else {
global_error();
arr_photos_comment = new Array();
init_upload_comment();
}
}
document.getElementById('uploadifive-file_comment-file-'+upload_photo_id).parentNode.removeChild(document.getElementById('uploadifive-file_comment-file-'+upload_photo_id)); 
upload_photo_id++;
},
'onUpload' : function() {
document.getElementById('uploadifive-file_comment').parentNode.removeChild(document.getElementById('uploadifive-file_comment'));
}
});
}

function comment_photo_show() {
if (photo_type==1) {
scroll_comments = $('#id_modal_photos').scrollTop();
}
$('#id_modal_photos').modal('hide');
$('#id_comment_photo').modal('show');
document.getElementById('id_comment_photo_body').innerHTML = '<div style="text-align:center; padding:20px;"><img src="/img/preloader.gif" /></div>';
agent.call('' ,'load_photo', 'otvet_load_photo', photo_name);
}

function otvet_load_photo(str) {
document.getElementById('id_comment_photo_body').innerHTML = str;
}

$('#id_comment_photo').on('hidden.bs.modal', function (e) {
$('#id_comment_photo').modal('hide');
if (photo_type==1) {
$('#id_modal_photos').modal('show');
document.getElementById('id_modal_photos').scrollTop = scroll_comments;
}
})

function del_photo() {
agent.call('' ,'del_photo', 'otvet_del_photo', photo_id, uid, token);
}

function otvet_del_photo(str) {
$('#id_modal_photos').modal('hide');
str_talker = 'Photo removed.'; talker();
}

function save_photo() {
agent.call('' ,'save_photo', 'otvet_save_photo', photo_id, uid, token);
}

function otvet_save_photo(str) {
str_talker = 'The picture has been saved to Your wall.'; talker();
}

function global_error() {
str_talker = 'An error occurred.'; talker();
}

function del_avatar() {
token = tokens[6];
agent.call('' ,'del_avatar', 'otvet_del_avatar', token);
}

function otvet_del_avatar() {
rand = Math.floor(Math.random() * (99999 - 0 + 1)) + 0;
document.getElementById('id_load_ava').src = '/img/no_photo/'+sex_name+'.png?r='+rand;
document.getElementById('id_avatar').src = '/img/no_photo/'+sex_name+'.png?r='+rand;
document.getElementById('id_top_avatar').src = '/img/no_photo/'+sex_name+'.png?r='+rand;
str_talker = 'Your avatar is removed.'; talker();
}

function otvety() {
if (!more) {
document.getElementById('id_body_otvety').innerHTML = '<div style="text-align:center; padding:20px;"><img src="/img/preloader.gif" /></div>';
}
$('#id_modal_otvety').modal('show');
if (document.getElementById('id_otvety_more_all')) {
document.getElementById('id_otvety_more_all').innerHTML = '<img src="/img/preloader.gif" />';
}
agent.call('' ,'otvety', 'otvet_otvety', more, page, token);
}

function otvet_otvety(str) {
if (document.getElementById('id_otvety_more_all')) {
document.getElementById('id_otvety_more_all').parentNode.removeChild(document.getElementById('id_otvety_more_all'));
}
if (str[0]!=='') {
if (more) {
document.getElementById('id_body_otvety').innerHTML = document.getElementById('id_body_otvety').innerHTML + str[0];
} else {
document.getElementById('id_body_otvety').innerHTML = str[0];
}
} else {
document.getElementById('id_body_otvety').innerHTML = '<p style="padding:15px; margin-bottom:0px; background:#f5f5f5; border-radius:4px; text-align:center;">The answers are no.</p>';
}
document.getElementById('id_otvety_count').innerHTML = str[1];
}

function ping_online() {
agent.call('' ,'ping_online', 'otvet_ping_online', otvety_count);
}

function otvet_ping_online(str) {
if (str[0]!==0) {
document.getElementById('id_u_visits').innerHTML = '+'+str[0];
document.getElementById('id_u_visits').style.display = 'block';
} else {
document.getElementById('id_u_visits').innerHTML = '';
document.getElementById('id_u_visits').style.display = 'none';
}

if (str[1]!==0) {
document.getElementById('id_u_news').innerHTML = '+'+str[1];
document.getElementById('id_u_news').style.display = 'block';
} else {
document.getElementById('id_u_news').innerHTML = '';
document.getElementById('id_u_news').style.display = 'none';
}

if (str[2]!==0) {
document.getElementById('id_u_friends').innerHTML = '+'+str[2];
document.getElementById('id_u_friends').style.display = 'block';
} else {
document.getElementById('id_u_friends').innerHTML = '';
document.getElementById('id_u_friends').style.display = 'none';
}

if (str[3]!==0) {
document.getElementById('id_u_otvety').innerHTML = '+'+str[3];
document.getElementById('id_u_otvety').style.display = 'block';
} else {
document.getElementById('id_u_otvety').innerHTML = '';
document.getElementById('id_u_otvety').style.display = 'none';
}

if (otvety_count!==str[5]) {
otvety_count = str[5];
str_talker = str[6]; talker();
}

if (str[7]!==0) {
document.getElementById('id_u_dialogs').innerHTML = '+'+str[7];
document.getElementById('id_u_dialogs').style.display = 'block';
} else {
document.getElementById('id_u_dialogs').innerHTML = '';
document.getElementById('id_u_dialogs').style.display = 'none';
}

setTimeout(ping_online, 3000);
}