uid = 0;
function log_in() {
l = document.getElementById('id_login').value;
p = document.getElementById('id_password').value;
if (l=='' || p=='') {
str_talker = 'Field E-mail and password should not be empty.'; talker();
} else {
agent.call('' ,'login', 'otvet_login', l, p);
}
}

function otvet_login(str) {
if (str=='false') {
document.getElementById('id_login').value = '';
document.getElementById('id_password').value= '';
str_talker = 'Invalid E-mail or password, try to log in again or use the password recovery link.'; talker();
} else {
location = '/';
}
}

function talker() {
if (document.getElementsByClassName('talker')[0].style.display!=='block') {
document.getElementsByClassName('talker_message')[0].innerHTML = str_talker;
document.getElementsByClassName('talker')[0].style.display = 'block';
setTimeout(talker_close, 5000);
}
}

function talker_close() {
document.getElementsByClassName('talker')[0].style.display = 'none';
}

function exit() {
document.cookie = "l=";
document.cookie = "p=";
location = '/';
}

function closesearch() {
document.getElementById('topsearch').style.display='none';
}

function top_search() {
top_query = document.getElementById('id_top_query').value;
if (top_query!=='') {
agent.call('' ,'topsearch', 'otvet_topsearch', top_query);
} else {
document.getElementById('top_result').innerHTML = '';
document.getElementById('topsearch').style.display='none';
}
}

function otvet_topsearch(str) {
if (str!=='') {
document.getElementById('topsearch').style.display='block';
document.getElementById('top_result').innerHTML = str;
} else {
document.getElementById('topsearch').style.display='none';
}
}

function start_recovery() {
email = document.getElementById('id_email').value;
if (email=='') {
str_talker = 'The E-mail field must not be empty.'; talker();
} else {
agent.call('' ,'recovery', 'otvet_recoverys', email);
}
}

function otvet_recoverys(str) {
if (str=='0') {
document.getElementById('id_email').value = '';
str_talker = 'This E-mail is not registered on the site.'; talker();
} else {
uid = str;
document.getElementById('id_form').innerHTML = '<div class="header-title-bg">Password recovery</div><div class="form-group" style="margin-top:40px;"><label>A code of letters</label><input id="id_password_recovery" placeholder="A code of letters" class="form-control" value=""></div><div class="row" style="margin-top:5px;"><div class="col-md-12"><div class="form-group" style="text-align:right;"><button type="button" class="btn btn-primary" onClick="start_recovery_login();">Log in</button></div></div></div>';
str_talker = 'To the specified E-mail message was sent with the code. Paste the code in the box.'; talker();
}
}

function start_recovery_login() {
recovery_password = document.getElementById('id_password_recovery').value;
if (recovery_password=='') {
str_talker = 'The field must not be empty.'; talker();
} else {
agent.call('' ,'recovery_login', 'otvet_recovery_login', uid, recovery_password);
}
}

function otvet_recovery_login(str) {
if (str=='0') {
str_talker = 'Not the correct code from the letter.'; talker();
} else {
location = '/id'+str;
}
}