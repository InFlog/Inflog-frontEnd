function ping() {
if (live_load) {
talk_id = uid;
token = tokens[2];
agent.call('' ,'ping', 'otvet_ping', last_messages_id, talk_id, live_key, token);
} else {
live_send = true;
live_key = false;
setTimeout(ping, 1000);
}
}

function otvet_ping(str) {
if (live_load) {
if (str[3]!=='0') {
if (!document.getElementById('id_pencil')) {
document.getElementById('id_pencil_body').innerHTML = '<span id="id_pencil" class="icon-pencil" style="position:absolute; margin-top:19px; margin-left:6px; font-size:19px; color:#5cb85c; display:block; opacity:0.5;"></span>'; 
pencil_1();
}
} else {
document.getElementById('id_pencil_body').innerHTML = ''; 
}
if (str[0]!=='') {
if (document.getElementById('id_no_messages')) { document.getElementById('id_no_messages').parentNode.removeChild(document.getElementById('id_no_messages')); }
document.getElementById('id_messages_body').innerHTML = document.getElementById('id_messages_body').innerHTML + str[0];
document.getElementById('id_message_scroll').scrollTop = document.getElementById('id_messages_body').clientHeight;
if (document.getElementById('id_pencil')) {
document.getElementById('id_pencil_body').innerHTML = '';
}
}
if (str[2]=='1') {
document.getElementById('id_online_1').innerHTML = '<span class="icon-lamp" style="color:#46af48; font-size:10px;"></span>';
document.getElementById('id_online_2').innerHTML = '<span class="icon-lamp" style="color:#46af48; font-size:10px;"></span>';
} else {
document.getElementById('id_online_1').innerHTML = '';
document.getElementById('id_online_2').innerHTML = '';
}
last_messages_id = str[1];
live_send = true;
live_key = false;
setTimeout(ping, 3000);
} else {
live_send = true;
live_key = false;
setTimeout(ping, 3000);
}
}

function pencil_1() {
if (document.getElementById('id_pencil')) {
document.getElementById('id_pencil').style.opacity = 0.5;
setTimeout(pencil_2, 500);
}
}

function pencil_2() {
if (document.getElementById('id_pencil')) {
document.getElementById('id_pencil').style.opacity = 1;
setTimeout(pencil_1, 500);
}
}

function otvet_ping_read(str) {
if (document.getElementById('id_messages_preloader')) { document.getElementById('id_messages_preloader').parentNode.removeChild(document.getElementById('id_messages_preloader')); }
if (str[0]!=='') {
if (document.getElementById('id_no_messages')) { document.getElementById('id_no_messages').parentNode.removeChild(document.getElementById('id_no_messages')); }
document.getElementById('id_messages_body').innerHTML = document.getElementById('id_messages_body').innerHTML + str[0];
}
last_messages_id = str[1];
live_send = true;
live_load = true;
}

function talker() {
if (document.getElementsByClassName('talker')[0].style.display!=='block') {
document.getElementsByClassName('talker_message')[0].innerHTML = str_talker;
document.getElementsByClassName('talker')[0].style.display = 'block';
setTimeout(talker_close, 5000);
}
}

function talker_close() {
document.getElementsByClassName('talker')[0].style.display = 'none';
}

function exit() {
document.cookie = "l=";
document.cookie = "p=";
location = '/';
}

function closesearch() {
document.getElementById('topsearch').style.display='none';
}

function top_search() {
top_query = document.getElementById('id_top_query').value;
if (top_query!=='') {
agent.call('' ,'topsearch', 'otvet_topsearch', top_query);
} else {
document.getElementById('top_result').innerHTML = '';
document.getElementById('topsearch').style.display='none';
}
}

function otvet_topsearch(str) {
if (str!=='') {
document.getElementById('topsearch').style.display='block';
document.getElementById('top_result').innerHTML = str;
} else {
document.getElementById('topsearch').style.display='none';
}
}


function init_upload_messages() {
arr_photos_messages = new Array();
document.getElementById('id_upload_messages_status').innerHTML = '<form style="text-align:left;"><input id="file_messages" name="file_messages" type="file" multiple="true" style="display:none;" onChange="$(\'#file_messages\').uploadifive(\'upload\');"></form>';
upload_messages_id = 0;
$('#file_messages').uploadifive({
'buttonText'    : '',
'buttonClass'   : 'glyphicon icon-attachment',
'fileSizeLimit' : '10240KB',
'uploadLimit'   : 5,
'fileDesc'      : 'jpg',
'fileExt'       : '*.jpg',
'auto'             : true,
'checkScript'      : '/uploadify/check-exists.php',
'formData'         : {'token':tokens[0]},
'uploadScript'     : '/uploadify/upload_messages.php',
'onUploadComplete' : function(file, data) {
if (data) {
if (data!=='0') {
document.getElementById('upload_messages_results').style.height = '50px';
document.getElementById('upload_messages_results').innerHTML = document.getElementById('upload_messages_results').innerHTML + '<div style="position:absolute; margin-left:'+(upload_messages_id*40)+'px; margin-top:10px; width:30px; height:30px; background-image: url(\'/photo/m_'+data+'.jpg\'); background-size:cover; background-position:center top; border-radius:50px; float:left;"></div>';
arr_photos_messages[upload_messages_id] = data;
} else {
global_error();
arr_photos_messages = new Array();
init_upload_messages();
}
}
document.getElementById('uploadifive-file_messages-file-'+upload_messages_id).parentNode.removeChild(document.getElementById('uploadifive-file_messages-file-'+upload_messages_id)); 
upload_messages_id++;
},
'onUpload' : function() {
document.getElementById('uploadifive-file_messages').parentNode.removeChild(document.getElementById('uploadifive-file_messages'));
}
});
}

function upload_photo_error() {
if (document.getElementById('uploadifive-file_messages-queue')) {
document.getElementById('uploadifive-file_messages-queue').parentNode.removeChild(document.getElementById('uploadifive-file_messages-queue'));
}
str_talker = 'The maximum number of uploaded images. You can upload 5 pictures at a time.'; talker();
}


function load_message() {
height_body_messages = document.getElementById('id_messages_body').clientHeight;
if (document.getElementById('id_more_message')) { 
document.getElementById('id_more_message').innerHTML = '<img src="/img/preloader.gif" />'; 
} else {
document.getElementById('id_messages_body').innerHTML = '<div style="text-align:center; padding:20px;"><img src="/img/preloader.gif" /></div>';
}
token = tokens[4];
agent.call('' ,'load_message', 'otvet_load_message', page, more, uid, token);
}

function otvet_load_message(str) {
if (document.getElementById('id_more_message')) { document.getElementById('id_more_message').parentNode.removeChild(document.getElementById('id_more_message')); }
if (str[0]=='') {
document.getElementById('id_messages_body').innerHTML = '<p id="id_no_messages" style="padding:15px; margin-bottom:0px; background:#f5f5f5; border-radius:4px; text-align:center;">No message.</p>';
} else {
if (more) {
document.getElementById('id_messages_body').innerHTML = str[0] + document.getElementById('id_messages_body').innerHTML;
} else {
document.getElementById('id_messages_body').innerHTML = str[0];
}
}
new_height_body_messages = document.getElementById('id_messages_body').clientHeight;
document.getElementById('id_message_scroll').scrollTop = new_height_body_messages - height_body_messages;

if (live_ping) {
last_messages_id = str[1];
ping();
live_ping = false;
}
}

function send_messages() {
if (live_send) {
if (document.getElementById('id_messages').value!=='' || arr_photos_messages.length>0) {
message = document.getElementById('id_messages').value;
document.getElementById('id_messages').value = '';
str_messages_photos = '';
if (arr_photos_messages.length>0) {
for (i=0; i<arr_photos_messages.length; i++) {
if (i==0) { str_messages_photos = str_messages_photos+arr_photos_messages[i]; } else { str_messages_photos = str_messages_photos+','+arr_photos_messages[i]; };
}
}
talk_id = uid;
live_load = false;
agent.call('' ,'send_messages', 'otvet_send_messages', message, str_messages_photos, talk_id, token);
live_send = false;
} else {
str_talker = 'The message must not be empty.'; talker();
}
}
}

function otvet_send_messages() {
document.getElementById('id_messages').value = '';
document.getElementById('id_messages_body').innerHTML = document.getElementById('id_messages_body').innerHTML + '<div id="id_messages_preloader" style="text-align:center; padding:5px;"><img src="/img/preloader.gif" /></div>';;
document.getElementById('id_message_scroll').scrollTop = document.getElementById('id_messages_body').clientHeight;
document.getElementById('upload_messages_results').style.height = '0px';
document.getElementById('upload_messages_results').innerHTML = '';
init_upload_messages();

talk_id = uid;
token = tokens[2];
agent.call('' ,'ping', 'otvet_ping_read', last_messages_id, talk_id, live_key, token);
} 

function message_photo_show() {
$('#id_comment_photo').modal('show');
document.getElementById('id_comment_photo_body').innerHTML = '<div style="text-align:center; padding:20px;"><img src="/img/preloader.gif" /></div>';
agent.call('' ,'load_photo', 'otvet_load_photo', photo_name);
}

function otvet_load_photo(str) {
document.getElementById('id_comment_photo_body').innerHTML = '<div style="text-align:center; padding:20px;"><img src="/img/preloader.gif" /></div>';
document.getElementById('id_comment_photo_body').innerHTML = str;
}

function like() {
agent.call('' ,'like', 'otvet_like', object_id, object_type, token);
}

function otvet_like(str) {
if (str[0]=='1') {
document.getElementById('like_heart_'+object_type+'_'+object_id).style.color = '#5085ad';
if (document.getElementById('like_count_'+object_type+'_'+object_id).innerHTML=='') {
document.getElementById('like_count_'+object_type+'_'+object_id).innerHTML = 1;
} else {
document.getElementById('like_count_'+object_type+'_'+object_id).innerHTML = parseInt(document.getElementById('like_count_'+object_type+'_'+object_id).innerHTML)+1;
}
document.getElementById('popover_'+object_type+'_'+object_id).style.display = 'block';
}
if (str[0]=='0') {
document.getElementById('like_heart_'+object_type+'_'+object_id).style.color = '#b4cee2';
if (document.getElementById('like_count_'+object_type+'_'+object_id).innerHTML=='1') {
document.getElementById('like_count_'+object_type+'_'+object_id).innerHTML = '';
document.getElementById('popover_'+object_type+'_'+object_id).style.display = 'none';
} else {
document.getElementById('like_count_'+object_type+'_'+object_id).innerHTML = parseInt(document.getElementById('like_count_'+object_type+'_'+object_id).innerHTML)-1;
}
}
document.getElementById('popover_'+object_type+'_'+object_id).title = str[1];
$('#popover_'+object_type+'_'+object_id).tooltip('destroy');
}

function add_smile_messages() {
message = '<smile'+smile_id+' />';
str_messages_photos = '';
talk_id = uid;
token = tokens[3];
agent.call('' ,'send_messages', 'otvet_send_messages', message, str_messages_photos, talk_id, token);
$('#id_open_smiles_messages').popover('destroy');
}

function load_dialogs() {
if (document.getElementById('id_dialogs_more')) { 
document.getElementById('id_dialogs_more').innerHTML = '<img src="/img/preloader.gif" />'; 
} else {
document.getElementById('id_dialogs').innerHTML = '<div style="text-align:center; padding:20px;"><img src="/img/preloader.gif" /></div>';
}
token = tokens[0];
agent.call('' ,'load_dialogs', 'otvet_load_dialogs', page, dialogs_type, token);
}

function otvet_load_dialogs(str) {
if (document.getElementById('id_dialogs_more')) { document.getElementById('id_dialogs_more').parentNode.removeChild(document.getElementById('id_dialogs_more')); }
if (str[0]=='') {
document.getElementById('id_dialogs').innerHTML = '<p style="padding:15px; margin-bottom:0px; background:#f5f5f5; border-radius:4px; text-align:center; margin-top:68px; margin-left:20px; margin-right:20px;">Dialogues are missing.</p>';
} else {
if (more) {
document.getElementById('id_dialogs').innerHTML = document.getElementById('id_dialogs').innerHTML + str[0];
} else {
document.getElementById('id_dialogs').innerHTML = str[0];
}
}
document.getElementById('id_count_dialogs').innerHTML = str[1];
}

function global_error() {
str_talker = 'An error occurred.'; talker();
}

function otvety() {
if (!more) {
document.getElementById('id_body_otvety').innerHTML = '<div style="text-align:center; padding:20px;"><img src="/img/preloader.gif" /></div>';
}
$('#id_modal_otvety').modal('show');
if (document.getElementById('id_otvety_more_all')) {
document.getElementById('id_otvety_more_all').innerHTML = '<img src="/img/preloader.gif" />';
}
agent.call('' ,'otvety', 'otvet_otvety', more, page, token);
}

function otvet_otvety(str) {
if (document.getElementById('id_otvety_more_all')) {
document.getElementById('id_otvety_more_all').parentNode.removeChild(document.getElementById('id_otvety_more_all'));
}
if (str[0]!=='') {
if (more) {
document.getElementById('id_body_otvety').innerHTML = document.getElementById('id_body_otvety').innerHTML + str[0];
} else {
document.getElementById('id_body_otvety').innerHTML = str[0];
}
} else {
document.getElementById('id_body_otvety').innerHTML = '<p style="padding:15px; margin-bottom:0px; background:#f5f5f5; border-radius:4px; text-align:center;">The answers are no.</p>';
}
document.getElementById('id_otvety_count').innerHTML = str[1];
}

function ping_online() {
agent.call('' ,'ping_online', 'otvet_ping_online', otvety_count);
}

function otvet_ping_online(str) {
if (str[0]!==0) {
document.getElementById('id_u_visits').innerHTML = '+'+str[0];
document.getElementById('id_u_visits').style.display = 'block';
} else {
document.getElementById('id_u_visits').innerHTML = '';
document.getElementById('id_u_visits').style.display = 'none';
}

if (str[1]!==0) {
document.getElementById('id_u_news').innerHTML = '+'+str[1];
document.getElementById('id_u_news').style.display = 'block';
} else {
document.getElementById('id_u_news').innerHTML = '';
document.getElementById('id_u_news').style.display = 'none';
}

if (str[2]!==0) {
document.getElementById('id_u_friends').innerHTML = '+'+str[2];
document.getElementById('id_u_friends').style.display = 'block';
} else {
document.getElementById('id_u_friends').innerHTML = '';
document.getElementById('id_u_friends').style.display = 'none';
}

if (str[3]!==0) {
document.getElementById('id_u_otvety').innerHTML = '+'+str[3];
document.getElementById('id_u_otvety').style.display = 'block';
} else {
document.getElementById('id_u_otvety').innerHTML = '';
document.getElementById('id_u_otvety').style.display = 'none';
}

if (otvety_count!==str[5]) {
otvety_count = str[5];
str_talker = str[6]; talker();
}

if (str[7]!==0) {
document.getElementById('id_u_dialogs').innerHTML = '+'+str[7];
document.getElementById('id_u_dialogs').style.display = 'block';
} else {
document.getElementById('id_u_dialogs').innerHTML = '';
document.getElementById('id_u_dialogs').style.display = 'none';
}

setTimeout(ping_online, 3000);
}

function visits() {
$('#id_modal_visits').modal('show');
if (document.getElementById('id_visits_more_all')) {
document.getElementById('id_visits_more_all').innerHTML = '<img src="/img/preloader.gif" />';
}
agent.call('' ,'visits', 'otvet_visits', more, page, token);
}

function otvet_visits(str) {
if (document.getElementById('id_visits_more_all')) {
document.getElementById('id_visits_more_all').parentNode.removeChild(document.getElementById('id_visits_more_all'));
}
if (str[0]!=='') {
if (more) {
document.getElementById('id_visits_peoples').innerHTML = document.getElementById('id_visits_peoples').innerHTML + str[0];
} else {
document.getElementById('id_visits_peoples').innerHTML = str[0];
}
} else {
document.getElementById('id_visits_peoples').innerHTML = '<p style="padding:15px; margin-bottom:0px; background:#f5f5f5; border-radius:4px; text-align:center;">To You nobody came.</p>';
}
document.getElementById('id_visits_count').innerHTML = str[1];
}