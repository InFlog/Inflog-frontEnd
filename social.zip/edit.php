<?php
include $_SERVER['DOCUMENT_ROOT'].'/inc/config.php';
include $_SERVER['DOCUMENT_ROOT'].'/inc/login.php';
if ($my_id) {
    include $_SERVER['DOCUMENT_ROOT'].'/inc/sql_social.php';

    $z_my_info = mysql_query("SELECT * FROM users WHERE id='$my_id'");
    $o_my_info = mysql_fetch_array($z_my_info);
    $my_firstname = $o_my_info['firstname'];
    $my_lastname = $o_my_info['lastname'];
    $my_sex = $o_my_info['sex'];
    if ($my_sex==1) { $my_sex_value = $lang[194]; }
    if ($my_sex==2) { $my_sex_value = $lang[195]; }
    $my_day = $o_my_info['day'];
    $my_month = $o_my_info['month'];
    if ($my_month==1) { $my_month_value = $lang[196]; }
    if ($my_month==2) { $my_month_value = $lang[197]; }
    if ($my_month==3) { $my_month_value = $lang[198]; }
    if ($my_month==4) { $my_month_value = $lang[199]; }
    if ($my_month==5) { $my_month_value = $lang[200]; }
    if ($my_month==6) { $my_month_value = $lang[201]; }
    if ($my_month==7) { $my_month_value = $lang[202]; }
    if ($my_month==8) { $my_month_value = $lang[203]; }
    if ($my_month==9) { $my_month_value = $lang[204]; }
    if ($my_month==10) { $my_month_value = $lang[205]; }
    if ($my_month==11) { $my_month_value = $lang[206]; }
    if ($my_month==12) { $my_month_value = $lang[207]; }
    $my_year = $o_my_info['year'];
    $my_country_id = $o_my_info['country'];
    $my_city_id = $o_my_info['city'];

    if ($my_country_id!=='0') {
    $z_country_name = mysql_query("SELECT * FROM net_country WHERE id='$my_country_id'");
    $o_country_name = mysql_fetch_array($z_country_name);
    $my_country_name = $o_country_name['name_'.$js_lang];
    } else {
    $my_country_name = $lang[208];
    }

    if ($my_city_id!=='0') {
    $z_city_name = mysql_query("SELECT * FROM net_city WHERE id='$my_city_id'");
    $o_city_name = mysql_fetch_array($z_city_name);
    $my_city_name = $o_city_name['name_'.$js_lang];
    } else {
    $my_city_name = $lang[209];
    }

    $country_list = '<li><a onClick="document.getElementById(\'id_country\').innerHTML=this.innerHTML; document.getElementById(\'id_city\').innerHTML=\''.$lang[210].'\'; $(\'#id_toolcountry\').tooltip(\'destroy\'); document.getElementById(\'city_block\').style.display=\'none\';">'.$lang[211].'</a></li>';
    $result = mysql_query("SELECT * FROM net_country ORDER BY name_$js_lang ASC"); 
    while ( $myrow = mysql_fetch_array($result) )
    {
    $country_list = $country_list.'<li><a onClick="document.getElementById(\'id_country\').innerHTML=this.innerHTML; document.getElementById(\'id_city\').innerHTML=\''.$lang[212].'\'; $(\'#id_toolcountry\').tooltip(\'destroy\'); country_id=\''.$myrow['id'].'\'; start_city_list();">'.$myrow['name_'.$js_lang].'</a></li>
    ';
    }
    $my_phone = $o_my_info['phone'];
    $my_mail = $o_my_info['mail'];
    $my_skype = $o_my_info['skype'];
    $my_site = $o_my_info['site'];
    $my_activity = $o_my_info['activity'];
    $my_interests = $o_my_info['interests'];
    $my_music = $o_my_info['music'];
    $my_movies = $o_my_info['movies'];
    $my_tv = $o_my_info['tv'];
    $my_books = $o_my_info['books'];
    $my_games = $o_my_info['games'];
    $my_quotations = $o_my_info['quotations'];
    $my_about = $o_my_info['about'];
    $my_institut = $o_my_info['institut'];
    $my_department = $o_my_info['department'];
    $my_start_training = $o_my_info['start_training'];
    if ($my_start_training==0) { $my_start_training = $lang[213]; }
    $my_finish_training = $o_my_info['finish_training'];
    if ($my_finish_training==0) { $my_finish_training = $lang[214]; }
    $my_education_info = $o_my_info['education_info'];
    $my_place_work = $o_my_info['place_work'];
    $my_position = $o_my_info['position'];
    $my_work_info = $o_my_info['work_info'];
    $my_policy = $o_my_info['policy'];
    $my_world_view = $o_my_info['world_view'];
    $my_important_live = $o_my_info['important_live'];
    $my_important_peoples = $o_my_info['important_peoples'];
    $my_smoking = $o_my_info['smoking'];
    $my_alcohol = $o_my_info['alcohol'];
    $my_inspirations = $o_my_info['inspirations'];
    $my_marital_status = $o_my_info['marital_status'];

    if ($my_marital_status==0) { $my_marital_status_value = $lang[215]; }
    if ($my_marital_status==1) { $my_marital_status_value = $lang[216]; }
    if ($my_marital_status==2) { $my_marital_status_value = $lang[217]; }
    if ($my_marital_status==3) { $my_marital_status_value = $lang[218]; }
    if ($my_marital_status==4) { $my_marital_status_value = $lang[219]; }
    if ($my_marital_status==5) { $my_marital_status_value = $lang[220]; }
    if ($my_marital_status==6) { $my_marital_status_value = $lang[221]; }
    if ($my_marital_status==7) { $my_marital_status_value = $lang[222]; }

    if ($my_policy==0) { $my_policy_value = $lang[223]; }
    if ($my_policy==1) { $my_policy_value = $lang[224]; }
    if ($my_policy==2) { $my_policy_value = $lang[225]; }
    if ($my_policy==3) { $my_policy_value = $lang[226]; }
    if ($my_policy==4) { $my_policy_value = $lang[227]; }
    if ($my_policy==5) { $my_policy_value = $lang[228]; }
    if ($my_policy==6) { $my_policy_value = $lang[229]; }
    if ($my_policy==7) { $my_policy_value = $lang[230]; }
    if ($my_policy==8) { $my_policy_value = $lang[231]; }

    if ($my_world_view==0) { $my_world_view_value = $lang[232]; }
    if ($my_world_view==1) { $my_world_view_value = $lang[233]; }
    if ($my_world_view==2) { $my_world_view_value = $lang[234]; }
    if ($my_world_view==3) { $my_world_view_value = $lang[235]; }
    if ($my_world_view==4) { $my_world_view_value = $lang[236]; }
    if ($my_world_view==5) { $my_world_view_value = $lang[237]; }
    if ($my_world_view==6) { $my_world_view_value = $lang[238]; }
    if ($my_world_view==7) { $my_world_view_value = $lang[239]; }
    if ($my_world_view==8) { $my_world_view_value = $lang[240]; }
    if ($my_world_view==9) { $my_world_view_value = $lang[241]; }

    if ($my_important_live==0) { $my_important_live_value = $lang[242]; }
    if ($my_important_live==1) { $my_important_live_value = $lang[243]; }
    if ($my_important_live==2) { $my_important_live_value = $lang[244]; }
    if ($my_important_live==3) { $my_important_live_value = $lang[245]; }
    if ($my_important_live==4) { $my_important_live_value = $lang[246]; }
    if ($my_important_live==5) { $my_important_live_value = $lang[247]; }
    if ($my_important_live==6) { $my_important_live_value = $lang[248]; }
    if ($my_important_live==7) { $my_important_live_value = $lang[249]; }
    if ($my_important_live==8) { $my_important_live_value = $lang[250]; }

    if ($my_important_peoples==0) { $my_important_peoples_value = $lang[251]; }
    if ($my_important_peoples==1) { $my_important_peoples_value = $lang[252]; }
    if ($my_important_peoples==2) { $my_important_peoples_value = $lang[253]; }
    if ($my_important_peoples==3) { $my_important_peoples_value = $lang[254]; }
    if ($my_important_peoples==4) { $my_important_peoples_value = $lang[255]; }
    if ($my_important_peoples==5) { $my_important_peoples_value = $lang[256]; }
    if ($my_important_peoples==6) { $my_important_peoples_value = $lang[257]; }

    if ($my_smoking==0) { $my_smoking_value = $lang[258]; }
    if ($my_smoking==1) { $my_smoking_value = $lang[259]; }
    if ($my_smoking==2) { $my_smoking_value = $lang[260]; }
    if ($my_smoking==3) { $my_smoking_value = $lang[261]; }
    if ($my_smoking==4) { $my_smoking_value = $lang[262]; }
    if ($my_smoking==5) { $my_smoking_value = $lang[263]; }

    if ($my_alcohol==0) { $my_alcohol_value = $lang[264]; }
    if ($my_alcohol==1) { $my_alcohol_value = $lang[265]; }
    if ($my_alcohol==2) { $my_alcohol_value = $lang[266]; }
    if ($my_alcohol==3) { $my_alcohol_value = $lang[267]; }
    if ($my_alcohol==4) { $my_alcohol_value = $lang[268]; }
    if ($my_alcohol==5) { $my_alcohol_value = $lang[269]; }
    
    $z_count_otvety = mysql_query("SELECT * FROM news WHERE user_to='$my_id'");
    $count_otvety = mysql_num_rows($z_count_otvety);

    mysql_close($msconnect);
    $global_rand = rand(100000, 999999);
    $title = $lang[270];
} else {
    header('Location: /'.$link[3]);
}
?>
<?php
include $_SERVER['DOCUMENT_ROOT'].'/functions/top_search.php';
include $_SERVER['DOCUMENT_ROOT'].'/functions/city_list.php';
include $_SERVER['DOCUMENT_ROOT'].'/functions/edit_main.php';
include $_SERVER['DOCUMENT_ROOT'].'/functions/edit_contacts.php';
include $_SERVER['DOCUMENT_ROOT'].'/functions/edit_interests.php';
include $_SERVER['DOCUMENT_ROOT'].'/functions/edit_education.php';
include $_SERVER['DOCUMENT_ROOT'].'/functions/edit_work.php';
include $_SERVER['DOCUMENT_ROOT'].'/functions/edit_position.php';
include $_SERVER['DOCUMENT_ROOT'].'/functions/ping_online.php';
include $_SERVER['DOCUMENT_ROOT'].'/functions/visits.php';
include $_SERVER['DOCUMENT_ROOT'].'/functions/otvety.php';


include $_SERVER['DOCUMENT_ROOT']."/inc/agent.php";
$agent->init();
?>
<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta name="description" content="">
        <meta name="author" content="">
        <title><?php echo $title; ?></title>
        <link href="/img/favicon.png" rel="shortcut icon" type="image/x-icon" />        
        <link rel="stylesheet" type="text/css" href="/css/bootstrap.css?r=<?php echo $global_rand; ?>" />
        <link rel="stylesheet" type="text/css" href="/icon/style.css?r=<?php echo $global_rand; ?>" />
        <?php if ($my_id):?>
        <script>
            country_id = '<?php echo $my_country_id; ?>';
            onload = function() {
                if (country_id!=='0') { start_city_list(); }
                ping_online();
            }
        </script>
        <?php endif;?>
    </head>
    <body role="document">
        <?php include $_SERVER['DOCUMENT_ROOT'].'/templates/header_user.tpl'; ?>
        <div class="container" style="margin-top:70px; margin-bottom:20px;">
            <div class="row" class="bs-example bs-example-tabs">
                <div class="col-md-2" style="padding-bottom:15px;">
                    <?php include $_SERVER['DOCUMENT_ROOT'].'/templates/user_left_menu.tpl'; ?>
                </div>                            
                <div class="col-md-3">                    
                    <div style="padding-top:5px; padding-bottom:5px; background-color:#ffffff; border:1px solid #e1e1e8; border-radius:4px; margin-bottom:20px;">
                        <ul id="myTab" class="list-group" style="margin:0px;">
                            <li class="list-group-item active list-group-edit" style="padding:10px; padding-left:20px; border-radius:0px;" onClick="$('#myTab a[href=\'#main\']').tab('show');"><a href="#main" data-toggle="tab"><?php echo $lang[271]; ?></a></li>
                            <li class="list-group-item list-group-edit" style="padding:10px; padding-left:20px; border-radius:0px; margin-top:5px;" onClick="$('#myTab a[href=\'#contacts\']').tab('show');"><a href="#contacts" data-toggle="tab"><?php echo $lang[272]; ?></a></li>
                            <li class="list-group-item list-group-edit" style="padding:10px; padding-left:20px; border-radius:0px; margin-top:5px;" onClick="$('#myTab a[href=\'#interests\']').tab('show');"><a href="#interests" data-toggle="tab"><?php echo $lang[273]; ?></a></li>
                            <li class="list-group-item list-group-edit" style="padding:10px; padding-left:20px; border-radius:0px; margin-top:5px;" onClick="$('#myTab a[href=\'#education\']').tab('show');"><a href="#education" data-toggle="tab"><?php echo $lang[274]; ?></a></li>
                            <li class="list-group-item list-group-edit" style="padding:10px; padding-left:20px; border-radius:0px; margin-top:5px;" onClick="$('#myTab a[href=\'#work\']').tab('show');"><a href="#work" data-toggle="tab"><?php echo $lang[275]; ?></a></li>
                            <li class="list-group-item list-group-edit" style="padding:10px; padding-left:20px; border-radius:0px; margin-top:5px;" onClick="$('#myTab a[href=\'#position\']').tab('show');"><a href="#position" data-toggle="tab"><?php echo $lang[276]; ?></a></li>
                        </ul>
                    </div>    
                </div>
                <div class="col-md-7">
                        <div style="padding:20px; background-color:#ffffff; border:1px solid #e1e1e8; border-radius:4px; margin-bottom:20px;">    
                            <div id="myTabContent" class="tab-content active">
                                <div class="tab-pane active" id="main">
                                    <div class="header-title-bg">
                                        <?php echo $lang[277]; ?>
                                    </div>
                                    <br><br><br>
                                    <div class="form-group">
                                        <label><?php echo $lang[278]; ?></label>
                                        <input id="id_firstname" placeholder="<?php echo $lang[279]; ?>" class="form-control" data-toggle="tooltip" data-placement="top" title="" value="<?php echo $my_firstname; ?>" onKeyDown="$('#id_firstname').tooltip('destroy');">
                                    </div>
                                    <div class="form-group">
                                        <label><?php echo $lang[280]; ?></label>
                                        <input id="id_lastname" placeholder="<?php echo $lang[281]; ?>" class="form-control" data-toggle="tooltip" data-placement="top" title="" value="<?php echo $my_lastname; ?>" onKeyDown="$('#id_lastname').tooltip('destroy');">
                                    </div>
                                    <div class="form-group">
                                        <label><?php echo $lang[282]; ?></label>
                                        <div id="id_pol" class="row" data-toggle="tooltip" data-placement="top" title="">
                                            <div class="col-md-12">
                                            <b class="caret" style="position:absolute; margin-top:15px; margin-left:calc(100% - 50px); z-index:1000; cursor:pointer;"></b><div id="id_sex" placeholder="<?php echo $lang[283]; ?>" class="form-control" class="dropdown-toggle" data-toggle="dropdown" aria-expanded="true" onClick="$('#id_firstdate').tooltip('destroy');" style="height:34px; padding-top:8px; border:1px solid #ccc; cursor:pointer;"><?php echo $my_sex_value; ?></div>
                                            <ul class="dropdown-menu" style="min-width:calc(100% - 30px); width:calc(100% - 30px); margin-left:15px; margin-top:-1px; border-color:#CCC;">
                                                <li><a onClick="document.getElementById('id_sex').innerHTML=this.innerHTML; $('#id_pol').tooltip('destroy');"><?php echo $lang[284]; ?></a></li>
                                                <li><a onClick="document.getElementById('id_sex').innerHTML=this.innerHTML; $('#id_pol').tooltip('destroy');"><?php echo $lang[285]; ?></a></li>
                                            </ul>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="form-group" style="margin-bottom:0px;">
                                        <label><?php echo $lang[286]; ?></label>
                                        <div id="id_firstdate" class="row" data-toggle="tooltip" data-placement="top" title="">
                                            <div class="col-md-4" style="padding-bottom:15px;">
                                                <b class="caret" style="position:absolute; margin-top:15px; margin-left:calc(100% - 50px); z-index:1000; cursor:pointer;"></b><div id="id_day" placeholder="<?php echo $lang[287]; ?>" class="form-control" class="dropdown-toggle" data-toggle="dropdown" aria-expanded="true" onClick="$('#id_firstdate').tooltip('destroy');" style="height:34px; padding-top:8px; border:1px solid #ccc; cursor:pointer;"><?php echo $my_day; ?></div>
                                                <ul class="dropdown-menu" style="min-width:calc(100% - 30px); width:calc(100% - 30px); height:115px; margin-left:15px; margin-top:-16px; overflow-y:scroll; overflow-x:hidden; border-color:#CCC;">
                                                <?php
                                                for ($i=1; $i<32; $i++) {
                                                echo '<li><a onClick="document.getElementById(\'id_day\').innerHTML=this.innerHTML; $(\'#id_firstdate\').tooltip(\'destroy\');">'.$i.'</a></li>
                                                ';    
                                                }
                                                ?>
                                                </ul>
                                            </div>    
                                            <div class="col-md-4" style="padding-bottom:15px;">
                                                <b class="caret" style="position:absolute; margin-top:15px; margin-left:calc(100% - 50px); z-index:1000; cursor:pointer;"></b><div id="id_month" placeholder="<?php echo $lang[288]; ?>" class="form-control" class="dropdown-toggle" data-toggle="dropdown" aria-expanded="true" onKeyDown="$('#id_firstdate').tooltip('destroy');" style="height:34px; padding-top:8px; border:1px solid #ccc; cursor:pointer;"><?php echo $my_month_value; ?></div>
                                                <ul class="dropdown-menu" style="min-width:calc(100% - 30px); width:calc(100% - 30px); height:115px; margin-left:15px; margin-top:-16px; overflow-y:scroll; overflow-x:hidden; border-color:#CCC;">
                                                <?php
                                                $months = $lang[289];
                                                $arr_months = explode(', ', $months);
                                                for ($i=0; $i<count($arr_months); $i++) {
                                                echo '<li><a onClick="document.getElementById(\'id_month\').innerHTML=this.innerHTML; $(\'#id_firstdate\').tooltip(\'destroy\');">'.$arr_months[$i].'</a></li>
                                                ';    
                                                }
                                                ?>
                                                </ul>
                                            </div>
                                            <div class="col-md-4" style="padding-bottom:15px;">
                                                <b class="caret" style="position:absolute; margin-top:15px; margin-left:calc(100% - 50px); z-index:1000; cursor:pointer;"></b><div id="id_year" placeholder="<?php echo $lang[290]; ?>" class="form-control" class="dropdown-toggle" data-toggle="dropdown" aria-expanded="true" onKeyDown="$('#id_firstdate').tooltip('destroy');" style="height:34px; padding-top:8px; border:1px solid #ccc; cursor:pointer;"><?php echo $my_year; ?></div>
                                                <ul class="dropdown-menu" style="min-width:calc(100% - 30px); width:calc(100% - 30px); height:115px; margin-left:15px; margin-top:-16px; overflow-y:scroll; overflow-x:hidden; border-color:#CCC;">
                                                <?php
                                                for ($i=1955; $i<2006; $i++) {
                                                echo '<li><a onClick="document.getElementById(\'id_year\').innerHTML=this.innerHTML; $(\'#id_firstdate\').tooltip(\'destroy\');">'.$i.'</a></li>
                                                ';    
                                                }
                                                ?>
                                                </ul>
                                            </div>    
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <label><?php echo $lang[291]; ?></label>
                                        <div class="row" data-toggle="tooltip" data-placement="top" title="">
                                            <div class="col-md-12">
                                            <b class="caret" style="position:absolute; margin-top:15px; margin-left:calc(100% - 50px); z-index:1000; cursor:pointer;"></b><div id="id_marital_status" class="form-control" class="dropdown-toggle" data-toggle="dropdown" aria-expanded="true" data-toggle="tooltip" data-placement="top" title="" style="height:34px; padding-top:8px; border:1px solid #ccc; cursor:pointer;"><?php echo $my_marital_status_value; ?></div>
                                            <ul class="dropdown-menu" style="min-width:calc(100% - 30px); width:calc(100% - 30px); height:115px; margin-left:15px; margin-top:-1px; overflow-y:scroll; overflow-x:hidden; border-color:#CCC;">
                                                <li><a onClick="document.getElementById('id_marital_status').innerHTML='<?php echo $lang[292]; ?>'; $('#id_marital_status').tooltip('destroy');"><?php echo $lang[293]; ?></a></li>
                                                <li><a onClick="document.getElementById('id_marital_status').innerHTML=this.innerHTML; $('#id_marital_status').tooltip('destroy');"><?php echo $lang[294]; ?></a></li>
                                                <li><a onClick="document.getElementById('id_marital_status').innerHTML=this.innerHTML; $('#id_marital_status').tooltip('destroy');"><?php echo $lang[295]; ?></a></li>
                                                <li><a onClick="document.getElementById('id_marital_status').innerHTML=this.innerHTML; $('#id_marital_status').tooltip('destroy');"><?php echo $lang[296]; ?></a></li>
                                                <li><a onClick="document.getElementById('id_marital_status').innerHTML=this.innerHTML; $('#id_marital_status').tooltip('destroy');"><?php echo $lang[297]; ?></a></li>
                                                <li><a onClick="document.getElementById('id_marital_status').innerHTML=this.innerHTML; $('#id_marital_status').tooltip('destroy');"><?php echo $lang[298]; ?></a></li>
                                                <li><a onClick="document.getElementById('id_marital_status').innerHTML=this.innerHTML; $('#id_marital_status').tooltip('destroy');"><?php echo $lang[299]; ?></a></li>
                                                <li><a onClick="document.getElementById('id_marital_status').innerHTML=this.innerHTML; $('#id_marital_status').tooltip('destroy');"><?php echo $lang[300]; ?></a></li>
                                            </ul>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <label><?php echo $lang[301]; ?></label>
                                        <div id="id_toolcountry" class="row" data-toggle="tooltip" data-placement="top" title="">
                                            <div class="col-md-12">
                                                <b class="caret" style="position:absolute; margin-top:15px; margin-left:calc(100% - 50px); z-index:1000; cursor:pointer;"></b><div id="id_country" class="form-control" class="dropdown-toggle" data-toggle="dropdown" aria-expanded="true" onKeyDown="$('#id_toolcountry').tooltip('destroy');" style="height:34px; padding-top:8px; border:1px solid #ccc; cursor:pointer;"><?php echo $my_country_name; ?></div>
                                                <ul class="dropdown-menu" style="min-width:calc(100% - 30px); width:calc(100% - 30px); height:115px; margin-left:15px; margin-top:-1px; overflow-y:scroll; overflow-x:hidden; border-color:#CCC;">
                                                <?php echo $country_list; ?>
                                                </ul>
                                            </div>
                                        </div>
                                    </div>
                                    <div id="city_block" class="form-group" style="display:none;">
                                        <label><?php echo $lang[302]; ?></label>
                                        <div id="id_toolcity" class="row" data-toggle="tooltip" data-placement="top" title="">
                                            <div class="col-md-12">
                                            <b class="caret" style="position:absolute; margin-top:15px; margin-left:calc(100% - 50px); z-index:1000; cursor:pointer;"></b><div id="id_city" class="form-control" class="dropdown-toggle" data-toggle="dropdown" aria-expanded="true" onKeyDown="$('#id_toolcity').tooltip('destroy'); start_city_list();" style="height:34px; padding-top:8px; border:1px solid #ccc; cursor:pointer;"><?php echo $my_city_name; ?></div>
                                            <ul id="id_city_list" class="dropdown-menu" style="min-width:calc(100% - 30px); width:calc(100% - 30px); height:115px; margin-left:15px; margin-top:-1px; overflow-y:scroll; overflow-x:hidden; border-color:#CCC;"></ul>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="row" style="margin-top:5px;">
                                        <div class="col-md-12">
                                            <div class="form-group" style="text-align:right;">
                                                <button type="button" class="btn btn-primary" onClick="start_edit_main();"><?php echo $lang[303]; ?></button>
                                            </div>
                                        </div>
                                    </div>    
                                </div>
                                
                                <div class="tab-pane" id="contacts">
                                    <div class="header-title-bg">
                                        <?php echo $lang[304]; ?>
                                    </div>
                                    <br><br><br>
                                    <div class="form-group">
                                        <label><?php echo $lang[305]; ?></label>
                                        <input id="id_phone" placeholder="<?php echo $lang[306]; ?>" class="form-control" data-toggle="tooltip" data-placement="top" title="" value="<?php echo $my_phone; ?>" onKeyDown="$('#id_phone').tooltip('destroy');">
                                    </div>
                                    <div class="form-group">
                                        <label><?php echo $lang[307]; ?></label>
                                        <input id="id_mail" placeholder="<?php echo $lang[308]; ?>" class="form-control" data-toggle="tooltip" data-placement="top" title="" value="<?php echo $my_mail; ?>" onKeyDown="$('#id_mail').tooltip('destroy');">
                                    </div>
                                    <div class="form-group">
                                        <label><?php echo $lang[309]; ?></label>
                                        <input id="id_skype" placeholder="<?php echo $lang[310]; ?>" class="form-control" data-toggle="tooltip" data-placement="top" title="" value="<?php echo $my_skype; ?>" onKeyDown="$('#id_skype').tooltip('destroy');">
                                    </div>
                                    <div class="form-group">
                                        <label><?php echo $lang[311]; ?></label>
                                        <input id="id_site" placeholder="<?php echo $lang[312]; ?>" class="form-control" data-toggle="tooltip" data-placement="top" title="" value="<?php echo $my_site; ?>" onKeyDown="$('#id_site').tooltip('destroy');">
                                    </div>
                                    <div class="row" style="margin-top:5px;">
                                        <div class="col-md-12">
                                            <div class="form-group" style="text-align:right;">
                                                <button type="button" class="btn btn-primary" onClick="start_edit_contacts();"><?php echo $lang[313]; ?></button>
                                            </div>
                                        </div>
                                    </div>    
                                </div>
                                
                                <div class="tab-pane" id="interests">
                                    <div class="header-title-bg">
                                        <?php echo $lang[314]; ?>
                                    </div>
                                    <br><br><br>
                                    <div class="form-group">
                                        <label><?php echo $lang[315]; ?></label>
                                        <textarea id="id_activity" placeholder="<?php echo $lang[316]; ?>" class="form-control" data-toggle="tooltip" data-placement="top" title="" style="height:70px; padding-top:10px; padding-bottom:10px; resize:none;" onKeyDown="$('#id_activity').tooltip('destroy');"><?php echo $my_activity; ?></textarea>
                                    </div>
                                    <div class="form-group">
                                        <label><?php echo $lang[317]; ?></label>
                                        <textarea id="id_interests" placeholder="<?php echo $lang[318]; ?>" class="form-control" data-toggle="tooltip" data-placement="top" title="" style="height:70px; padding-top:10px; padding-bottom:10px; resize:none;" onKeyDown="$('#id_interests').tooltip('destroy');"><?php echo $my_interests; ?></textarea>
                                    </div>
                                    <div class="form-group">
                                        <label><?php echo $lang[319]; ?></label>
                                        <textarea id="id_music" placeholder="<?php echo $lang[320]; ?>" class="form-control" data-toggle="tooltip" data-placement="top" title="" style="height:70px; padding-top:10px; padding-bottom:10px; resize:none;" onKeyDown="$('#id_music').tooltip('destroy');"><?php echo $my_music; ?></textarea>
                                    </div>
                                    <div class="form-group">
                                        <label><?php echo $lang[321]; ?></label>
                                        <textarea id="id_movies" placeholder="<?php echo $lang[322]; ?>" class="form-control" data-toggle="tooltip" data-placement="top" title="" style="height:70px; padding-top:10px; padding-bottom:10px; resize:none;" onKeyDown="$('#id_movies').tooltip('destroy');"><?php echo $my_movies; ?></textarea>
                                    </div>
                                    <div class="form-group">
                                        <label><?php echo $lang[323]; ?></label>
                                        <textarea id="id_tv" placeholder="<?php echo $lang[324]; ?>" class="form-control" data-toggle="tooltip" data-placement="top" title="" style="height:70px; padding-top:10px; padding-bottom:10px; resize:none;" onKeyDown="$('#id_tv').tooltip('destroy');"><?php echo $my_tv; ?></textarea>
                                    </div>
                                    <div class="form-group">
                                        <label><?php echo $lang[325]; ?></label>
                                        <textarea id="id_books" placeholder="<?php echo $lang[326]; ?>" class="form-control" data-toggle="tooltip" data-placement="top" title="" style="height:70px; padding-top:10px; padding-bottom:10px; resize:none;" onKeyDown="$('#id_books').tooltip('destroy');"><?php echo $my_books; ?></textarea>
                                    </div>
                                    <div class="form-group">
                                        <label><?php echo $lang[327]; ?></label>
                                        <textarea id="id_games" placeholder="<?php echo $lang[328]; ?>" class="form-control" data-toggle="tooltip" data-placement="top" title="" style="height:70px; padding-top:10px; padding-bottom:10px; resize:none;" onKeyDown="$('#id_games').tooltip('destroy');"><?php echo $my_games; ?></textarea>
                                    </div>
                                    <div class="form-group">
                                        <label><?php echo $lang[329]; ?></label>
                                        <textarea id="id_quotations" placeholder="<?php echo $lang[330]; ?>" class="form-control" data-toggle="tooltip" data-placement="top" title="" style="height:70px; padding-top:10px; padding-bottom:10px; resize:none;" onKeyDown="$('#id_quotations').tooltip('destroy');"><?php echo $my_quotations; ?></textarea>
                                    </div>
                                    <div class="form-group">
                                        <label><?php echo $lang[331]; ?></label>
                                        <textarea id="id_about" placeholder="<?php echo $lang[332]; ?>" class="form-control" data-toggle="tooltip" data-placement="top" title="" style="height:70px; padding-top:10px; padding-bottom:10px; resize:none;" onKeyDown="$('#id_about').tooltip('destroy');"><?php echo $my_about; ?></textarea>
                                    </div>
                                    <div class="row" style="margin-top:5px;">
                                        <div class="col-md-12">
                                            <div class="form-group" style="text-align:right;">
                                                <button type="button" class="btn btn-primary" onClick="start_edit_interests();"><?php echo $lang[333]; ?></button>
                                            </div>
                                        </div>
                                    </div>    
                                </div>
                                
                                <div class="tab-pane" id="education">
                                <div class="header-title-bg">
                                    <?php echo $lang[334]; ?>
                                </div>
                                    <br><br><br>
                                    <div class="form-group">
                                        <label><?php echo $lang[335]; ?></label>
                                        <input id="id_institut" placeholder="<?php echo $lang[336]; ?>" class="form-control" data-toggle="tooltip" data-placement="top" title="" value="<?php echo $my_institut; ?>"  onKeyDown="$('#id_institut').tooltip('destroy');">
                                    </div>
                                    <div class="form-group">
                                        <label><?php echo $lang[337]; ?></label>
                                        <input id="id_department" placeholder="<?php echo $lang[338]; ?>" class="form-control" data-toggle="tooltip" data-placement="top" title="" value="<?php echo $my_department; ?>"  onKeyDown="$('#id_department').tooltip('destroy');">
                                    </div>
                                    <div class="form-group" style="margin-bottom:0px;">
                                        <label><?php echo $lang[339]; ?></label>                        
                                        <div id="id_err_training" class="row" data-toggle="tooltip" data-placement="top" title="">
                                            <div class="col-md-6" style="padding-bottom:15px;">
                                                <b class="caret" style="position:absolute; margin-top:15px; margin-left:calc(100% - 50px); z-index:1000; cursor:pointer;"></b><div id="id_start_training" class="form-control" class="dropdown-toggle" data-toggle="dropdown" aria-expanded="true" style="height:34px; padding-top:8px; border:1px solid #ccc; cursor:pointer;"><?php echo $my_start_training; ?></div>
                                                <ul class="dropdown-menu" style="min-width:calc(100% - 30px); width:calc(100% - 30px); height:115px; margin-left:15px; margin-top:-16px; overflow-y:scroll; overflow-x:hidden; border-color:#CCC;">
                                                    <li><a onClick="document.getElementById('id_start_training').innerHTML=this.innerHTML; $('#id_err_training').tooltip('destroy');"><?php echo $lang[340]; ?></a></li>
                                                    <?php
                                                    for ($i=1955; $i<2017; $i++) {
                                                    echo '<li><a onClick="document.getElementById(\'id_start_training\').innerHTML=this.innerHTML; $(\'#id_err_training\').tooltip(\'destroy\');">'.$i.'</a></li>
                                                    ';    
                                                    }
                                                    ?>
                                                </ul>
                                            </div>    
                                            <div class="col-md-6" style="padding-bottom:15px;">
                                                <b class="caret" style="position:absolute; margin-top:15px; margin-left:calc(100% - 50px); z-index:1000; cursor:pointer;"></b><div id="id_finish_training" class="form-control" class="dropdown-toggle" data-toggle="dropdown" aria-expanded="true" style="height:34px; padding-top:8px; border:1px solid #ccc; cursor:pointer;"><?php echo $my_finish_training; ?></div>
                                                <ul class="dropdown-menu" style="min-width:calc(100% - 30px); width:calc(100% - 30px); height:115px; margin-left:15px; margin-top:-16px; overflow-y:scroll; overflow-x:hidden; border-color:#CCC;">
                                                    <li><a onClick="document.getElementById('id_finish_training').innerHTML=this.innerHTML; $('#id_err_training').tooltip('destroy');"><?php echo $lang[341]; ?></a></li>
                                                    <?php
                                                    for ($i=1955; $i<2017; $i++) {
                                                    echo '<li><a onClick="document.getElementById(\'id_finish_training\').innerHTML=this.innerHTML; $(\'#id_err_training\').tooltip(\'destroy\');">'.$i.'</a></li>
                                                    ';    
                                                    }
                                                    ?>
                                                </ul>
                                            </div>    
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <label><?php echo $lang[342]; ?></label>
                                        <textarea id="id_education_info" placeholder="<?php echo $lang[343]; ?>" class="form-control" data-toggle="tooltip" data-placement="top" title="" style="height:70px; padding-top:10px; padding-bottom:10px; resize:none;" onKeyDown="$('#id_education_info').tooltip('destroy');"><?php echo $my_education_info; ?></textarea>
                                    </div>
                                    
                                    <div class="row" style="margin-top:5px;">
                                        <div class="col-md-12">
                                            <div class="form-group" style="text-align:right;">
                                                <button type="button" class="btn btn-primary" onClick="start_edit_education();"><?php echo $lang[344]; ?></button>
                                            </div>
                                        </div>
                                    </div>    
                                </div>
                                
                                <div class="tab-pane" id="work">
                                    <div class="header-title-bg">
                                        <?php echo $lang[345]; ?>
                                    </div>
                                    <br><br><br>
                                    <div class="form-group">
                                        <label><?php echo $lang[346]; ?></label>
                                        <input id="id_place_work" placeholder="<?php echo $lang[347]; ?>" class="form-control" data-toggle="tooltip" data-placement="top" title="" value="<?php echo $my_place_work; ?>" onKeyDown="$('#id_place_work').tooltip('destroy');">
                                    </div>
                                    <div class="form-group">
                                        <label><?php echo $lang[348]; ?></label>
                                        <input id="id_position" placeholder="<?php echo $lang[349]; ?>" class="form-control" data-toggle="tooltip" data-placement="top" title="" value="<?php echo $my_position; ?>" onKeyDown="$('#id_position').tooltip('destroy');">
                                    </div>
                                    <div class="form-group">
                                        <label><?php echo $lang[350]; ?></label>
                                        <textarea id="id_work_info" placeholder="<?php echo $lang[351]; ?>" class="form-control" data-toggle="tooltip" data-placement="top" title="" style="height:70px; padding-top:10px; padding-bottom:10px; resize:none;" onKeyDown="$('#id_work_info').tooltip('destroy');"><?php echo $my_work_info; ?></textarea>
                                    </div>
                                    <div class="row" style="margin-top:5px;">
                                        <div class="col-md-12">
                                            <div class="form-group" style="text-align:right;">
                                                <button type="button" class="btn btn-primary" onClick="start_edit_work();"><?php echo $lang[352]; ?></button>
                                            </div>
                                        </div>
                                    </div>    
                                </div>
                                
                                <div class="tab-pane" id="position">
                                    <div class="header-title-bg">
                                        <?php echo $lang[353]; ?>
                                    </div>
                                    <br><br><br>
                                    <div class="form-group">
                                        <label><?php echo $lang[354]; ?></label>
                                        <div class="row" data-toggle="tooltip" data-placement="top" title="">
                                            <div class="col-md-12">
                                            <b class="caret" style="position:absolute; margin-top:15px; margin-left:calc(100% - 50px); z-index:1000; cursor:pointer;"></b><div id="id_policy" class="form-control" class="dropdown-toggle" data-toggle="dropdown" aria-expanded="true" data-toggle="tooltip" data-placement="top" title="" style="height:34px; padding-top:8px; border:1px solid #ccc; cursor:pointer;"><?php echo $my_policy_value; ?></div>
                                            <ul class="dropdown-menu" style="min-width:calc(100% - 30px); width:calc(100% - 30px); height:115px; margin-left:15px; margin-top:-1px; overflow-y:scroll; overflow-x:hidden; border-color:#CCC;">
                                                <li><a onClick="document.getElementById('id_policy').innerHTML='<?php echo $lang[355]; ?>'; $('#id_policy').tooltip('destroy');"><?php echo $lang[355]; ?></a></li>
                                                <li><a onClick="document.getElementById('id_policy').innerHTML=this.innerHTML; $('#id_policy').tooltip('destroy');"><?php echo $lang[356]; ?></a></li>
                                                <li><a onClick="document.getElementById('id_policy').innerHTML=this.innerHTML; $('#id_policy').tooltip('destroy');"><?php echo $lang[357]; ?></a></li>
                                                <li><a onClick="document.getElementById('id_policy').innerHTML=this.innerHTML; $('#id_policy').tooltip('destroy');"><?php echo $lang[358]; ?></a></li>
                                                <li><a onClick="document.getElementById('id_policy').innerHTML=this.innerHTML; $('#id_policy').tooltip('destroy');"><?php echo $lang[359]; ?></a></li>
                                                <li><a onClick="document.getElementById('id_policy').innerHTML=this.innerHTML; $('#id_policy').tooltip('destroy');"><?php echo $lang[360]; ?></a></li>
                                                <li><a onClick="document.getElementById('id_policy').innerHTML=this.innerHTML; $('#id_policy').tooltip('destroy');"><?php echo $lang[361]; ?></a></li>
                                                <li><a onClick="document.getElementById('id_policy').innerHTML=this.innerHTML; $('#id_policy').tooltip('destroy');"><?php echo $lang[362]; ?></a></li>
                                                <li><a onClick="document.getElementById('id_policy').innerHTML=this.innerHTML; $('#id_policy').tooltip('destroy');"><?php echo $lang[363]; ?></a></li>
                                            </ul>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <label><?php echo $lang[364]; ?></label>
                                        <div class="row" data-toggle="tooltip" data-placement="top" title="">
                                            <div class="col-md-12">
                                            <b class="caret" style="position:absolute; margin-top:15px; margin-left:calc(100% - 50px); z-index:1000; cursor:pointer;"></b><div id="id_world_view" class="form-control" class="dropdown-toggle" data-toggle="dropdown" aria-expanded="true" data-toggle="tooltip" data-placement="top" title="" style="height:34px; padding-top:8px; border:1px solid #ccc; cursor:pointer;"><?php echo $my_world_view_value; ?></div>
                                            <ul class="dropdown-menu" style="min-width:calc(100% - 30px); width:calc(100% - 30px); height:115px; margin-left:15px; margin-top:-1px; overflow-y:scroll; overflow-x:hidden; border-color:#CCC;">
                                                <li><a onClick="document.getElementById('id_world_view').innerHTML='<?php echo $lang[365]; ?>'; $('#id_world_view').tooltip('destroy');"><?php echo $lang[365]; ?></a></li>
                                                <li><a onClick="document.getElementById('id_world_view').innerHTML=this.innerHTML; $('#id_world_view').tooltip('destroy');"><?php echo $lang[366]; ?></a></li>
                                                <li><a onClick="document.getElementById('id_world_view').innerHTML=this.innerHTML; $('#id_world_view').tooltip('destroy');"><?php echo $lang[367]; ?></a></li>
                                                <li><a onClick="document.getElementById('id_world_view').innerHTML=this.innerHTML; $('#id_world_view').tooltip('destroy');"><?php echo $lang[368]; ?></a></li>
                                                <li><a onClick="document.getElementById('id_world_view').innerHTML=this.innerHTML; $('#id_world_view').tooltip('destroy');"><?php echo $lang[369]; ?></a></li>
                                                <li><a onClick="document.getElementById('id_world_view').innerHTML=this.innerHTML; $('#id_world_view').tooltip('destroy');"><?php echo $lang[370]; ?></a></li>
                                                <li><a onClick="document.getElementById('id_world_view').innerHTML=this.innerHTML; $('#id_world_view').tooltip('destroy');"><?php echo $lang[371]; ?></a></li>
                                                <li><a onClick="document.getElementById('id_world_view').innerHTML=this.innerHTML; $('#id_world_view').tooltip('destroy');"><?php echo $lang[372]; ?></a></li>
                                                <li><a onClick="document.getElementById('id_world_view').innerHTML=this.innerHTML; $('#id_world_view').tooltip('destroy');"><?php echo $lang[373]; ?></a></li>
                                                <li><a onClick="document.getElementById('id_world_view').innerHTML=this.innerHTML; $('#id_world_view').tooltip('destroy');"><?php echo $lang[374]; ?></a></li>
                                            </ul>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <label><?php echo $lang[375]; ?></label>
                                        <div class="row" data-toggle="tooltip" data-placement="top" title="">
                                            <div class="col-md-12">
                                            <b class="caret" style="position:absolute; margin-top:15px; margin-left:calc(100% - 50px); z-index:1000; cursor:pointer;"></b><div id="id_important_live" class="form-control" class="dropdown-toggle" data-toggle="dropdown" aria-expanded="true" data-toggle="tooltip" data-placement="top" title="" style="height:34px; padding-top:8px; border:1px solid #ccc; cursor:pointer;"><?php echo $my_important_live_value; ?></div>
                                            <ul class="dropdown-menu" style="min-width:calc(100% - 30px); width:calc(100% - 30px); height:115px; margin-left:15px; margin-top:-1px; overflow-y:scroll; overflow-x:hidden; border-color:#CCC;">
                                                <li><a onClick="document.getElementById('id_important_live').innerHTML='<?php echo $lang[376]; ?>'; $('#id_important_live').tooltip('destroy');"><?php echo $lang[376]; ?></a></li>
                                                <li><a onClick="document.getElementById('id_important_live').innerHTML=this.innerHTML; $('#id_important_live').tooltip('destroy');"><?php echo $lang[377]; ?></a></li>
                                                <li><a onClick="document.getElementById('id_important_live').innerHTML=this.innerHTML; $('#id_important_live').tooltip('destroy');"><?php echo $lang[378]; ?></a></li>
                                                <li><a onClick="document.getElementById('id_important_live').innerHTML=this.innerHTML; $('#id_important_live').tooltip('destroy');"><?php echo $lang[379]; ?></a></li>
                                                <li><a onClick="document.getElementById('id_important_live').innerHTML=this.innerHTML; $('#id_important_live').tooltip('destroy');"><?php echo $lang[380]; ?></a></li>
                                                <li><a onClick="document.getElementById('id_important_live').innerHTML=this.innerHTML; $('#id_important_live').tooltip('destroy');"><?php echo $lang[381]; ?></a></li>
                                                <li><a onClick="document.getElementById('id_important_live').innerHTML=this.innerHTML; $('#id_important_live').tooltip('destroy');"><?php echo $lang[382]; ?></a></li>
                                                <li><a onClick="document.getElementById('id_important_live').innerHTML=this.innerHTML; $('#id_important_live').tooltip('destroy');"><?php echo $lang[383]; ?></a></li>
                                                <li><a onClick="document.getElementById('id_important_live').innerHTML=this.innerHTML; $('#id_important_live').tooltip('destroy');"><?php echo $lang[384]; ?></a></li>
                                            </ul>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <label><?php echo $lang[385]; ?></label>
                                        <div class="row" data-toggle="tooltip" data-placement="top" title="">
                                            <div class="col-md-12">
                                            <b class="caret" style="position:absolute; margin-top:15px; margin-left:calc(100% - 50px); z-index:1000; cursor:pointer;"></b><div id="id_important_peoples" class="form-control" class="dropdown-toggle" data-toggle="dropdown" aria-expanded="true" data-toggle="tooltip" data-placement="top" title="" style="height:34px; padding-top:8px; border:1px solid #ccc; cursor:pointer;"><?php echo $my_important_peoples_value; ?></div>
                                            <ul class="dropdown-menu" style="min-width:calc(100% - 30px); width:calc(100% - 30px); height:115px; margin-left:15px; margin-top:-1px; overflow-y:scroll; overflow-x:hidden; border-color:#CCC;">
                                                <li><a onClick="document.getElementById('id_important_peoples').innerHTML='<?php echo $lang[386]; ?>'; $('#id_important_peoples').tooltip('destroy');"><?php echo $lang[386]; ?></a></li>
                                                <li><a onClick="document.getElementById('id_important_peoples').innerHTML=this.innerHTML; $('#id_important_peoples').tooltip('destroy');"><?php echo $lang[387]; ?></a></li>
                                                <li><a onClick="document.getElementById('id_important_peoples').innerHTML=this.innerHTML; $('#id_important_peoples').tooltip('destroy');"><?php echo $lang[388]; ?></a></li>
                                                <li><a onClick="document.getElementById('id_important_peoples').innerHTML=this.innerHTML; $('#id_important_peoples').tooltip('destroy');"><?php echo $lang[389]; ?></a></li>
                                                <li><a onClick="document.getElementById('id_important_peoples').innerHTML=this.innerHTML; $('#id_important_peoples').tooltip('destroy');"><?php echo $lang[390]; ?></a></li>
                                                <li><a onClick="document.getElementById('id_important_peoples').innerHTML=this.innerHTML; $('#id_important_peoples').tooltip('destroy');"><?php echo $lang[391]; ?></a></li>
                                                <li><a onClick="document.getElementById('id_important_peoples').innerHTML=this.innerHTML; $('#id_important_peoples').tooltip('destroy');"><?php echo $lang[392]; ?></a></li>
                                            </ul>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <label><?php echo $lang[393]; ?></label>
                                        <div class="row" data-toggle="tooltip" data-placement="top" title="">
                                            <div class="col-md-12">
                                            <b class="caret" style="position:absolute; margin-top:15px; margin-left:calc(100% - 50px); z-index:1000; cursor:pointer;"></b><div id="id_smoking" class="form-control" class="dropdown-toggle" data-toggle="dropdown" aria-expanded="true" data-toggle="tooltip" data-placement="top" title="" style="height:34px; padding-top:8px; border:1px solid #ccc; cursor:pointer;"><?php echo $my_smoking_value; ?></div>
                                            <ul class="dropdown-menu" style="min-width:calc(100% - 30px); width:calc(100% - 30px); height:115px; margin-left:15px; margin-top:-1px; overflow-y:scroll; overflow-x:hidden; border-color:#CCC;">
                                                <li><a onClick="document.getElementById('id_smoking').innerHTML='<?php echo $lang[394]; ?>'; $('#id_smoking').tooltip('destroy');"><?php echo $lang[394]; ?></a></li>
                                                <li><a onClick="document.getElementById('id_smoking').innerHTML=this.innerHTML; $('#id_smoking').tooltip('destroy');"><?php echo $lang[395]; ?></a></li>
                                                <li><a onClick="document.getElementById('id_smoking').innerHTML=this.innerHTML; $('#id_smoking').tooltip('destroy');"><?php echo $lang[396]; ?></a></li>
                                                <li><a onClick="document.getElementById('id_smoking').innerHTML=this.innerHTML; $('#id_smoking').tooltip('destroy');"><?php echo $lang[397]; ?></a></li>
                                                <li><a onClick="document.getElementById('id_smoking').innerHTML=this.innerHTML; $('#id_smoking').tooltip('destroy');"><?php echo $lang[398]; ?></a></li>
                                                <li><a onClick="document.getElementById('id_smoking').innerHTML=this.innerHTML; $('#id_smoking').tooltip('destroy');"><?php echo $lang[399]; ?></a></li>
                                            </ul>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <label><?php echo $lang[400]; ?></label>
                                        <div class="row" data-toggle="tooltip" data-placement="top" title="">
                                            <div class="col-md-12">
                                            <b class="caret" style="position:absolute; margin-top:15px; margin-left:calc(100% - 50px); z-index:1000; cursor:pointer;"></b><div id="id_alcohol" class="form-control" class="dropdown-toggle" data-toggle="dropdown" aria-expanded="true" data-toggle="tooltip" data-placement="top" title="" style="height:34px; padding-top:8px; border:1px solid #ccc; cursor:pointer;"><?php echo $my_alcohol_value; ?></div>
                                            <ul class="dropdown-menu" style="min-width:calc(100% - 30px); width:calc(100% - 30px); height:115px; margin-left:15px; margin-top:-1px; overflow-y:scroll; overflow-x:hidden; border-color:#CCC;">
                                                <li><a onClick="document.getElementById('id_alcohol').innerHTML='<?php echo $lang[401]; ?>'; $('#id_alcohol').tooltip('destroy');"><?php echo $lang[401]; ?></a></li>
                                                <li><a onClick="document.getElementById('id_alcohol').innerHTML=this.innerHTML; $('#id_alcohol').tooltip('destroy');"><?php echo $lang[402]; ?></a></li>
                                                <li><a onClick="document.getElementById('id_alcohol').innerHTML=this.innerHTML; $('#id_alcohol').tooltip('destroy');"><?php echo $lang[403]; ?></a></li>
                                                <li><a onClick="document.getElementById('id_alcohol').innerHTML=this.innerHTML; $('#id_alcohol').tooltip('destroy');"><?php echo $lang[404]; ?></a></li>
                                                <li><a onClick="document.getElementById('id_alcohol').innerHTML=this.innerHTML; $('#id_alcohol').tooltip('destroy');"><?php echo $lang[405]; ?></a></li>
                                                <li><a onClick="document.getElementById('id_alcohol').innerHTML=this.innerHTML; $('#id_alcohol').tooltip('destroy');"><?php echo $lang[406]; ?></a></li>
                                            </ul>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <label><?php echo $lang[407]; ?></label>
                                        <textarea id="id_inspirations" placeholder="<?php echo $lang[408]; ?>" class="form-control" data-toggle="tooltip" data-placement="top" title="" style="height:70px; padding-top:10px; padding-bottom:10px; resize:none;" onKeyDown="$('#id_inspirations').tooltip('destroy');"><?php echo $my_inspirations; ?></textarea>
                                    </div>
                                    <div class="row" style="margin-top:5px;">
                                        <div class="col-md-12">
                                            <div class="form-group" style="text-align:right;">
                                                <button type="button" class="btn btn-primary" onClick="start_edit_position();"><?php echo $lang[409]; ?></button>
                                            </div>
                                        </div>
                                    </div>    
                                </div>
                            </div>
                        </div>                            
                </div>                        
            </div>
        </div>                

        <?php include $_SERVER['DOCUMENT_ROOT'].'/modal/visits.php'; ?>
        <?php include $_SERVER['DOCUMENT_ROOT'].'/modal/otvety.php'; ?>
        
        <div class="talker">
        <div class="talker_message"></div>
        </div>            
        <?php include $_SERVER['DOCUMENT_ROOT'].'/templates/footer.tpl'; ?>    
        <script>
            <?php if ($my_id):?>var otvety_count = <?php echo $count_otvety; ?>;<?php endif;?>
            var tokens = ['<?php echo md5($my_id.'_main_'.$secret); ?>', '<?php echo md5($my_id.'_contacts_'.$secret); ?>', '<?php echo md5($my_id.'_interests_'.$secret); ?>', '<?php echo md5($my_id.'_education_'.$secret); ?>', '<?php echo md5($my_id.'_work_'.$secret); ?>', '<?php echo md5($my_id.'_position_'.$secret); ?>'];
            var page = 1;
            var more = false;
        </script>
        <script src="/js/system/<?php echo $js_lang; ?>/edit.js?r=<?php echo $global_rand; ?>" type="text/javascript"></script>
    </body>
</html>