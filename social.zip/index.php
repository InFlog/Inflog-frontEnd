<?php
include $_SERVER['DOCUMENT_ROOT'].'/inc/config.php';
include $_SERVER['DOCUMENT_ROOT'].'/inc/login.php';
if ($my_id) {
    header('Location: /'.$link[0]);
} else {
    $title = $lang[7];
    $global_rand = rand(100000, 999999);
}
?>
<?php
include $_SERVER['DOCUMENT_ROOT'].'/functions/top_search.php';
include $_SERVER['DOCUMENT_ROOT'].'/functions/login.php';


include $_SERVER['DOCUMENT_ROOT']."/inc/agent.php";
$agent->init();
?>
<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta name="description" content="">
        <meta name="author" content="">
        <title><?php echo $title; ?></title>
        <link href="/img/favicon.png" rel="shortcut icon" type="image/x-icon" />    
        <link rel="stylesheet" type="text/css" href="/css/bootstrap.css?r=<?php echo $global_rand; ?>" />
    </head>
    <body role="document">
        <?php
        include $_SERVER['DOCUMENT_ROOT'].'/templates/header_user.tpl';
        ?>
        <div class="container" style="margin-top:70px; margin-bottom:20px;">
            <div class="row">
                <div class="col-md-2" style="padding-bottom:15px;">
                    <?php include $_SERVER['DOCUMENT_ROOT'].'/templates/user_left_menu.tpl'; ?>
                </div>
                <div class="col-md-10">
                    <div class="row">
                        <div class="col-md-1"></div>
                        <div class="col-md-10" style="padding:30px; padding-top:0px;">
                            <div class="row">
                                <h4><?php echo $lang[0]; ?></h4>
                                <p style="text-align:justify;"><?php echo $lang[1]; ?></p>
                                <hr style="margin-top:10px; margin-bottom:10px; border-bottom:1px solid #ccc;"></hr>
                                <p><?php echo $lang[2]; ?></p>
                                <ul>
                                    <li><?php echo $lang[3]; ?></li>
                                    <li><?php echo $lang[4]; ?></li>
                                    <li><?php echo $lang[5]; ?></li>
                                </ul>
                                <br>
                                <p style="text-align:center;">
                                    <a href="/<?php echo $link[3]; ?>"><button type="button" class="btn btn-success btn-lg"><?php echo $lang[6]; ?></button></a>
                                </p>
                                <br>
                                <div style="width:33%; padding-bottom:15px; float:left; text-align:center; padding-right:10px;">
                                    <div style="padding:50%; background:#fff; border-radius:100%; background-image: url('/img/main/scr_1.png'); margin-right:2px; background-size:cover; background-position:center; box-shadow:inset 0px 0px 10px rgba(0,0,0,0.25);"></div>
                                </div>
                                <div style="width:33%; padding-bottom:15px; float:left; text-align:center; padding:5px; padding-top:0px;">
                                    <div style="padding:50%; background:#fff; border-radius:100%; background-image: url('/img/main/scr_2.png'); margin-right:2px; background-size:cover; background-position:center; box-shadow:inset 0px 0px 10px rgba(0,0,0,0.25);"></div>
                                </div>
                                <div style="width:33%; padding-bottom:15px; float:left; text-align:center; padding-left:10px;">
                                    <div style="padding:50%; background:#fff; border-radius:100%; background-image: url('/img/main/scr_3.png'); margin-right:2px; background-size:cover; background-position:center; box-shadow:inset 0px 0px 10px rgba(0,0,0,0.25);"></div>
                                </div>
                            </div>
                        </div>
                    <div class="col-md-1"></div>
                    </div>
                </div>
            </div>                
        </div>
        
        <div class="talker">
        <div class="talker_message"></div>
        </div>
        <?php include $_SERVER['DOCUMENT_ROOT'].'/templates/footer.tpl'; ?>
        <script src="/js/system/<?php echo $js_lang; ?>/index.js?r=<?php echo $global_rand; ?>" type="text/javascript"></script>
    </body>
</html>