<div id="id_comment_photo" class="modal" style="margin-left:0px;">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-hidden="true" style="font-size:18px;">&times;</button>
                <h4 class="modal-title" id="myModalLabel"><? echo $lang[492]; ?></h4>
            </div>
            <div id="id_comment_photo_body" class="modal-body" style="padding:0px;"></div>
        </div>
    </div>
</div>