<div id="id_modal_avatar" class="modal" style="margin-left:0px;">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-hidden="true" style="font-size:18px;">&times;</button>
                <?php if ($live_avatar):?>
                <h4 class="modal-title" id="myModalLabel"><? echo $lang[488]; ?></h4>
                <?php endif;?>
                <?php if (!$live_avatar):?>
                <h4 class="modal-title" id="myModalLabel"><? echo $lang[489]; ?></h4>
                <?php endif;?>
            </div>
            <div class="modal-body">
                <div class="row">                        
                    <div id="id_preload_ava" class="col-md-3" style="text-align:center; padding-bottom:20px;"></div>
                    <div class="col-md-9" id="id_upload_ava"></div>                        
                </div>            
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-primary" data-dismiss="modal" onClick="del_avatar();"><? echo $lang[490]; ?></button>
            </div>
        </div>
    </div>
</div>