<div id="id_modal_otvety" class="modal" style="margin-left:0px;">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-hidden="true" style="font-size:18px;">&times;</button>
                <h4 class="modal-title" id="myModalLabel"><? echo $lang[493]; ?> <b id="id_otvety_count"></b></h4>
            </div>
            <div class="modal-body" style="padding:20px 0px 20px 0px;">
                <div id="id_body_otvety" class="row" style="margin:0px 15px 0px 15px; padding:0px; text-align:center;">
                    <div style="text-align:center;"><img src="/img/preloader.gif" /></div>
                </div>
            </div>
        </div>
    </div>
</div>