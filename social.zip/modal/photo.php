<?
include $_SERVER['DOCUMENT_ROOT'].'/inc/login.php';
include $_SERVER['DOCUMENT_ROOT'].'/inc/sql_social.php';
$rand = rand(10000, 99999);
$user_ava_id = $my_id;
$z_user_avatar = mysql_query("SELECT * FROM users WHERE id='$user_ava_id'");
$o_user_avatar = mysql_fetch_array($z_user_avatar);
$user_avatar = $o_user_avatar['avatar'];
$user_sex = $o_user_avatar['sex'];
if ($user_avatar==0) {
    if ($user_sex==1) { $avatar = '/img/no_photo/girl.png?r='.$rand; }
    if ($user_sex==2) { $avatar = '/img/no_photo/boy.png?r='.$rand; }
} else {
    $avatar = '/avatar/'.$user_ava_id.'.jpg?r='.$rand;
}
mysql_close($msconnect);
?>
        <div id="id_modal_photos" class="modal" style="margin-left:0px;">
            <div class="modal-dialog">
                <div class="modal-content">
                    <div class="modal-header">
                        <button type="button" class="close" data-dismiss="modal" aria-hidden="true" style="font-size:18px;">&times;</button>
                        <h4 class="modal-title" id="myModalLabel"><? echo $lang[494]; ?> <b id="id_p1"></b> <? echo $lang[495]; ?> <b id="id_p2"></b></h4>
                    </div>
                    <div class="modal-body" style="padding:0px;">
                        <section id="photo_slider" class="slider">
                            <? echo $photo_modal; ?>
                        </section>
                        <div id="id_photo_comments" style="padding:15px;"></div>
                        <?php if ($my_id):?>
                        <div style="padding:15px; background:#f5f5f5; border-top:1px solid #e1e1e8;">
                            <div style="float:left;">
                                <a href="/id<? echo $my_id; ?>"><img id="id_top_avatar" width="30" height="30" src="<? echo $avatar; ?>" style="border-radius:100px;"></a>
                            </div>
                            <div style="width:calc(100% - 30px); float:left; padding-left:10px;">
                                <textarea id="id_comment" placeholder="<? echo $lang[496]; ?>" style="height:50px; width:100%; padding:7px; resize:none; border:1px solid #e1e1e8;"></textarea>
                                <div id="upload_comment_results"></div>
                                <div id="id_upload_comment_status" style="width:30%; float:left; padding-top:15px;"></div>
                                <div style="width:70%; float:left; padding-top:10px;">
                                    <button type="button" class="btn btn-primary" onclick="token='<? echo md5($my_id.'_'.$uid.'_sendcomment_'.$secret); ?>'; send_comment();" style="float:right;"><? echo $lang[497]; ?></button>
                                    <span id="id_open_smiles" data-toggle="popover" data-html="true" data-placement="top" data-content="<div><img width='20' height='20' src='/img/smiles/m_1.png' style='margin:2px; cursor:pointer;' onClick='smile_id=1; add_smile();' /><img  width='20' height='20' src='/img/smiles/m_2.png' style='margin:2px; cursor:pointer;' onClick='smile_id=2; add_smile();' /><img  width='20' height='20' src='/img/smiles/m_3.png' style='margin:2px; cursor:pointer;' onClick='smile_id=3; add_smile();' /><img  width='20' height='20' src='/img/smiles/m_4.png' style='margin:2px; cursor:pointer;' onClick='smile_id=4; add_smile();' /><img  width='20' height='20' src='/img/smiles/m_5.png' style='margin:2px; cursor:pointer;' onClick='smile_id=5; add_smile();' /><img  width='20' height='20' src='/img/smiles/m_6.png' style='margin:2px; cursor:pointer;' onClick='smile_id=6; add_smile();' /><img  width='20' height='20' src='/img/smiles/m_7.png' style='margin:2px; cursor:pointer;' onClick='smile_id=7; add_smile();' /></div><div><img width='20' height='20' src='/img/smiles/m_8.png' style='margin:2px; cursor:pointer;' onClick='smile_id=8; add_smile();' /><img  width='20' height='20' src='/img/smiles/m_9.png' style='margin:2px; cursor:pointer;' onClick='smile_id=9; add_smile();' /><img  width='20' height='20' src='/img/smiles/m_10.png' style='margin:2px; cursor:pointer;' onClick='smile_id=10; add_smile();' /><img  width='20' height='20' src='/img/smiles/m_11.png' style='margin:2px; cursor:pointer;' onClick='smile_id=11; add_smile();' /><img  width='20' height='20' src='/img/smiles/m_12.png' style='margin:2px; cursor:pointer;' onClick='smile_id=12; add_smile();' /><img  width='20' height='20' src='/img/smiles/m_13.png' style='margin:2px; cursor:pointer;' onClick='smile_id=13; add_smile();' /><img  width='20' height='20' src='/img/smiles/m_14.png' style='margin:2px; cursor:pointer;' onClick='smile_id=14; add_smile();' /></div><div><img width='20' height='20' src='/img/smiles/m_15.png' style='margin:2px; cursor:pointer;' onClick='smile_id=15; add_smile();' /><img  width='20' height='20' src='/img/smiles/m_16.png' style='margin:2px; cursor:pointer;' onClick='smile_id=16; add_smile();' /><img  width='20' height='20' src='/img/smiles/m_17.png' style='margin:2px; cursor:pointer;' onClick='smile_id=17; add_smile();' /><img  width='20' height='20' src='/img/smiles/m_18.png' style='margin:2px; cursor:pointer;' onClick='smile_id=18; add_smile();' /><img  width='20' height='20' src='/img/smiles/m_19.png' style='margin:2px; cursor:pointer;' onClick='smile_id=19; add_smile();' /><img  width='20' height='20' src='/img/smiles/m_20.png' style='margin:2px; cursor:pointer;' onClick='smile_id=20; add_smile();' /><img  width='20' height='20' src='/img/smiles/m_21.png' style='margin:2px; cursor:pointer;' onClick='smile_id=21; add_smile();' /></div><div><img width='20' height='20' src='/img/smiles/m_22.png' style='margin:2px; cursor:pointer;' onClick='smile_id=22; add_smile();' /><img  width='20' height='20' src='/img/smiles/m_23.png' style='margin:2px; cursor:pointer;' onClick='smile_id=23; add_smile();' /><img  width='20' height='20' src='/img/smiles/m_24.png' style='margin:2px; cursor:pointer;' onClick='smile_id=24; add_smile();' /><img  width='20' height='20' src='/img/smiles/m_25.png' style='margin:2px; cursor:pointer;' onClick='smile_id=25; add_smile();' /><img  width='20' height='20' src='/img/smiles/m_26.png' style='margin:2px; cursor:pointer;' onClick='smile_id=26; add_smile();' /><img  width='20' height='20' src='/img/smiles/m_27.png' style='margin:2px; cursor:pointer;' onClick='smile_id=27; add_smile();' /><img  width='20' height='20' src='/img/smiles/m_28.png' style='margin:2px; cursor:pointer;' onClick='smile_id=28; add_smile();' /></div><div><img width='20' height='20' src='/img/smiles/m_29.png' style='margin:2px; cursor:pointer;' onClick='smile_id=29; add_smile();' /><img  width='20' height='20' src='/img/smiles/m_30.png' style='margin:2px; cursor:pointer;' onClick='smile_id=30; add_smile();' /><img  width='20' height='20' src='/img/smiles/m_31.png' style='margin:2px; cursor:pointer;' onClick='smile_id=31; add_smile();' /><img  width='20' height='20' src='/img/smiles/m_32.png' style='margin:2px; cursor:pointer;' onClick='smile_id=32; add_smile();' /><img  width='20' height='20' src='/img/smiles/m_33.png' style='margin:2px; cursor:pointer;' onClick='smile_id=33; add_smile();' /><img  width='20' height='20' src='/img/smiles/m_34.png' style='margin:2px; cursor:pointer;' onClick='smile_id=34; add_smile();' /><img  width='20' height='20' src='/img/smiles/m_35.png' style='margin:2px; cursor:pointer;' onClick='smile_id=35; add_smile();' /></div>" class="icon-bird" style="color:#999; font-size:20px; float:right; margin-top:7px; margin-right:15px; cursor:pointer;" onMouseOver="$('#id_open_smiles').popover();"></span>
                                </div>
                            </div>
                        </div>
                        <div style="padding:15px; background:#f5f5f5;"><div class="row"></div></div>
                        <div style="padding:15px; background:#222;">
                            <div class="row">
                                <div class="col-md-12" style="text-align:right;">
                                    <?php if ($my_id and $my_id==$uid):?>
                                    <a style="cursor:pointer; font-size:12px; color:#fff;" onclick="token='<? echo md5($my_id.'_'.$uid.'_delphoto_'.$secret); ?>'; del_photo();"><? echo $lang[498]; ?></a>
                                    <?php endif;?>
                                    <?php if ($my_id):?>
                                    <span class="dropdown-toggle" data-toggle="dropdown" aria-expanded="true" style="cursor:pointer; font-size:12px; color:#fff; margin-left:15px;"><? echo $lang[499]; ?> <b class="caret"></b></span>
                                    <ul class="dropdown-menu" style="margin-top:-16px; border-bottom:none; border-color:#CCC; margin-left:calc(100% - 175px); margin-top:-70px;">
                                        <li><a onclick="token='<? echo md5($my_id.'_'.$uid.'_savephoto_'.$secret); ?>'; save_photo();"><? echo $lang[500]; ?></a></li>
                                    </ul>
                                    <?php endif;?>
                                </div>
                            </div>
                        </div>
                        <?php endif;?>
                    </div>
                </div>
            </div>
        </div>