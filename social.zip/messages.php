<?php
include $_SERVER['DOCUMENT_ROOT'].'/inc/config.php';
include $_SERVER['DOCUMENT_ROOT'].'/inc/login.php';
if ($my_id) {
    include $_SERVER['DOCUMENT_ROOT'].'/inc/sql_social.php';
    $uid = $_GET['id'];
    $uid = addslashes($uid);
    $uid = htmlspecialchars($uid);
    
    $z_user_info = mysql_query("SELECT * FROM users WHERE id='$uid'");
    $o_user_info = mysql_fetch_array($z_user_info);
    $live_user = $o_user_info['id'];
    
    if (!isset($_GET['id'])) {
        $live_user = true;
    }
    
        $info_firstname = $o_user_info['firstname'];
        
        $rand = rand(10000, 99999);
        $z_user_avatar = mysql_query("SELECT * FROM users WHERE id='$uid'");
        $o_user_avatar = mysql_fetch_array($z_user_avatar);
        $user_avatar = $o_user_avatar['avatar'];
        $user_sex = $o_user_avatar['sex'];
        if ($user_avatar==0) {
            if ($user_sex==1) { $avatar = '/img/no_photo/girl.png?r='.$rand; }
            if ($user_sex==2) { $avatar = '/img/no_photo/boy.png?r='.$rand; }
        } else {
            $avatar = '/avatar/'.$uid.'.jpg?r='.$rand;
        }
        
        $z_dialog_id = mysql_query("SELECT * FROM dialogs WHERE user_from='$uid' and user_to='$my_id'");
        $o_dialog_id = mysql_fetch_array($z_dialog_id);
        $dialog_id = $o_dialog_id['dialog_id'];
            
        if ($dialog_id) {
            mysql_query("UPDATE dialogs SET status='0' WHERE user_from='$uid' and user_to='$my_id'");
        }
        
        $z_count_otvety = mysql_query("SELECT * FROM news WHERE user_to='$my_id'");
        $count_otvety = mysql_num_rows($z_count_otvety);
        
        $z_count_my_dialogs = mysql_query("SELECT dialog_id FROM dialogs WHERE user_to='$my_id' OR user_from='$my_id'");
        $count_my_dialogs = mysql_num_rows($z_count_my_dialogs);
        
        $z_count_my_dialogs_noread = mysql_query("SELECT dialog_id FROM dialogs WHERE user_to='$my_id' and status='1'");
        $count_my_dialogs_noread = mysql_num_rows($z_count_my_dialogs_noread);

        mysql_close($msconnect);
        $global_rand = rand(100000, 999999);
        
        if (isset($_GET['id'])) {
            $title = $lang[417];
        } else {
            $title = $lang[418];
        }

} else {
    header('Location: /'.$link[3]);
}
?>
<?php
include $_SERVER['DOCUMENT_ROOT'].'/functions/top_search.php';
include $_SERVER['DOCUMENT_ROOT'].'/functions/load_photo.php';
include $_SERVER['DOCUMENT_ROOT'].'/functions/like_users.php';
include $_SERVER['DOCUMENT_ROOT'].'/functions/ping_online.php';
include $_SERVER['DOCUMENT_ROOT'].'/functions/visits.php';
include $_SERVER['DOCUMENT_ROOT'].'/functions/otvety.php';
include $_SERVER['DOCUMENT_ROOT'].'/functions/load_message.php';
include $_SERVER['DOCUMENT_ROOT'].'/functions/send_messages.php';
include $_SERVER['DOCUMENT_ROOT'].'/functions/ping_messages.php';
include $_SERVER['DOCUMENT_ROOT'].'/functions/load_dialogs.php';


include $_SERVER['DOCUMENT_ROOT']."/inc/agent.php";
$agent->init();
?>
<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta name="description" content="">
        <meta name="author" content="">
        <title><?php echo $title; ?></title>
        <link href="/img/favicon.png" rel="shortcut icon" type="image/x-icon" />        
        <link rel="stylesheet" type="text/css" href="/css/bootstrap.css?r=<?php echo $global_rand; ?>" />
        <link rel="stylesheet" type="text/css" href="/icon/style.css?r=<?php echo $global_rand; ?>" />
        <script>
            <?php if ($my_id):?>otvety_count = <?php echo $count_otvety; ?>;<?php endif;?>
            <?php if (isset($_GET['id'])):?>
                <?php if ($my_id):?>var tokens = ['<?php echo md5($my_id.'_messages_'.$secret);?>', '<?php echo md5($my_id.'_sendmessages_'.$secret); ?>', '<?php echo md5($my_id.'_'.$uid.'_pingmessages_'.$secret); ?>', '<?php echo md5($my_id.'_'.$uid.'_sendmessages_'.$secret); ?>', '<?php echo md5($uid.'_loadmessages_'.$secret);?>'];<?php endif;?>
                live_send = true;
                uid = <?php echo $uid; ?>;
                live_ping = true;
                live_key = false;
                live_load = true;
            <?php endif;?>
            <?php if (!isset($_GET['id'])):?>
                <?php if ($my_id):?>var tokens = ['<?php echo md5($my_id.'_loaddialogs_'.$secret);?>'];<?php endif;?>
            <?php endif;?>
            page = 1;
            more = false;
            onload = function() {
                <?php if (isset($_GET['id'])):?>
                init_upload_messages();
                load_message();
                <?php endif;?>
                <?php if (!isset($_GET['id'])):?>
                dialogs_type = 1;
                load_dialogs();
                <?php endif;?>
                ping_online();
            }
        </script>
    </head>
    <body role="document">
        <?php include $_SERVER['DOCUMENT_ROOT'].'/templates/header_user.tpl'; ?>
        <div class="container" style="margin-top:70px; margin-bottom:20px;">
            <div class="row" class="bs-example bs-example-tabs">
                <div class="col-md-2" style="padding-bottom:15px;">
                    <?php include $_SERVER['DOCUMENT_ROOT'].'/templates/user_left_menu.tpl'; ?>
                </div>
                <?php if ($live_user):?>
                <div class="col-md-3">
                    <div style="padding-top:5px; padding-bottom:5px; background-color:#ffffff; border:1px solid #e1e1e8; border-radius:4px; margin-bottom:20px;">
                        <?php if (isset($_GET['id'])):?>
                        <ul id="myTab" class="list-group" style="margin:0px;">
                            <a href="/<?php echo $link[2]; ?>"><li class="list-group-item list-group-edit" style="padding:10px; padding-left:20px; border-radius:0px;"><?php echo $lang[419]; ?> <span style="float:right; padding-right:5px; color:#777; font-size:11px; padding-top:1px;"><b><?php echo $count_my_dialogs; ?></b></span></li><a>
                            <li class="list-group-item active list-group-edit" style="padding:10px; padding-left:20px; border-radius:0px; margin-top:5px; color:#2B587A;"><b><?php echo $info_firstname; ?></b> <span id="id_online_1"></span></li>
                        </ul>
                        <?php endif;?>
                        <?php if (!isset($_GET['id'])):?>
                        <ul id="myTab" class="list-group" style="margin:0px;">
                            <li class="list-group-item active list-group-edit" style="padding:10px; padding-left:20px; border-radius:0px;" onClick="$('#myTab a[href=\'#all_dialog\']').tab('show'); page=1; more=false; dialogs_type=1; load_dialogs();"><a href="#all_dialog" data-toggle="tab"><?php echo $lang[420]; ?> <span style="float:right; padding-right:5px; color:#777; font-size:11px; padding-top:1px;"><b><?php echo $count_my_dialogs; ?></b></span></a></li>
                            <li class="list-group-item list-group-edit" style="padding:10px; padding-left:20px; border-radius:0px; margin-top:5px;" onClick="$('#myTab a[href=\'#noread_dialog\']').tab('show'); page=1; more=false; dialogs_type=2; load_dialogs();"><a href="#noread_dialog" data-toggle="tab"><?php echo $lang[421]; ?> <span style="float:right; padding-right:5px; color:#777; font-size:11px; padding-top:1px;"><b><?php echo $count_my_dialogs_noread; ?></b></span></a></li>
                        </ul>
                        <?php endif;?>
                    </div>
                </div>
                <?php if (isset($_GET['id'])):?>
                <div class="col-md-7">
                    <div style="padding:0px; background-color:#ffffff; border:1px solid #e1e1e8; border-radius:4px; margin-bottom:20px;">
                        <div class="header-title-bg" style="margin-top:0px; margin-left:0px;">
                            <?php echo $lang[422]; ?> <b><?php echo $info_firstname; ?></b> <span id="id_online_2"></span>
                        </div>
                        <div id="id_message_scroll" style="height:300px; overflow-y:scroll; margin-top:47px; padding:20px;">
                            <div id="id_messages_body"></div>
                        </div>
                        <div style="padding:15px; background:#f5f5f5; border-top:1px solid #e1e1e8;">
                            <div style="float:left;">
                                <img width="30" height="30" src="<?php echo $avatar; ?>" style="border-radius:100px;">
                                <span id="id_pencil_body"></span>
                            </div>
                            <div style="width:calc(100% - 30px); float:left; padding-left:10px;">
                                <textarea id="id_messages" placeholder="<?php echo $lang[423]; ?>" style="height:33px; width:100%; padding:7px; resize:none; border:1px solid #e1e1e8;" onclick="this.style.height='70px';" onkeydown="if(event.keyCode==13){token='<?php echo md5($my_id.'_'.$uid.'_sendmessages_'.$secret); ?>'; send_messages();}else{live_key=true;}"></textarea>
                                <div id="upload_messages_results"></div>
                                <div id="id_upload_messages_status" style="width:30%; float:left; padding-top:15px;"></div>
                                <div style="width:70%; float:left; padding-top:10px;">
                                    <button type="button" class="btn btn-primary" onclick="token='<?php echo md5($my_id.'_'.$uid.'_sendmessages_'.$secret); ?>'; send_messages();" style="float:right;"><?php echo $lang[424]; ?></button>
                                    <span id="id_open_smiles_messages" data-toggle="popover" data-html="true" data-placement="top" data-content="<div><img width='20' height='20' src='/img/smiles/m_1.png' style='margin:2px; cursor:pointer;' onClick='smile_id=1; add_smile_messages();' /><img  width='20' height='20' src='/img/smiles/m_2.png' style='margin:2px; cursor:pointer;' onClick='smile_id=2; add_smile_messages();' /><img  width='20' height='20' src='/img/smiles/m_3.png' style='margin:2px; cursor:pointer;' onClick='smile_id=3; add_smile_messages();' /><img  width='20' height='20' src='/img/smiles/m_4.png' style='margin:2px; cursor:pointer;' onClick='smile_id=4; add_smile_messages();' /><img  width='20' height='20' src='/img/smiles/m_5.png' style='margin:2px; cursor:pointer;' onClick='smile_id=5; add_smile_messages();' /><img  width='20' height='20' src='/img/smiles/m_6.png' style='margin:2px; cursor:pointer;' onClick='smile_id=6; add_smile_messages();' /><img  width='20' height='20' src='/img/smiles/m_7.png' style='margin:2px; cursor:pointer;' onClick='smile_id=7; add_smile_messages();' /></div><div><img width='20' height='20' src='/img/smiles/m_8.png' style='margin:2px; cursor:pointer;' onClick='smile_id=8; add_smile_messages();' /><img  width='20' height='20' src='/img/smiles/m_9.png' style='margin:2px; cursor:pointer;' onClick='smile_id=9; add_smile_messages();' /><img  width='20' height='20' src='/img/smiles/m_10.png' style='margin:2px; cursor:pointer;' onClick='smile_id=10; add_smile_messages();' /><img  width='20' height='20' src='/img/smiles/m_11.png' style='margin:2px; cursor:pointer;' onClick='smile_id=11; add_smile_messages();' /><img  width='20' height='20' src='/img/smiles/m_12.png' style='margin:2px; cursor:pointer;' onClick='smile_id=12; add_smile_messages();' /><img  width='20' height='20' src='/img/smiles/m_13.png' style='margin:2px; cursor:pointer;' onClick='smile_id=13; add_smile_messages();' /><img  width='20' height='20' src='/img/smiles/m_14.png' style='margin:2px; cursor:pointer;' onClick='smile_id=14; add_smile_messages();' /></div><div><img width='20' height='20' src='/img/smiles/m_15.png' style='margin:2px; cursor:pointer;' onClick='smile_id=15; add_smile_messages();' /><img  width='20' height='20' src='/img/smiles/m_16.png' style='margin:2px; cursor:pointer;' onClick='smile_id=16; add_smile_messages();' /><img  width='20' height='20' src='/img/smiles/m_17.png' style='margin:2px; cursor:pointer;' onClick='smile_id=17; add_smile_messages();' /><img  width='20' height='20' src='/img/smiles/m_18.png' style='margin:2px; cursor:pointer;' onClick='smile_id=18; add_smile_messages();' /><img  width='20' height='20' src='/img/smiles/m_19.png' style='margin:2px; cursor:pointer;' onClick='smile_id=19; add_smile_messages();' /><img  width='20' height='20' src='/img/smiles/m_20.png' style='margin:2px; cursor:pointer;' onClick='smile_id=20; add_smile_messages();' /><img  width='20' height='20' src='/img/smiles/m_21.png' style='margin:2px; cursor:pointer;' onClick='smile_id=21; add_smile_messages();' /></div><div><img width='20' height='20' src='/img/smiles/m_22.png' style='margin:2px; cursor:pointer;' onClick='smile_id=22; add_smile_messages();' /><img  width='20' height='20' src='/img/smiles/m_23.png' style='margin:2px; cursor:pointer;' onClick='smile_id=23; add_smile_messages();' /><img  width='20' height='20' src='/img/smiles/m_24.png' style='margin:2px; cursor:pointer;' onClick='smile_id=24; add_smile_messages();' /><img  width='20' height='20' src='/img/smiles/m_25.png' style='margin:2px; cursor:pointer;' onClick='smile_id=25; add_smile_messages();' /><img  width='20' height='20' src='/img/smiles/m_26.png' style='margin:2px; cursor:pointer;' onClick='smile_id=26; add_smile_messages();' /><img  width='20' height='20' src='/img/smiles/m_27.png' style='margin:2px; cursor:pointer;' onClick='smile_id=27; add_smile_messages();' /><img  width='20' height='20' src='/img/smiles/m_28.png' style='margin:2px; cursor:pointer;' onClick='smile_id=28; add_smile_messages();' /></div><div><img width='20' height='20' src='/img/smiles/m_29.png' style='margin:2px; cursor:pointer;' onClick='smile_id=29; add_smile_messages();' /><img  width='20' height='20' src='/img/smiles/m_30.png' style='margin:2px; cursor:pointer;' onClick='smile_id=30; add_smile_messages();' /><img  width='20' height='20' src='/img/smiles/m_31.png' style='margin:2px; cursor:pointer;' onClick='smile_id=31; add_smile_messages();' /><img  width='20' height='20' src='/img/smiles/m_32.png' style='margin:2px; cursor:pointer;' onClick='smile_id=32; add_smile_messages();' /><img  width='20' height='20' src='/img/smiles/m_33.png' style='margin:2px; cursor:pointer;' onClick='smile_id=33; add_smile_messages();' /><img  width='20' height='20' src='/img/smiles/m_34.png' style='margin:2px; cursor:pointer;' onClick='smile_id=34; add_smile_messages();' /><img  width='20' height='20' src='/img/smiles/m_35.png' style='margin:2px; cursor:pointer;' onClick='smile_id=35; add_smile_messages();' /></div>" class="icon-bird" style="color:#999; font-size:20px; float:right; margin-top:7px; margin-right:15px; cursor:pointer;" onmouseover="$('#id_open_smiles_messages').popover();" data-original-title="" title=""></span>
                                </div>
                            </div>
                        </div>
                        <div style="padding:15px; background:#f5f5f5; border-radius:0px 0px 4px 4px;"><div class="row"></div></div>
                    </div>                            
                </div>
                <?php endif;?>
                <?php if (!isset($_GET['id'])):?>
                <div class="col-md-7">
                    <div style="padding:0px; background-color:#ffffff; border:1px solid #e1e1e8; border-radius:4px; margin-bottom:20px;">
                        <div class="header-title-bg" style="margin-top:0px; margin-left:0px;">
                            <?php echo $lang[425]; ?> <b id="id_count_dialogs"></b>
                        </div>
                        <div id="id_dialogs" style="margin-top:47px; padding-bottom:20px;"></div>
                    </div>                            
                </div>
                <?php endif;?>
                <?php endif;?>
                <?php if (!$live_user):?>
                <div class="col-md-10">
                    <div style="padding:20px; background-color:#ffffff; border:1px solid #e1e1e8; border-radius:4px; margin-bottom:20px;"> 
                        <p style="padding:15px; background:#f5f5f5; border-radius:4px; margin-bottom:0px; text-align:center;"><?php echo $lang[426]; ?></p>
                    </div>
                </div>
                <?php endif;?>
            </div>
        </div>                
        
        <?php include $_SERVER['DOCUMENT_ROOT'].'/modal/likes.php'; ?>
        <?php include $_SERVER['DOCUMENT_ROOT'].'/modal/load_photo.php'; ?>
        <?php include $_SERVER['DOCUMENT_ROOT'].'/modal/visits.php'; ?>
        <?php include $_SERVER['DOCUMENT_ROOT'].'/modal/otvety.php'; ?>
        
        <div class="talker">
        <div class="talker_message"></div>
        </div>            
        <?php include $_SERVER['DOCUMENT_ROOT'].'/templates/footer.tpl'; ?>
        <script src="/uploadify/jquery.uploadifive.min.js?r=<?php echo $global_rand; ?>" type="text/javascript"></script>
        <script src="/js/system/<?php echo $js_lang; ?>/messages.js?r=<?php echo $global_rand; ?>" type="text/javascript"></script>
    </body>
</html>