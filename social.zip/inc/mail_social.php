<?php
$host = '';//mail server
$login = '';//login mailbox
$password = '';//password mailbox
$from = '';//e-mail sending
?> 