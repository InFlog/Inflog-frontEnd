<?php
$hostname = 'localhost';//database server
$user = 'root';//user database
$password = '';//password database
$db = 'dbsocial';//database name
$msconnect = mysql_connect($hostname, $user, $password);
mysql_select_db($db);

mysql_query("SET NAMES 'UTF8'");
mysql_query("SET collation_connection = 'UTF8_general_ci'");
mysql_query("SET collation_server = 'UTF8_general_ci'");
mysql_query("SET character_set_client = 'UTF8'");
mysql_query("SET character_set_connection = 'UTF8'");
mysql_query("SET character_set_results = 'UTF8'");
mysql_query("SET character_set_server = 'UTF8'");


?>