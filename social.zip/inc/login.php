<?php
$_COOKIE['l'] = addslashes($_COOKIE['l']);
$_COOKIE['p'] = addslashes($_COOKIE['p']);

$_COOKIE['l'] = htmlspecialchars($_COOKIE['l']);
$_COOKIE['p'] = htmlspecialchars($_COOKIE['p']);

$livelogin = false;
$my_id = false;
if ($_COOKIE['l'] and $_COOKIE['p']) {
    if ($_COOKIE['l']!=='' and $_COOKIE['p']!=='') {
        $login = $_COOKIE['l'];
        $passw = $_COOKIE['p'];
        include $_SERVER['DOCUMENT_ROOT'].'/inc/sql_social.php';
        $z_my_id = mysql_query("SELECT * FROM users WHERE id='$login' and password='$passw'");
        $o_my_id = mysql_fetch_array($z_my_id);
        if ($o_my_id) { 
        $my_id = $o_my_id['id']; 
        $my_sex = $o_my_id['sex'];
        $my_avatar = $o_my_id['avatar'];
        $my_firstname = $o_my_id['firstname'];
        }
        mysql_close($msconnect);
    }
}

?>