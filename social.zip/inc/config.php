<?php
include $_SERVER['DOCUMENT_ROOT'].'/language/en.php';//en.php or ru.php
$js_lang = 'en';//en or ru
$secret = "912087780219"; //any value

$link = Array();
$link[0] = "News";
$link[1] = "Friends";
$link[2] = "Message";
$link[3] = "Registration";
$link[4] = "Recovery";
$link[5] = "Edit";
$link[6] = "Settings";
$link[7] = "Search";
$link[8] = "Photos";
?>